const { chromium } = require("playwright-core");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "../../outputs/bypassium-messenger");
const artifacts = path.join(root, "test-artifacts");
const edge = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const base = "http://127.0.0.1:4178/src/arcade/index.html";
const gameIds = ["snake", "sky", "tower", "trail", "pong", "meteor", "gravity", "blade", "golf", "territory"];

async function canvasStats(page) {
  return page.locator("#gameCanvas").evaluate((canvas) => {
    const context = canvas.getContext("2d");
    const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
    const colors = new Set();
    let opaque = 0;
    for (let y = 0; y < canvas.height; y += 20) {
      for (let x = 0; x < canvas.width; x += 20) {
        const index = (y * canvas.width + x) * 4;
        colors.add(`${pixels[index] >> 4},${pixels[index + 1] >> 4},${pixels[index + 2] >> 4}`);
        if (pixels[index + 3] > 0) opaque += 1;
      }
    }
    return { colors: colors.size, opaque };
  });
}

async function exercise(page, id) {
  await page.goto(`${base}?game=${id}`, { waitUntil: "domcontentloaded", timeout: 15000 });
  await page.waitForTimeout(2300);
  const canvas = page.locator("#gameCanvas");
  const box = await canvas.boundingBox();
  if (id === "sky" || id === "tower" || id === "gravity") await canvas.click({ position: { x: box.width * .3, y: box.height * .5 }, force: true });
  if (["snake", "meteor", "territory"].includes(id)) { await page.keyboard.press("KeyW"); await page.keyboard.press("KeyD"); }
  if (id === "pong") { await page.keyboard.down("KeyW"); await page.waitForTimeout(180); await page.keyboard.up("KeyW"); }
  if (id === "trail") { await page.keyboard.down("KeyW"); await page.waitForTimeout(550); await page.keyboard.up("KeyW"); }
  if (id === "blade") await page.mouse.move(box.x + box.width * .3, box.y + box.height * .35);
  if (id === "golf") {
    await page.mouse.move(box.x + box.width * .16, box.y + box.height * .5);
    await page.mouse.down();
    await page.mouse.move(box.x + box.width * .08, box.y + box.height * .5, { steps: 5 });
    await page.mouse.up();
  }
  await page.waitForTimeout(500);
  return canvasStats(page);
}

(async () => {
  const browser = await chromium.launch({ headless: true, executablePath: edge });
  const errors = [];
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  page.on("pageerror", (error) => errors.push(String(error)));
  page.on("console", (message) => { if (message.type() === "error") errors.push(message.text()); });
  await page.goto(base, { waitUntil: "domcontentloaded", timeout: 15000 });
  const cards = await page.locator(".game-card").count();
  if (cards !== 10) throw new Error(`Expected 10 game cards, found ${cards}`);
  await page.screenshot({ path: path.join(artifacts, "arcade-playwright-desktop.png"), fullPage: true });

  const results = {};
  for (const id of gameIds) {
    console.log(`testing ${id}`);
    results[id] = await exercise(page, id);
    if (results[id].colors < 8 || results[id].opaque < 500) throw new Error(`${id} canvas appears blank: ${JSON.stringify(results[id])}`);
  }

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${base}?game=snake`, { waitUntil: "domcontentloaded", timeout: 15000 });
  await page.waitForTimeout(2200);
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - innerWidth);
  if (overflow > 1) throw new Error(`Mobile layout overflows horizontally by ${overflow}px`);
  await page.screenshot({ path: path.join(artifacts, "arcade-playwright-mobile.png"), fullPage: true });
  await browser.close();

  const report = { cards, errors, games: results, mobileOverflow: overflow };
  fs.writeFileSync(path.join(artifacts, "arcade-playwright-report.json"), JSON.stringify(report, null, 2));
  if (errors.length) throw new Error(`Browser errors: ${errors.join(" | ")}`);
  process.stdout.write(JSON.stringify(report, null, 2));
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
