const { chromium } = require("playwright-core");
const path = require("node:path");
const fs = require("node:fs");

(async () => {
  const extensionPath = path.resolve(__dirname, "../../outputs/bypassium-messenger");
  const profile = path.resolve(__dirname, ".extension-profile");
  fs.rmSync(profile, { recursive: true, force: true });
  const context = await chromium.launchPersistentContext(profile, {
    headless: true,
    executablePath: "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
    args: [`--disable-extensions-except=${extensionPath}`, `--load-extension=${extensionPath}`]
  });
  let worker = context.serviceWorkers()[0];
  if (!worker) worker = await context.waitForEvent("serviceworker", { timeout: 15000 });
  const extensionId = new URL(worker.url()).host;
  const page = await context.newPage();
  await page.setViewportSize({ width: 380, height: 650 });
  const errors = [];
  page.on("pageerror", (error) => errors.push(String(error)));
  await page.goto(`chrome-extension://${extensionId}/src/arcade/index.html`, { waitUntil: "domcontentloaded" });
  if (await page.locator(".game-card").count() !== 10) throw new Error("Arcade did not load ten cards from the unpacked extension.");
  await page.goto(`chrome-extension://${extensionId}/src/sidepanel/index.html`, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(1200);
  if (await page.locator("#arcadeButton").count() !== 1) throw new Error("Arcade launcher is missing from the side panel.");
  const launcherBox = await page.locator("#arcadeButton").boundingBox();
  if (!launcherBox || launcherBox.y < 0 || launcherBox.y + launcherBox.height > 650) {
    throw new Error("Arcade launcher is outside the visible narrow side panel.");
  }
  const walletBox = await page.locator("#arcadeWallet").boundingBox();
  if (!walletBox || walletBox.y < 0 || walletBox.y + walletBox.height > 650) {
    throw new Error("Arcade credit wallet is outside the visible narrow side panel.");
  }
  await page.evaluate(() => {
    localStorage.setItem("bypassium-arcade-beta-v1", JSON.stringify({ credits: 4125 }));
    window.dispatchEvent(new StorageEvent("storage", { key: "bypassium-arcade-beta-v1" }));
  });
  if (await page.locator("#railCreditBalance").textContent() !== "4.1K") throw new Error("Arcade credit wallet did not refresh.");
  await page.locator("#onboardingDialog").evaluate((dialog) => dialog.close());
  await page.locator("#arcadeButton").click();
  await page.waitForTimeout(1500);
  const arcadePage = context.pages().find((candidate) => candidate !== page && candidate.url().endsWith("/src/arcade/index.html"));
  if (!arcadePage) throw new Error(`Arcade launcher did not open a new tab. Open pages: ${context.pages().map((candidate) => candidate.url()).join(", ")}`);
  await arcadePage.waitForLoadState("domcontentloaded");
  if (!arcadePage.url().endsWith("/src/arcade/index.html")) throw new Error("Arcade launcher did not open the full Arcade tab.");
  if (await arcadePage.locator(".game-card").count() !== 10) throw new Error("Arcade tab opened without its styled game library.");
  await page.screenshot({ path: path.resolve(extensionPath, "test-artifacts/arcade-launcher-narrow.png") });
  if (errors.length) throw new Error(errors.join(" | "));
  console.log(JSON.stringify({ extensionId, arcadeCards: 10, launcher: true, launcherVisible: true, creditWallet: "4.1K", opensOwnTab: true }, null, 2));
  await context.close();
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
