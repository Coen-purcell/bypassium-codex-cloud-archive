const { chromium } = require("../arcade-test/node_modules/playwright-core");
const path = require("node:path");

(async () => {
  const browser = await chromium.launch({ headless: true, executablePath: "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe" });
  for (const game of ["FruitSlice", "TowerDefense"]) {
    const page = await browser.newPage({ viewport: { width: 430, height: 760 } });
    await page.goto("http://127.0.0.1:4183/", { waitUntil: "networkidle" });
    await page.getByPlaceholder("게임 검색...").fill(game);
    await page.getByRole("button", { name: game, exact: true }).click();
    await page.waitForTimeout(1000);
    const start = page.getByRole("button", { name: /start|시작/i }).first();
    if (await start.count()) await start.click().catch(() => {});
    await page.waitForTimeout(900);
    await page.screenshot({ path: path.join(__dirname, `${game}.png`) });
    await page.close();
  }
  await browser.close();
})().catch((error) => { console.error(error); process.exitCode = 1; });
