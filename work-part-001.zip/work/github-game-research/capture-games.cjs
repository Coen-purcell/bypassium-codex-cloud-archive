const { chromium } = require("../arcade-test/node_modules/playwright-core");
const path = require("node:path");

const games = ["bullet-hell", "vaporwave-escape", "retro-racer", "hexagon-defense", "agar", "marble-run", "titan-clash", "earth-digger", "neon-portal", "block-squad"];

(async () => {
  const browser = await chromium.launch({ headless: true, executablePath: "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe" });
  for (const game of games) {
    const page = await browser.newPage({ viewport: { width: 1000, height: 760 } });
    await page.goto(`http://127.0.0.1:4182/90s-games/games/${game}.html`, { waitUntil: "domcontentloaded" });
    const start = page.getByRole("button", { name: /start|enter|new game/i }).first();
    if (await start.count()) await start.click().catch(() => {});
    await page.waitForTimeout(900);
    await page.screenshot({ path: path.join(__dirname, `${game}.png`) });
    await page.close();
  }
  await browser.close();
})().catch((error) => { console.error(error); process.exitCode = 1; });
