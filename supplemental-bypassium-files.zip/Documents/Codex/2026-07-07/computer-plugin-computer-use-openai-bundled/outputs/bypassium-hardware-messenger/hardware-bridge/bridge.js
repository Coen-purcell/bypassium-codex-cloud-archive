import process from "node:process";
import readline from "node:readline";
import { SerialPort } from "serialport";
import { ReadlineParser } from "@serialport/parser-readline";
import { WebSocketServer, WebSocket } from "ws";

const PORT = Number(process.env.BYPASSIUM_BRIDGE_PORT || 8787);
const SERIAL_PATH = process.env.BYPASSIUM_SERIAL_PORT || process.argv[2] || "";
const BAUD_RATE = Number(process.env.BYPASSIUM_BAUD || 115200);

const server = new WebSocketServer({ host: "127.0.0.1", port: PORT });
let extensionSocket = null;
let serial = null;
let cachedSnapshot = null;

server.on("connection", (socket) => {
  extensionSocket = socket;
  log(`extension connected on ws://127.0.0.1:${PORT}`);
  sendToExtension({ type: "hello", source: "hardware-bridge" });

  socket.on("message", (data) => {
    handleExtensionEvent(String(data)).catch((error) => log(`extension event failed: ${error.message}`));
  });
  socket.on("close", () => {
    if (extensionSocket === socket) extensionSocket = null;
    log("extension disconnected");
    sendToSerial("STATUS|Extension disconnected");
  });
});

if (SERIAL_PATH) {
  serial = new SerialPort({ path: SERIAL_PATH, baudRate: BAUD_RATE });
  const parser = serial.pipe(new ReadlineParser({ delimiter: "\n" }));
  serial.on("open", () => log(`serial open ${SERIAL_PATH} @ ${BAUD_RATE}`));
  serial.on("error", (error) => log(`serial error: ${error.message}`));
  parser.on("data", (line) => handleSerialLine(line.trim()));
} else {
  log("mock mode: no serial port supplied");
  log("type CONTACTS, SELECT|123456, SEND|123456|hello, or STATUS|invisible");
  const cli = readline.createInterface({ input: process.stdin, output: process.stdout });
  cli.on("line", (line) => handleSerialLine(line.trim()));
}

function handleSerialLine(line) {
  if (!line) return;
  log(`arduino -> ${line}`);
  const [command, ...parts] = line.split("|");
  if (command === "CONTACTS") {
    sendToExtension({ type: "list-contacts" });
    return;
  }
  if (command === "SNAPSHOT") {
    sendToExtension({ type: "snapshot" });
    return;
  }
  if (command === "SELECT") {
    sendToExtension({ type: "select-contact", id: parts[0] || "" });
    return;
  }
  if (command === "SEND") {
    sendToExtension({ type: "send-message", to: parts[0] || "", text: parts.slice(1).join("|") });
    return;
  }
  if (command === "STATUS") {
    sendToExtension({ type: "presence", value: parts[0] || "online" });
    return;
  }
  if (command === "DEBUG") {
    log(`arduino debug: ${parts.join("|")}`);
    return;
  }
  sendToSerial(`STATUS|Unknown command ${command}`);
}

async function handleExtensionEvent(raw) {
  const event = JSON.parse(raw);
  if (event.type === "snapshot") {
    cachedSnapshot = event;
    sendSnapshotToSerial(event);
    return;
  }
  if (event.type === "chat") {
    sendChatToSerial(event);
    return;
  }
  if (event.type === "incoming") {
    const contact = event.contact || {};
    const message = event.message || {};
    sendToSerial(`INCOMING|${field(contact.id)}|${field(contact.name)}|${field(message.text)}`);
    return;
  }
  if (event.type === "send-ok") {
    sendToSerial(`SENT|${field(event.to)}|${field(event.messageId)}`);
    return;
  }
  if (event.type === "presence") {
    sendToSerial(`PRESENCE|${field(event.value)}`);
    return;
  }
  if (event.type === "error") {
    sendToSerial(`ERROR|${field(event.message)}`);
    return;
  }
  log(`extension -> ${raw}`);
}

function sendSnapshotToSerial(snapshot) {
  sendToSerial(`READY|${field(snapshot.identity)}|${field(snapshot.displayName)}|${field(snapshot.presence)}`);
  for (const [index, contact] of (snapshot.contacts || []).entries()) {
    sendToSerial(`CONTACT|${index}|${field(contact.id)}|${field(contact.name)}|${field(contact.status)}|${Number(contact.unreadCount || 0)}`);
  }
  sendToSerial("END_CONTACTS");
}

function sendChatToSerial(event) {
  const contact = event.contact || {};
  sendToSerial(`CHAT|${field(contact.id)}|${field(contact.name)}`);
  for (const message of event.messages || []) {
    sendToSerial(`MSG|${field(message.direction)}|${field(message.text)}|${field(message.sentAt)}`);
  }
  sendToSerial("END_CHAT");
}

function sendToExtension(payload) {
  if (!extensionSocket || extensionSocket.readyState !== WebSocket.OPEN) {
    log("extension is not connected");
    sendToSerial("STATUS|Open Bypassium Developer > Hardware Terminal > Connect");
    return;
  }
  extensionSocket.send(JSON.stringify(payload));
}

function sendToSerial(line) {
  const data = `${line}\n`;
  if (serial?.writable) {
    serial.write(data);
  } else {
    process.stdout.write(`bridge -> ${line}\n`);
  }
}

function field(value) {
  return String(value || "").replace(/[\r\n|]/g, " ").slice(0, 160);
}

function log(message) {
  process.stdout.write(`[bridge] ${message}\n`);
}
