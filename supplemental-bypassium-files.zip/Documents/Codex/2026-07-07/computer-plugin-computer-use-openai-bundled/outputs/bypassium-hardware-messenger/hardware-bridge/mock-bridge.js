import crypto from "node:crypto";
import http from "node:http";
import process from "node:process";
import readline from "node:readline";

const PORT = Number(process.env.BYPASSIUM_BRIDGE_PORT || 8787);
let extensionSocket = null;

const server = http.createServer();
server.on("upgrade", (request, socket) => {
  const key = request.headers["sec-websocket-key"];
  if (!key) {
    socket.destroy();
    return;
  }
  const accept = crypto
    .createHash("sha1")
    .update(`${key}258EAFA5-E914-47DA-95CA-C5AB0DC85B11`)
    .digest("base64");
  socket.write([
    "HTTP/1.1 101 Switching Protocols",
    "Upgrade: websocket",
    "Connection: Upgrade",
    `Sec-WebSocket-Accept: ${accept}`,
    "",
    ""
  ].join("\r\n"));
  extensionSocket = socket;
  log("extension connected");
  sendToExtension({ type: "hello", source: "mock-bridge" });
  socket.on("data", (buffer) => {
    for (const frame of decodeFrames(buffer)) {
      if (frame.opcode === 0x8) {
        socket.end();
        return;
      }
      if (frame.opcode === 0x9) {
        socket.write(encodeFrame(frame.payload, 0xA));
        continue;
      }
      if (frame.opcode !== 0x1) continue;
      handleExtensionEvent(frame.payload);
    }
  });
  socket.on("close", () => {
    if (extensionSocket === socket) extensionSocket = null;
    log("extension disconnected");
  });
});

server.listen(PORT, "127.0.0.1", () => {
  log(`mock bridge listening on ws://127.0.0.1:${PORT}`);
  log("type CONTACTS, SELECT|123456, SEND|123456|hello, STATUS|invisible");
});

readline.createInterface({ input: process.stdin, output: process.stdout }).on("line", (line) => {
  handleTerminalCommand(line.trim());
});

function handleTerminalCommand(line) {
  if (!line) return;
  const [command, ...parts] = line.split("|");
  if (command === "CONTACTS") return sendToExtension({ type: "list-contacts" });
  if (command === "SNAPSHOT") return sendToExtension({ type: "snapshot" });
  if (command === "SELECT") return sendToExtension({ type: "select-contact", id: parts[0] || "" });
  if (command === "SEND") return sendToExtension({ type: "send-message", to: parts[0] || "", text: parts.slice(1).join("|") });
  if (command === "STATUS") return sendToExtension({ type: "presence", value: parts[0] || "online" });
  log(`unknown command: ${command}`);
}

function handleExtensionEvent(raw) {
  let event;
  try {
    event = JSON.parse(raw);
  } catch {
    log(`ignored non-json frame: ${JSON.stringify(raw).slice(0, 80)}`);
    return;
  }
  if (event.type === "snapshot") {
    log(`READY ${event.displayName} (${event.identity}) presence=${event.presence}`);
    for (const [index, contact] of (event.contacts || []).entries()) {
      log(`CONTACT ${index}: ${contact.name} [${contact.id}] ${contact.status} unread=${contact.unreadCount || 0}`);
    }
    return;
  }
  if (event.type === "chat") {
    log(`CHAT ${event.contact?.name || event.contact?.id}`);
    for (const message of event.messages || []) {
      log(`${message.direction === "outbound" ? "You" : "Them"}: ${message.text}`);
    }
    return;
  }
  if (event.type === "incoming") {
    log(`INCOMING ${event.contact?.name || event.contact?.id}: ${event.message?.text || ""}`);
    return;
  }
  if (event.type === "send-ok") {
    log(`SENT ${event.to} ${event.messageId}`);
    return;
  }
  if (event.type === "error") {
    log(`ERROR ${event.message}`);
    return;
  }
  log(`extension -> ${raw}`);
}

function sendToExtension(payload) {
  if (!extensionSocket || extensionSocket.destroyed) {
    log("extension is not connected");
    return;
  }
  extensionSocket.write(encodeFrame(JSON.stringify(payload)));
}

function decodeFrames(buffer) {
  const frames = [];
  let offset = 0;
  while (offset + 2 <= buffer.length) {
    const first = buffer[offset];
    const second = buffer[offset + 1];
    let length = second & 0x7f;
    offset += 2;
    if (length === 126) {
      if (offset + 2 > buffer.length) break;
      length = buffer.readUInt16BE(offset);
      offset += 2;
    } else if (length === 127) {
      if (offset + 8 > buffer.length) break;
      length = Number(buffer.readBigUInt64BE(offset));
      offset += 8;
    }
    const masked = Boolean(second & 0x80);
    const mask = masked ? buffer.subarray(offset, offset + 4) : null;
    if (masked) offset += 4;
    if (offset + length > buffer.length) break;
    const payload = Buffer.from(buffer.subarray(offset, offset + length));
    if (mask) {
      for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i % 4];
    }
    offset += length;
    frames.push({ opcode: first & 0x0f, payload: payload.toString("utf8") });
  }
  return frames;
}

function encodeFrame(text, opcode = 0x1) {
  const payload = Buffer.from(text);
  const first = 0x80 | opcode;
  if (payload.length < 126) return Buffer.concat([Buffer.from([first, payload.length]), payload]);
  if (payload.length < 65536) {
    const header = Buffer.alloc(4);
    header[0] = first;
    header[1] = 126;
    header.writeUInt16BE(payload.length, 2);
    return Buffer.concat([header, payload]);
  }
  const header = Buffer.alloc(10);
  header[0] = first;
  header[1] = 127;
  header.writeBigUInt64BE(BigInt(payload.length), 2);
  return Buffer.concat([header, payload]);
}

function log(message) {
  process.stdout.write(`[mock-bridge] ${message}\n`);
}
