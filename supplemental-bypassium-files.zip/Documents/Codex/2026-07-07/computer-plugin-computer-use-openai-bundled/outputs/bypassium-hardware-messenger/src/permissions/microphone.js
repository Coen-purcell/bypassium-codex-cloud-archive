const allowButton = document.querySelector("#allowMicrophone");
const status = document.querySelector("#permissionStatus");
const blockedHelp = document.querySelector("#blockedHelp");

allowButton.addEventListener("click", requestMicrophoneAccess);

// Requests one-time microphone consent from a visible, focused extension page.
async function requestMicrophoneAccess() {
  allowButton.disabled = true;
  blockedHelp.classList.add("hidden");
  status.textContent = "Waiting for Chrome's microphone permission...";

  let stream = null;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((track) => track.stop());
    stream = null;
    status.textContent = "Microphone enabled. Starting your voice note...";
    await chrome.runtime.sendMessage({
      target: "voice-recorder-ui",
      type: "voice-recorder-permission-granted"
    });
    setTimeout(() => window.close(), 650);
  } catch (error) {
    stream?.getTracks().forEach((track) => track.stop());
    const denied = ["NotAllowedError", "PermissionDeniedError", "SecurityError"].includes(error?.name);
    status.textContent = denied
      ? "Chrome did not allow microphone access."
      : error?.message || "The microphone could not be opened.";
    blockedHelp.classList.toggle("hidden", !denied);
    allowButton.disabled = false;
    allowButton.textContent = "Try again";
  }
}
