import { loadState, saveState } from "./storage.js";

const SIX_DIGIT_CODE = /^\d{6}$/;
const SYNCED_ID_KEY = "bypassiumIdentityRecovery";

// Encodes an ArrayBuffer as URL-safe base64 for compact encrypted payloads.
export function bufferToBase64Url(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}

// Decodes URL-safe base64 back to an ArrayBuffer.
export function base64UrlToBuffer(value) {
  const padded = value.replaceAll("-", "+").replaceAll("_", "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes.buffer;
}

// Restores or generates a permanent six-digit identity and keeps only its ID in Chrome Sync.
export async function ensureIdentity() {
  const state = await loadState();
  if (hasCompleteLocalIdentity(state.identity)) {
    await storeSyncedId(state.identity.id);
    return state.identity;
  }

  const syncedId = await loadSyncedId();
  const localId = SIX_DIGIT_CODE.test(String(state.identity?.id || "")) ? state.identity.id : "";
  const existingKeyPair = state.identity?.privateKeyJwk && state.identity?.publicKeyJwk;
  const keyPair = existingKeyPair
    ? null
    : await crypto.subtle.generateKey(
      { name: "ECDH", namedCurve: "P-256" },
      true,
      ["deriveKey"]
    );

  const identity = {
    id: localId || syncedId || generateSixDigitCode(),
    publicKeyJwk: existingKeyPair ? state.identity.publicKeyJwk : await crypto.subtle.exportKey("jwk", keyPair.publicKey),
    privateKeyJwk: existingKeyPair ? state.identity.privateKeyJwk : await crypto.subtle.exportKey("jwk", keyPair.privateKey),
    createdAt: state.identity?.createdAt || new Date().toISOString()
  };

  await saveState({ identity });
  await storeSyncedId(identity.id);
  return identity;
}

async function loadSyncedId() {
  try {
    if (!chrome.storage?.sync) return "";
    await restrictSyncStorageAccess();
    const stored = await chrome.storage.sync.get(SYNCED_ID_KEY);
    const id = String(stored[SYNCED_ID_KEY]?.id || "");
    return SIX_DIGIT_CODE.test(id) ? id : "";
  } catch {
    return "";
  }
}

async function storeSyncedId(id) {
  try {
    if (!chrome.storage?.sync || !SIX_DIGIT_CODE.test(String(id || ""))) return false;
    await restrictSyncStorageAccess();
    const stored = await chrome.storage.sync.get(SYNCED_ID_KEY);
    if (stored[SYNCED_ID_KEY]?.id === id) return true;
    await chrome.storage.sync.set({
      [SYNCED_ID_KEY]: {
        version: 1,
        id,
        updatedAt: new Date().toISOString()
      }
    });
    return true;
  } catch {
    return false;
  }
}

async function restrictSyncStorageAccess() {
  if (chrome.storage.sync.setAccessLevel) {
    await chrome.storage.sync.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
  }
}

function hasCompleteLocalIdentity(identity) {
  return Boolean(
    identity
    && SIX_DIGIT_CODE.test(String(identity.id || ""))
    && identity.publicKeyJwk
    && identity.privateKeyJwk
  );
}

// Produces a zero-padded six-digit code using browser cryptographic randomness.
function generateSixDigitCode() {
  const random = crypto.getRandomValues(new Uint32Array(1))[0] % 1000000;
  return String(random).padStart(6, "0");
}

// Validates six-digit codes before storing them as contacts.
export function isValidBypassiumId(value) {
  return typeof value === "string" && SIX_DIGIT_CODE.test(value.trim());
}
