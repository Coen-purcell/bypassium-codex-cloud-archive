const MAX_RECORDING_MS = 60_000;
const MAX_RECORDING_BYTES = 750 * 1024;

let activeRecording = null;

chrome.runtime.onMessage.addListener((message) => {
  if (message?.target !== "voice-recorder-offscreen") return;

  if (message.type === "voice-recorder-start") {
    void startRecording(message.requestId);
  }
  if (message.type === "voice-recorder-stop" && message.requestId === activeRecording?.requestId) {
    stopRecording();
  }
  if (message.type === "voice-recorder-cancel" && message.requestId === activeRecording?.requestId) {
    activeRecording.cancelled = true;
    stopRecording();
  }
});

// Captures microphone audio in Chrome's dedicated USER_MEDIA document.
async function startRecording(requestId) {
  if (!requestId) return;
  if (activeRecording) {
    notifyUi("voice-recorder-error", requestId, {
      errorName: "InvalidStateError",
      errorMessage: "Another voice note is already recording."
    });
    return;
  }

  let stream = null;
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 1
      }
    });
    const mimeType = [
      "audio/webm;codecs=opus",
      "audio/webm",
      "audio/ogg;codecs=opus"
    ].find((type) => typeof MediaRecorder.isTypeSupported === "function" && MediaRecorder.isTypeSupported(type)) || "";
    const options = { audioBitsPerSecond: 32000 };
    if (mimeType) options.mimeType = mimeType;
    const recorder = new MediaRecorder(stream, options);
    const recording = {
      requestId,
      recorder,
      stream,
      chunks: [],
      startedAt: Date.now(),
      timeout: null,
      cancelled: false,
      finished: false
    };
    activeRecording = recording;
    recorder.addEventListener("dataavailable", (event) => {
      if (event.data?.size) recording.chunks.push(event.data);
    });
    recorder.addEventListener("error", (event) => {
      recording.cancelled = true;
      notifyUi("voice-recorder-error", requestId, {
        errorName: event.error?.name || "RecorderError",
        errorMessage: event.error?.message || "Chrome stopped the voice recorder."
      });
      finishRecording(recording);
    });
    recorder.addEventListener("stop", () => void finishRecording(recording));
    recorder.start(250);
    recording.timeout = setTimeout(stopRecording, MAX_RECORDING_MS);
    notifyUi("voice-recorder-started", requestId);
  } catch (error) {
    stream?.getTracks().forEach((track) => track.stop());
    notifyUi("voice-recorder-error", requestId, {
      errorName: error?.name || "MicrophoneError",
      errorMessage: error?.message || "The microphone could not be opened."
    });
  }
}

function stopRecording() {
  if (activeRecording?.recorder.state === "recording") activeRecording.recorder.stop();
}

async function finishRecording(recording) {
  if (!recording || recording.finished) return;
  recording.finished = true;
  clearTimeout(recording.timeout);
  recording.stream.getTracks().forEach((track) => track.stop());
  if (activeRecording === recording) activeRecording = null;

  if (recording.cancelled) {
    notifyUi("voice-recorder-cancelled", recording.requestId);
    return;
  }

  const durationMs = Math.min(MAX_RECORDING_MS, Date.now() - recording.startedAt);
  const type = recording.recorder.mimeType || recording.chunks[0]?.type || "audio/webm";
  const blob = new Blob(recording.chunks, { type });
  if (durationMs < 500 || !blob.size) {
    notifyUi("voice-recorder-error", recording.requestId, {
      errorName: "RecordingTooShort",
      errorMessage: "That voice note was too short."
    });
    return;
  }
  if (blob.size > MAX_RECORDING_BYTES) {
    notifyUi("voice-recorder-error", recording.requestId, {
      errorName: "RecordingTooLarge",
      errorMessage: "That voice note is too large. Try a shorter recording."
    });
    return;
  }

  try {
    notifyUi("voice-recorder-result", recording.requestId, {
      attachment: {
        type: type.split(";")[0],
        name: "Voice note",
        dataUrl: await blobToDataUrl(blob),
        size: blob.size,
        durationMs
      }
    });
  } catch {
    notifyUi("voice-recorder-error", recording.requestId, {
      errorName: "RecordingReadError",
      errorMessage: "That voice note could not be prepared."
    });
  }
}

function notifyUi(type, requestId, detail = {}) {
  void chrome.runtime.sendMessage({
    target: "voice-recorder-ui",
    type,
    requestId,
    ...detail
  }).catch(() => {});
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Could not read recorded audio."));
    reader.readAsDataURL(blob);
  });
}
