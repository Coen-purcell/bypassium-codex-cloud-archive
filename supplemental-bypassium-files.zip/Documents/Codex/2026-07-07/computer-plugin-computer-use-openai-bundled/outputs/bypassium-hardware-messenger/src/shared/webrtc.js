import { decryptText, deriveSharedAesKey, encryptText } from "./crypto.js";
import { updateContact, updateDiagnostics } from "./storage.js";

const MAX_RELAY_COMMAND_CHARS = 3_800_000;

export class PeerMessenger {
  constructor({ identity, onMessage, onGroupMessage, onChatSetting, onQuickAddResults, onAnnouncement, onAdminNotice, onServiceConfig, onStatus, onPeerDiscovered, onContactStatuses, onProfileUpdated, onGroupsUpdated, onTyping, onReadReceipt, onReaction, onMessageStatus }) {
    this.identity = identity;
    this.onMessage = onMessage;
    this.onGroupMessage = onGroupMessage;
    this.onChatSetting = onChatSetting;
    this.onQuickAddResults = onQuickAddResults;
    this.onAnnouncement = onAnnouncement;
    this.onAdminNotice = onAdminNotice;
    this.onServiceConfig = onServiceConfig;
    this.onStatus = onStatus;
    this.onPeerDiscovered = onPeerDiscovered;
    this.onContactStatuses = onContactStatuses;
    this.onProfileUpdated = onProfileUpdated;
    this.onGroupsUpdated = onGroupsUpdated;
    this.onTyping = onTyping;
    this.onReadReceipt = onReadReceipt;
    this.onReaction = onReaction;
    this.onMessageStatus = onMessageStatus;
    this.peerId = null;
    this.peerPublicKeyJwk = null;
    this.signalingSocket = null;
    this.signalingOpenPromise = null;
    this.signalingUrl = null;
    this.messageCount = 0;
    this.serverSupportsRelay = false;
    this.serverSupportsOfflineInbox = false;
    this.serverSupportsPublicKeyDirectory = false;
    this.serverSupportsChatSettings = false;
    this.serverSupportsQuickAdd = false;
    this.serviceConfig = {};
    this.publicKeyWaiters = new Map();
    this.relayKeyCache = new Map();
    this.knownPublicKeys = new Map();
    this.knownProfiles = new Map();
    this.lastWatchedContacts = [];
    this.lastProfile = null;
    this.reconnectTimer = null;
  }

  // Registers this installation with the relay server and refreshes contact presence.
  async connectDirectory(signalingUrl, contacts = []) {
    await this.openSignalingSocket(signalingUrl);
    this.watchContacts(contacts);
    await updateDiagnostics({
      currentConnectionType: "encrypted server relay",
      peerConnectionStatus: "relay registered"
    });
  }

  // Publishes the user's public display profile to the server for saved contacts.
  publishProfile(profile) {
    this.lastProfile = profile;
    if (!this.signalingSocket || this.signalingSocket.readyState !== WebSocket.OPEN) return;
    this.signalingSocket.send(JSON.stringify({
      type: "publish-profile",
      profile
    }));
  }

  submitReport(reportType, message, evidence = "") {
    this.sendServerCommand({
      type: "submit-report",
      reportType,
      message,
      evidence,
      extensionVersion: globalThis.chrome?.runtime?.getManifest?.().version || "unknown"
    });
  }

  requestQuickAdd({ query = "", exclude = [], offset = 0, limit = 30 } = {}) {
    if (!this.serverSupportsQuickAdd) {
      throw new Error("The message server must be updated before Quick Add can load.");
    }
    this.sendServerCommand({
      type: "quick-add-request",
      query,
      exclude,
      offset,
      limit
    });
  }

  createGroup(name, members, avatar = "") {
    this.sendServerCommand({ type: "create-group", name, members, avatar });
  }

  renameGroup(groupId, name) {
    this.sendServerCommand({ type: "rename-group", groupId, name });
  }

  updateGroup(groupId, patch = {}) {
    this.sendServerCommand({ type: "update-group", groupId, ...patch });
  }

  addGroupMembers(groupId, members) {
    this.sendServerCommand({ type: "add-group-members", groupId, members });
  }

  setGroupAdmin(groupId, memberId, isAdmin) {
    this.sendServerCommand({ type: "set-group-admin", groupId, memberId, isAdmin });
  }

  transferGroupOwnership(groupId, memberId) {
    this.sendServerCommand({ type: "transfer-group-ownership", groupId, memberId });
  }

  removeGroupMember(groupId, memberId) {
    this.sendServerCommand({ type: "remove-group-member", groupId, memberId });
  }

  leaveGroup(groupId) {
    this.sendServerCommand({ type: "leave-group", groupId });
  }

  sendServerCommand(command) {
    if (!this.signalingSocket || this.signalingSocket.readyState !== WebSocket.OPEN) {
      throw new Error("Message server is not connected yet.");
    }
    this.signalingSocket.send(JSON.stringify(command));
  }

  refresh() {
    this.sendServerCommand({ type: "sync" });
    this.watchContacts(this.lastWatchedContacts);
  }

  // Asks the server for contact online status and any known public encryption keys.
  watchContacts(contacts = []) {
    this.lastWatchedContacts = contacts.map((contact) => contact.id || contact);
    if (!this.signalingSocket || this.signalingSocket.readyState !== WebSocket.OPEN) return;
    this.signalingSocket.send(JSON.stringify({
      type: "watch-contacts",
      contacts: this.lastWatchedContacts
    }));
  }

  // Selects a saved contact as the current relay target.
  async connectToPeer(contact, signalingUrl) {
    this.peerId = contact.id;
    if (contact.publicKeyJwk) this.knownPublicKeys.set(contact.id, contact.publicKeyJwk);
    this.peerPublicKeyJwk = contact.publicKeyJwk || this.knownPublicKeys.get(contact.id) || null;
    await this.openSignalingSocket(signalingUrl);
    if (!this.peerPublicKeyJwk) {
      this.watchContacts([contact.id]);
      this.peerPublicKeyJwk = await this.waitForPublicKey(contact.id);
    }
    await updateDiagnostics({
      currentConnectionType: "encrypted server relay",
      peerConnectionStatus: "relay ready"
    });
  }

  // Opens the WebSocket relay channel used for online and offline delivery.
  openSignalingSocket(signalingUrl) {
    this.signalingUrl = signalingUrl;
    if (this.signalingSocket?.readyState === WebSocket.OPEN) return Promise.resolve();
    if (this.signalingOpenPromise) return this.signalingOpenPromise;

    this.signalingOpenPromise = new Promise((resolve, reject) => {
      const socket = new WebSocket(signalingUrl);
      this.signalingSocket = socket;

      let settled = false;
      socket.onopen = () => {
        this.emitStatus("Connected to message server");
        socket.send(JSON.stringify({
          type: "register",
          peerId: this.identity.id,
          publicKeyJwk: this.identity.publicKeyJwk,
          extensionVersion: globalThis.chrome?.runtime?.getManifest?.().version || "unknown"
        }));
      };
      socket.onerror = () => {
        this.signalingOpenPromise = null;
        settled = true;
        reject(new Error("Could not reach the message server."));
      };
      socket.onclose = () => {
        this.signalingOpenPromise = null;
        this.serverSupportsRelay = false;
        this.serverSupportsOfflineInbox = false;
        this.serverSupportsPublicKeyDirectory = false;
        this.serverSupportsChatSettings = false;
        this.serverSupportsQuickAdd = false;
        updateDiagnostics({ peerConnectionStatus: "message server disconnected" });
        this.scheduleReconnect();
      };
      socket.onmessage = async (event) => {
        try {
          const message = JSON.parse(event.data);
          await this.handleServerMessage(message);
          if (message.type === "registered" && !settled) {
            settled = true;
            this.signalingOpenPromise = null;
            resolve();
          }
        } catch (error) {
          if (!settled) {
            settled = true;
            this.signalingOpenPromise = null;
            reject(error);
          }
          updateDiagnostics({ failure: `Message server failed: ${error.message}` });
          this.emitStatus(error.message);
        }
      };
    });
    return this.signalingOpenPromise;
  }

  // Handles relay server registration, presence updates, delivery receipts, and inbound messages.
  async handleServerMessage(message) {
    if (message.type === "registered") {
      this.serverSupportsRelay = Boolean(message.features?.encryptedRelay);
      this.serverSupportsOfflineInbox = Boolean(message.features?.offlineInbox);
      this.serverSupportsPublicKeyDirectory = Boolean(message.features?.publicKeyDirectory);
      this.serverSupportsChatSettings = Boolean(message.features?.encryptedChatSettings);
      this.serverSupportsQuickAdd = Boolean(message.features?.quickAddDirectory);
      this.serviceConfig = message.serviceConfig || {};
      await this.onServiceConfig?.(this.serviceConfig);
      if (Array.isArray(message.groups)) await this.onGroupsUpdated?.(message.groups);
      if (this.lastWatchedContacts.length) this.watchContacts(this.lastWatchedContacts);
      if (this.lastProfile) this.publishProfile(this.lastProfile);
      this.emitStatus("Ready to send encrypted messages");
      return;
    }

    if (message.type === "contact-statuses") {
      const publicKeys = message.publicKeys || {};
      for (const [id, publicKeyJwk] of Object.entries(publicKeys)) {
        this.knownPublicKeys.set(id, publicKeyJwk);
        await updateContact(id, { publicKeyJwk });
        if (id === this.peerId) this.peerPublicKeyJwk = publicKeyJwk;
        this.resolvePublicKeyWaiter(id, publicKeyJwk);
      }
      for (const [id, profile] of Object.entries(message.profiles || {})) {
        this.knownProfiles.set(id, profile);
      }
      this.onContactStatuses?.(message.statuses || {}, message.profiles || {});
      return;
    }

    if (message.type === "quick-add-results") {
      await this.onQuickAddResults?.(message);
      return;
    }

    if (message.type === "service-config") {
      this.serviceConfig = message.config || {};
      await this.onServiceConfig?.(this.serviceConfig);
      return;
    }

    if (message.type === "announcement") {
      await this.onAnnouncement?.(message);
      return;
    }

    if (message.type === "admin-notice") {
      await this.onAdminNotice?.(message);
      return;
    }

    if (message.type === "report-submitted") {
      this.emitStatus(`Support report submitted (${message.reportId}).`);
      return;
    }

    if (["account-restricted", "update-required", "service-unavailable"].includes(message.type)) {
      await this.onAdminNotice?.({
        title: message.type === "update-required" ? "Update required" : "Bypassium account notice",
        message: message.message || message.reason || "Access is currently restricted.",
        severity: "critical"
      });
      return;
    }

    if (message.type === "direct-message") {
      await this.handleRelayedMessage(message);
      return;
    }

    if (message.type === "direct-setting") {
      await this.handleRelayedSetting(message);
      return;
    }

    if (message.type === "group-message") {
      await this.handleGroupMessage(message);
      return;
    }

    if (message.type === "group-updated") {
      await this.onGroupsUpdated?.([message.group]);
      return;
    }

    if (message.type === "sync-complete") {
      if (Array.isArray(message.groups)) await this.onGroupsUpdated?.(message.groups);
      this.emitStatus("Messages and groups refreshed.");
      return;
    }

    if (message.type === "profile-updated") {
      await this.onProfileUpdated?.(message.peerId, message.profile);
      return;
    }

    if (message.type === "message-queued") {
      this.emitStatus(`${message.peerId || "Contact"} is offline. Encrypted message queued with the original timestamp.`);
      return;
    }

    if (message.type === "message-relayed") {
      this.emitStatus("Encrypted message delivered through server relay.");
      return;
    }

    if (message.type === "message-status") {
      await this.onMessageStatus?.(message);
      return;
    }

    if (message.type === "typing") {
      await this.onTyping?.(message);
      return;
    }

    if (message.type === "read-receipt") {
      await this.onReadReceipt?.(message);
      this.acknowledgeSavedMessage(message.queueId);
      return;
    }

    if (message.type === "reaction") {
      await this.onReaction?.(message);
      this.acknowledgeSavedMessage(message.queueId);
      return;
    }

    if (message.type === "error") {
      throw new Error(message.message || "The message server returned an error.");
    }
  }

  // Encrypts a group message once per member so the server can route but not read it.
  async sendGroupText(group, contacts, message, options = {}) {
    if (!this.signalingSocket || this.signalingSocket.readyState !== WebSocket.OPEN || !this.serverSupportsRelay || !this.serverSupportsOfflineInbox) {
      throw new Error("Message server is not connected yet.");
    }
    assertContentAllowed(this.serviceConfig, message);
    if (this.serviceConfig.groupsEnabled === false) throw new Error("Group messaging is temporarily disabled.");
    const started = performance.now();
    const sentAt = options.sentAt || new Date().toISOString();
    const recipientTasks = (group.members || []).map(async (memberId) => {
      if (memberId === this.identity.id) return null;
      const contact = contacts.find((item) => item.id === memberId);
      const publicKeyJwk = await this.publicKeyForPeer(memberId, contact?.publicKeyJwk);
      if (!publicKeyJwk) return null;
      const relayKey = await this.getRelayKey(memberId, publicKeyJwk);
      return {
        to: memberId,
        encrypted: await encryptText(relayKey, serializeChatPayload(message))
      };
    });
    const recipients = (await Promise.all(recipientTasks)).filter(Boolean);
    if (!recipients.length) throw new Error("No group members have public keys yet. They need to open Bypassium once.");
    const messageId = options.messageId || crypto.randomUUID();
    const baseCommand = {
      type: "group-message",
      groupId: group.id,
      messageId,
      sentAt,
      ...outgoingContentMetadata(message)
    };
    for (const batch of chunkRecipientsForRelay(baseCommand, recipients)) {
      this.signalingSocket.send(JSON.stringify({ ...baseCommand, recipients: batch }));
    }
    this.messageCount += 1;
    void updateDiagnostics({
      sent: this.messageCount,
      lastLatencyMs: Math.round(performance.now() - started),
      currentConnectionType: "encrypted server relay",
      encryptionStatus: "AES-GCM per group member",
      peerConnectionStatus: "group relay sent"
    });
    return { sentAt, messageId };
  }

  // Encrypts and sends a chat message through the relay server.
  async sendText(message, options = {}) {
    const started = performance.now();
    const sentAt = options.sentAt || new Date().toISOString();
    const messageId = options.messageId || crypto.randomUUID();
    const targetId = options.to || this.peerId;
    const targetPublicKey = options.publicKeyJwk
      || this.knownPublicKeys.get(targetId)
      || (targetId === this.peerId ? this.peerPublicKeyJwk : null);
    assertContentAllowed(this.serviceConfig, message);

    if (!targetId || this.signalingSocket?.readyState !== WebSocket.OPEN || !this.serverSupportsRelay || !this.serverSupportsOfflineInbox) {
      throw new Error("This contact is not ready yet. Wait for the message server to connect.");
    }

    if (!targetPublicKey) {
      throw new Error("This contact needs to open Bypassium once before encrypted messages can be sent.");
    }

    const relayKey = await this.getRelayKey(targetId, targetPublicKey);
    const encrypted = await encryptText(relayKey, serializeChatPayload(message));
    this.signalingSocket.send(JSON.stringify({
      type: "direct-message",
      to: targetId,
      messageId,
      encrypted,
      sentAt,
      ...outgoingContentMetadata(message)
    }));
    this.messageCount += 1;
    void updateDiagnostics({
      sent: this.messageCount,
      lastLatencyMs: Math.round(performance.now() - started),
      currentConnectionType: "encrypted server relay",
      encryptionStatus: "AES-GCM before server relay",
      peerConnectionStatus: "relay sent"
    });
    return { sentAt, messageId };
  }

  // Sends an encrypted conversation setting that is not rendered as a message.
  async sendChatSetting(setting, options = {}) {
    const targetId = options.to || this.peerId;
    const targetPublicKey = options.publicKeyJwk
      || this.knownPublicKeys.get(targetId)
      || (targetId === this.peerId ? this.peerPublicKeyJwk : null);
    if (!this.serverSupportsChatSettings) {
      throw new Error("The message server must be updated before backgrounds can sync.");
    }
    if (!targetId || this.signalingSocket?.readyState !== WebSocket.OPEN || !targetPublicKey) {
      throw new Error("This contact is not ready to receive shared chat settings.");
    }
    const relayKey = await this.getRelayKey(targetId, targetPublicKey);
    const messageId = crypto.randomUUID();
    this.signalingSocket.send(JSON.stringify({
      type: "direct-setting",
      to: targetId,
      messageId,
      encrypted: await encryptText(relayKey, JSON.stringify({
        version: 1,
        kind: "chat-background",
        background: setting
      })),
      sentAt: new Date().toISOString()
    }));
    return { messageId };
  }

  // Decrypts a queued group message, stores it locally through the UI, then acks it.
  async handleGroupMessage(payload) {
    try {
      if (!payload.from || !payload.groupId || !payload.publicKeyJwk || !payload.encrypted) return;
      await this.onPeerDiscovered?.({ id: payload.from, publicKeyJwk: payload.publicKeyJwk, profile: payload.profile });
      const relayKey = await this.getRelayKey(payload.from, payload.publicKeyJwk);
      const message = parseChatPayload(await decryptText(relayKey, payload.encrypted));
      if (message.kind === "reaction") {
        await this.onReaction?.({
          type: "reaction",
          from: payload.from,
          groupId: payload.groupId,
          messageId: message.reactionMessageId,
          emoji: message.emoji,
          active: message.reactionActive !== false
        });
        this.acknowledgeSavedMessage(payload.messageId);
        return;
      }
      this.messageCount += 1;
      void updateDiagnostics({
        received: this.messageCount,
        encryptionStatus: "AES-GCM per group member",
        peerConnectionStatus: "group relay received"
      });
      await this.onGroupMessage?.({
        groupId: payload.groupId,
        groupName: payload.groupName,
        members: payload.members || [],
        senderId: payload.from,
        messageId: payload.messageId,
        profile: payload.profile,
        publicKeyJwk: payload.publicKeyJwk,
        ...message,
        sentAt: payload.sentAt
      });
      this.acknowledgeSavedMessage(payload.messageId);
    } catch (error) {
      updateDiagnostics({ failure: `Could not decrypt group message: ${error.message}` });
    }
  }

  // Returns whether the selected contact can be messaged through the relay.
  canMessagePeer(peerId) {
    return Boolean(
      peerId
      && this.peerId === peerId
      && this.signalingSocket?.readyState === WebSocket.OPEN
      && this.serverSupportsRelay
      && this.serverSupportsOfflineInbox
      && this.peerPublicKeyJwk
    );
  }

  // Keeps the public method used by older UI code without closing the server socket.
  close() {
    this.peerId = null;
    this.peerPublicKeyJwk = null;
  }

  // Decrypts an encrypted message forwarded by the server without changing the active chat.
  async handleRelayedMessage(payload) {
    try {
      if (!payload.from || !payload.publicKeyJwk || !payload.encrypted) return;
      await this.onPeerDiscovered?.({ id: payload.from, publicKeyJwk: payload.publicKeyJwk, profile: payload.profile });
      const relayKey = await this.getRelayKey(payload.from, payload.publicKeyJwk);
      const message = parseChatPayload(await decryptText(relayKey, payload.encrypted));
      if (message.kind === "reaction") {
        await this.onReaction?.({
          type: "reaction",
          from: payload.from,
          messageId: message.reactionMessageId,
          emoji: message.emoji,
          active: message.reactionActive !== false
        });
        this.acknowledgeSavedMessage(payload.messageId);
        return;
      }
      this.messageCount += 1;
      void updateDiagnostics({
        received: this.messageCount,
        encryptionStatus: "AES-GCM before server relay",
        peerConnectionStatus: "relay received"
      });
      await this.onMessage?.({
        peerId: payload.from,
        messageId: payload.messageId,
        profile: payload.profile,
        publicKeyJwk: payload.publicKeyJwk,
        ...message,
        sentAt: payload.sentAt,
        from: "peer"
      });
      this.acknowledgeSavedMessage(payload.messageId);
    } catch (error) {
      updateDiagnostics({ failure: `Could not decrypt relayed message: ${error.message}` });
    }
  }

  // Decrypts a shared conversation setting and acknowledges durable server delivery.
  async handleRelayedSetting(payload) {
    try {
      if (!payload.from || !payload.publicKeyJwk || !payload.encrypted) return;
      await this.onPeerDiscovered?.({ id: payload.from, publicKeyJwk: payload.publicKeyJwk, profile: payload.profile });
      const relayKey = await this.getRelayKey(payload.from, payload.publicKeyJwk);
      const setting = JSON.parse(await decryptText(relayKey, payload.encrypted));
      if (setting?.version === 1 && setting.kind === "chat-background") {
        await this.onChatSetting?.({
          peerId: payload.from,
          background: setting.background || {},
          sentAt: payload.sentAt
        });
      }
      this.acknowledgeSavedMessage(payload.messageId);
    } catch (error) {
      updateDiagnostics({ failure: `Could not decrypt shared chat setting: ${error.message}` });
    }
  }

  // Tells the server it can delete a queued message only after local save succeeds.
  acknowledgeSavedMessage(messageId) {
    if (!messageId || this.signalingSocket?.readyState !== WebSocket.OPEN) return;
    this.signalingSocket.send(JSON.stringify({
      type: "ack-message",
      messageId
    }));
  }

  sendTyping({ to, groupId, isTyping }) {
    if (!this.signalingSocket || this.signalingSocket.readyState !== WebSocket.OPEN) return;
    this.signalingSocket.send(JSON.stringify({
      type: "typing",
      to,
      groupId,
      isTyping: Boolean(isTyping)
    }));
  }

  sendReadReceipt(peerId, messageId) {
    if (!peerId || !messageId || this.signalingSocket?.readyState !== WebSocket.OPEN) return;
    this.signalingSocket.send(JSON.stringify({
      type: "read-receipt",
      to: peerId,
      messageId,
      readAt: new Date().toISOString()
    }));
  }

  sendGroupReadReceipt(groupId, peerId, messageId) {
    if (!groupId || !peerId || !messageId || this.signalingSocket?.readyState !== WebSocket.OPEN) return;
    this.signalingSocket.send(JSON.stringify({
      type: "read-receipt",
      groupId,
      to: peerId,
      messageId,
      readAt: new Date().toISOString()
    }));
  }

  async sendReaction({ to, groupId, messageId, emoji, active = true, publicKeyJwk }) {
    if (!messageId || !emoji || this.signalingSocket?.readyState !== WebSocket.OPEN) return;
    const directPublicKey = to ? await this.publicKeyForPeer(to, publicKeyJwk) : null;
    if (to && directPublicKey) {
      const relayKey = await this.getRelayKey(to, directPublicKey);
      this.signalingSocket.send(JSON.stringify({
        type: "direct-message",
        to,
        messageId: crypto.randomUUID(),
        encrypted: await encryptText(relayKey, serializeChatPayload({
          kind: "reaction",
          reactionMessageId: messageId,
          emoji,
          reactionActive: active
        })),
        sentAt: new Date().toISOString()
      }));
      return;
    }
    if (to) throw new Error("That contact needs to open Bypassium once before reactions can be sent.");
  }

  async sendGroupReaction(group, contacts, messageId, emoji, active = true) {
    if (!group?.id || !messageId || !emoji || this.signalingSocket?.readyState !== WebSocket.OPEN) return;
    const recipientTasks = (group.members || []).map(async (memberId) => {
      if (memberId === this.identity.id) return null;
      const contact = contacts.find((item) => item.id === memberId);
      const publicKeyJwk = await this.publicKeyForPeer(memberId, contact?.publicKeyJwk);
      if (!publicKeyJwk) return null;
      const relayKey = await this.getRelayKey(memberId, publicKeyJwk);
      return {
        to: memberId,
        encrypted: await encryptText(relayKey, serializeChatPayload({
          kind: "reaction",
          reactionMessageId: messageId,
          emoji,
          reactionActive: active
        }))
      };
    });
    const recipients = (await Promise.all(recipientTasks)).filter(Boolean);
    if (!recipients.length) throw new Error("No group members are ready to receive reactions yet.");
    if (recipients.length) {
      const baseCommand = {
        type: "group-message",
        groupId: group.id,
        messageId: crypto.randomUUID(),
        sentAt: new Date().toISOString()
      };
      for (const batch of chunkRecipientsForRelay(baseCommand, recipients)) {
        this.signalingSocket.send(JSON.stringify({ ...baseCommand, recipients: batch }));
      }
    }
  }

  emitStatus(message) {
    this.onStatus?.(message);
  }

  waitForPublicKey(peerId) {
    if (this.knownPublicKeys.has(peerId)) return Promise.resolve(this.knownPublicKeys.get(peerId));
    return new Promise((resolve) => {
      const timeout = setTimeout(() => {
        this.publicKeyWaiters.delete(peerId);
        resolve(null);
      }, 2500);
      this.publicKeyWaiters.set(peerId, (publicKeyJwk) => {
        clearTimeout(timeout);
        this.publicKeyWaiters.delete(peerId);
        resolve(publicKeyJwk);
      });
    });
  }

  resolvePublicKeyWaiter(peerId, publicKeyJwk) {
    this.knownPublicKeys.set(peerId, publicKeyJwk);
    const waiter = this.publicKeyWaiters.get(peerId);
    if (waiter) waiter(publicKeyJwk);
  }

  async publicKeyForPeer(peerId, fallbackPublicKey = null) {
    if (fallbackPublicKey) {
      this.knownPublicKeys.set(peerId, fallbackPublicKey);
      return fallbackPublicKey;
    }
    if (this.knownPublicKeys.has(peerId)) return this.knownPublicKeys.get(peerId);
    this.watchContacts([peerId]);
    return this.waitForPublicKey(peerId);
  }

  async getRelayKey(peerId, publicKeyJwk) {
    const cacheKey = `${peerId}:${JSON.stringify(publicKeyJwk)}`;
    if (!this.relayKeyCache.has(cacheKey)) {
      this.relayKeyCache.set(cacheKey, deriveSharedAesKey(this.identity.privateKeyJwk, publicKeyJwk));
    }
    return this.relayKeyCache.get(cacheKey);
  }

  scheduleReconnect() {
    if (this.reconnectTimer || !this.signalingUrl) return;
    this.reconnectTimer = setTimeout(async () => {
      this.reconnectTimer = null;
      try {
        await this.openSignalingSocket(this.signalingUrl);
      } catch (error) {
        this.emitStatus(`Reconnecting to message server failed: ${error.message}`);
        this.scheduleReconnect();
      }
    }, 2200);
  }
}

function chunkRecipientsForRelay(baseCommand, recipients) {
  const batches = [];
  let current = [];
  for (const recipient of recipients) {
    const candidate = [...current, recipient];
    const size = JSON.stringify({ ...baseCommand, recipients: candidate }).length;
    if (current.length && size > MAX_RELAY_COMMAND_CHARS) {
      batches.push(current);
      current = [recipient];
    } else {
      current = candidate;
    }
  }
  if (current.length) batches.push(current);
  return batches;
}

function serializeChatPayload(message) {
  if (typeof message === "string") return message;
  return JSON.stringify({
    version: 2,
    kind: message.kind || "message",
    text: message.text || "",
    attachment: message.attachment || null,
    replyTo: message.replyTo || null,
    presentation: serializeMessagePresentation(message.presentation),
    reactionMessageId: message.reactionMessageId || "",
    emoji: message.emoji || "",
    reactionActive: message.reactionActive !== false
  });
}

function parseChatPayload(payload) {
  try {
    const parsed = JSON.parse(payload);
    if (parsed && typeof parsed === "object" && parsed.version === 2) {
      return {
        kind: parsed.kind || "message",
        text: String(parsed.text || ""),
        attachment: parsed.attachment || null,
        replyTo: parsed.replyTo || null,
        presentation: serializeMessagePresentation(parsed.presentation),
        reactionMessageId: String(parsed.reactionMessageId || ""),
        emoji: String(parsed.emoji || ""),
        reactionActive: parsed.reactionActive !== false
      };
    }
  } catch {
    // Older messages were encrypted as plain text, so falling back keeps them readable.
  }
  return { text: payload, attachment: null, replyTo: null, presentation: null };
}

function serializeMessagePresentation(value) {
  if (!value || typeof value !== "object") return null;
  const allowedColors = new Set([
    "blue", "navy", "sky", "cyan", "teal", "emerald", "lime", "violet",
    "purple", "fuchsia", "rose", "pink", "red", "orange", "amber", "slate", "charcoal"
  ]);
  const colorId = allowedColors.has(value.colorId) ? value.colorId : "blue";
  const fontId = Math.min(4, Math.max(0, Number.parseInt(value.fontId, 10) || 0));
  return { colorId, fontId };
}

function outgoingContentMetadata(message = {}) {
  const attachment = message.attachment || null;
  if (!attachment) return { contentType: "text", attachmentBytes: 0 };
  const source = String(attachment.dataUrl || attachment.url || "");
  const bytes = Number(attachment.size || source.length || 0);
  if (String(attachment.type || "").startsWith("audio/") || source.startsWith("data:audio/")) {
    return { contentType: "voice", attachmentBytes: bytes };
  }
  if (attachment.type === "image/gif" || source.includes("image/gif")) {
    return { contentType: "gif", attachmentBytes: bytes };
  }
  return { contentType: "image", attachmentBytes: bytes };
}

function assertContentAllowed(config = {}, message = {}) {
  const metadata = outgoingContentMetadata(message);
  if (config.readOnlyMode) throw new Error("Bypassium is temporarily read-only.");
  if (config.messagingEnabled === false) throw new Error("Messaging is temporarily disabled.");
  if (metadata.contentType === "voice" && config.voiceNotesEnabled === false) {
    throw new Error("Voice notes are temporarily disabled.");
  }
  if (metadata.contentType !== "text" && config.attachmentsEnabled === false) {
    throw new Error("Attachments are temporarily disabled.");
  }
  if (config.maxAttachmentBytes && metadata.attachmentBytes > Number(config.maxAttachmentBytes)) {
    throw new Error("That attachment exceeds the current server limit.");
  }
}

// Collects browser-visible networking capabilities for the relay-only design.
export async function collectNetworkInfo() {
  const info = [];
  info.push({ label: "Message transport", value: "Encrypted WebSocket relay" });
  info.push({ label: "Offline inbox", value: "Supported when the message server is online" });
  info.push({ label: "Notifications", value: "Notification" in window ? Notification.permission : "Unavailable" });
  info.push({ label: "Local storage", value: chrome.storage?.local ? "Chrome storage.local available" : "Unavailable" });
  info.push({
    label: "ID recovery",
    value: chrome.storage?.sync
      ? "6-digit ID saved through Chrome Sync when the signed-in profile allows it"
      : "Chrome Sync unavailable in this browser profile"
  });
  info.push({
    label: "Policy note",
    value: "Messages are encrypted before they reach the server. Offline messages are held temporarily and deleted after delivery."
  });
  return info;
}
