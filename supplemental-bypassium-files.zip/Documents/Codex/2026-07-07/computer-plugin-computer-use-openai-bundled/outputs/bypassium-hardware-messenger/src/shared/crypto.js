import { base64UrlToBuffer, bufferToBase64Url } from "./identity.js";

// Imports a stored private ECDH key.
export async function importPrivateKey(jwk) {
  return crypto.subtle.importKey("jwk", jwk, { name: "ECDH", namedCurve: "P-256" }, false, ["deriveKey"]);
}

// Imports a peer public ECDH key.
export async function importPublicKey(jwk) {
  return crypto.subtle.importKey("jwk", jwk, { name: "ECDH", namedCurve: "P-256" }, false, []);
}

// Derives an AES-GCM key used to encrypt messages in transit.
export async function deriveSharedAesKey(privateKeyJwk, peerPublicKeyJwk) {
  const privateKey = await importPrivateKey(privateKeyJwk);
  const publicKey = await importPublicKey(peerPublicKeyJwk);
  return crypto.subtle.deriveKey(
    { name: "ECDH", public: publicKey },
    privateKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

// Encrypts plaintext to a compact JSON-safe payload.
export async function encryptText(key, plaintext) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encoded = new TextEncoder().encode(plaintext);
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, encoded);
  return {
    iv: bufferToBase64Url(iv.buffer),
    ciphertext: bufferToBase64Url(ciphertext)
  };
}

// Decrypts a payload produced by encryptText.
export async function decryptText(key, payload) {
  const iv = new Uint8Array(base64UrlToBuffer(payload.iv));
  const ciphertext = base64UrlToBuffer(payload.ciphertext);
  const plaintext = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, ciphertext);
  return new TextDecoder().decode(plaintext);
}
