const DEFAULT_STATE = {
  identity: null,
  contacts: [],
  groups: [],
  conversations: {},
  groupConversations: {},
  settings: {
    theme: "system",
    displayName: "Local User",
    profilePicture: "",
    presence: "online",
    quickAddVisible: true,
    palette: {
      accent: "#2563eb",
      accent2: "#0f766e",
      background: "#f6f7fb",
      custom: false
    },
    messageStyle: {
      colorId: "blue",
      fontId: 0
    },
    onboardingSeen: false
  },
  diagnostics: {
    sent: 0,
    received: 0,
    failures: [],
    lastLatencyMs: null,
    currentConnectionType: "none",
    encryptionStatus: "not connected",
    peerConnectionStatus: "idle"
  }
};

const STATE_SCHEMA_VERSION = 2;
const STATE_SCHEMA_KEY = "stateSchemaVersion";
const UPDATE_BACKUP_KEY = "updateSafetyBackup";
const PERSISTED_STATE_KEYS = [
  "identity",
  "contacts",
  "groups",
  "conversations",
  "groupConversations",
  "settings",
  "diagnostics"
];

let mutationQueue = Promise.resolve();

// Reads all persisted application state from chrome.storage.local.
export async function loadState() {
  const stored = await chrome.storage.local.get({
    ...DEFAULT_STATE,
    [STATE_SCHEMA_KEY]: 0,
    [UPDATE_BACKUP_KEY]: null
  });
  const recovery = recoverStateFromUpdateBackup(stored);
  const state = migrateState(recovery.state, Number(stored[STATE_SCHEMA_KEY] || 0));
  const normalized = normalizeState(state);
  if (recovery.recovered || stored[STATE_SCHEMA_KEY] !== STATE_SCHEMA_VERSION) {
    await chrome.storage.local.set({
      ...normalized,
      [STATE_SCHEMA_KEY]: STATE_SCHEMA_VERSION
    });
  }
  return normalized;
}

// Captures one complete local snapshot before a Chrome extension update is used.
export async function createUpdateSafetyBackup(previousVersion = "") {
  const stored = await chrome.storage.local.get(DEFAULT_STATE);
  if (!hasMeaningfulState(stored)) return false;
  const data = {};
  for (const key of PERSISTED_STATE_KEYS) data[key] = stored[key];
  await chrome.storage.local.set({
    [UPDATE_BACKUP_KEY]: {
      schemaVersion: STATE_SCHEMA_VERSION,
      extensionVersion: String(previousVersion || ""),
      capturedAt: new Date().toISOString(),
      data
    }
  });
  return true;
}

// Merges a partial state patch into chrome.storage.local.
export async function saveState(patch) {
  return mutateState(() => patch);
}

// Persists a single settings patch without disturbing other settings.
export async function saveSettings(settingsPatch) {
  return mutateState((state) => ({
    settings: {
      ...state.settings,
      ...settingsPatch,
      palette: {
        ...state.settings.palette,
        ...(settingsPatch.palette || {})
      }
    }
  }));
}

// Creates or updates a contact that is visible only on this device.
export async function upsertContact(contact) {
  return mutateState((state) => {
    const existing = state.contacts.find((item) => item.id === contact.id) || {};
    const contacts = state.contacts.filter((item) => item.id !== contact.id);
    contacts.push({
      ...existing,
      id: contact.id,
      name: contact.name || existing.name || contact.id.slice(0, 12),
      nameEdited: Object.prototype.hasOwnProperty.call(contact, "nameEdited") ? contact.nameEdited : existing.nameEdited || false,
      avatar: contact.avatar || existing.avatar || "",
      status: contact.status || existing.status || "offline",
      publicKeyJwk: contact.publicKeyJwk || existing.publicKeyJwk || null,
      accepted: Object.prototype.hasOwnProperty.call(contact, "accepted") ? contact.accepted : existing.accepted ?? true,
      blocked: Object.prototype.hasOwnProperty.call(contact, "blocked") ? contact.blocked : existing.blocked || false,
      notifications: Object.prototype.hasOwnProperty.call(contact, "notifications") ? contact.notifications : existing.notifications ?? true,
      pinned: Object.prototype.hasOwnProperty.call(contact, "pinned") ? contact.pinned : existing.pinned || false,
      chatBackground: contact.chatBackground || existing.chatBackground || "",
      unreadCount: Object.prototype.hasOwnProperty.call(contact, "unreadCount") ? contact.unreadCount : existing.unreadCount || 0,
      createdAt: contact.createdAt || existing.createdAt || new Date().toISOString()
    });
    return { patch: { contacts }, result: contacts };
  });
}

// Applies a focused local-only patch to an existing contact.
export async function updateContact(contactId, patch) {
  return mutateState((state) => {
    const contacts = state.contacts.map((contact) => (
      contact.id === contactId ? { ...contact, ...patch } : contact
    ));
    return { patch: { contacts }, result: contacts };
  });
}

// Creates or updates a locally visible group chat.
export async function upsertGroup(group) {
  return mutateState((state) => {
    const existing = state.groups.find((item) => item.id === group.id) || {};
    const groups = state.groups.filter((item) => item.id !== group.id);
    groups.push({
      ...existing,
      id: group.id,
      name: group.name || existing.name || "Group chat",
      avatar: group.avatar || existing.avatar || "",
      members: Array.isArray(group.members) ? group.members : existing.members || [],
      ownerId: group.ownerId || existing.ownerId || group.createdBy || existing.createdBy || "",
      admins: Array.isArray(group.admins) ? group.admins : existing.admins || [],
      notifications: Object.prototype.hasOwnProperty.call(group, "notifications") ? group.notifications : existing.notifications ?? true,
      pinned: Object.prototype.hasOwnProperty.call(group, "pinned") ? group.pinned : existing.pinned || false,
      chatBackground: group.chatBackground || existing.chatBackground || "",
      unreadCount: Object.prototype.hasOwnProperty.call(group, "unreadCount") ? group.unreadCount : existing.unreadCount || 0,
      updatedAt: group.updatedAt || existing.updatedAt || new Date().toISOString()
    });
    return { patch: { groups }, result: groups };
  });
}

// Applies a focused local-only patch to an existing group.
export async function updateGroup(groupId, patch) {
  return mutateState((state) => {
    const groups = state.groups.map((group) => (
      group.id === groupId ? { ...group, ...patch } : group
    ));
    return { patch: { groups }, result: groups };
  });
}

// Removes a group from this device and clears its local message history.
export async function deleteGroup(groupId) {
  return mutateState((state) => {
    const groups = state.groups.filter((group) => group.id !== groupId);
    const groupConversations = { ...state.groupConversations };
    delete groupConversations[groupId];
    return { patch: { groups, groupConversations }, result: groups };
  });
}

// Deletes a contact and its local conversation history from this device.
export async function deleteContact(contactId) {
  return mutateState((state) => {
    const contacts = state.contacts.filter((contact) => contact.id !== contactId);
    const conversations = { ...state.conversations };
    delete conversations[contactId];
    return { patch: { contacts, conversations }, result: contacts };
  });
}

// Stores a message inside the local conversation history for a contact.
export async function appendMessage(contactId, message) {
  return mutateState((state) => {
    const conversation = state.conversations[contactId] || [];
    const inserted = !message.messageId || !conversation.some((item) => item.messageId === message.messageId);
    if (!inserted) return { patch: {}, result: { conversation, inserted: false } };
    const nextConversation = [...conversation, message];
    const conversations = {
      ...state.conversations,
      [contactId]: nextConversation
    };
    return { patch: { conversations }, result: { conversation: nextConversation, inserted: true } };
  });
}

// Marks a locally stored outbound direct message as read by the recipient.
export async function markMessageRead(contactId, messageId, readAt) {
  return mutateState((state) => {
    const conversation = state.conversations[contactId] || [];
    const nextConversation = conversation.map((message) => (
      message.messageId === messageId ? { ...message, readAt } : message
    ));
    const conversations = {
      ...state.conversations,
      [contactId]: nextConversation
    };
    return { patch: { conversations }, result: nextConversation };
  });
}

// Records which inbound direct-message read receipts have already been handed to the server.
export async function markDirectReadReceiptsSent(contactId, messageIds) {
  const ids = new Set(messageIds);
  return mutateState((state) => {
    const conversation = state.conversations[contactId] || [];
    const nextConversation = conversation.map((message) => (
      ids.has(message.messageId) ? { ...message, readReceiptSent: true } : message
    ));
    return { patch: { conversations: { ...state.conversations, [contactId]: nextConversation } }, result: nextConversation };
  });
}

// Updates the server delivery state for one outbound direct message.
export async function updateMessageDelivery(contactId, messageId, status, updatedAt = new Date().toISOString()) {
  return mutateState((state) => {
    const conversation = state.conversations[contactId] || [];
    const nextConversation = conversation.map((message) => (
      localMessageKey(message) === messageId
        ? { ...message, deliveryStatus: laterDeliveryStatus(message.deliveryStatus, status), deliveryUpdatedAt: updatedAt }
        : message
    ));
    return {
      patch: { conversations: { ...state.conversations, [contactId]: nextConversation } },
      result: nextConversation
    };
  });
}

// Deletes one direct message from local storage only.
export async function deleteMessage(contactId, messageId) {
  return mutateState((state) => {
    const conversation = state.conversations[contactId] || [];
    const nextConversation = conversation.filter((message) => localMessageKey(message) !== messageId);
    const conversations = {
      ...state.conversations,
      [contactId]: nextConversation
    };
    return { patch: { conversations }, result: nextConversation };
  });
}

// Adds or replaces this device's local emoji reaction on a direct message.
export async function reactToMessage(contactId, messageId, emoji, reactorId = "local", active = true) {
  return mutateState((state) => {
    const conversation = state.conversations[contactId] || [];
    const nextConversation = conversation.map((message) => (
      localMessageKey(message) === messageId ? withReaction(message, emoji, reactorId, active) : message
    ));
    const conversations = {
      ...state.conversations,
      [contactId]: nextConversation
    };
    return { patch: { conversations }, result: nextConversation };
  });
}

// Stores a group message locally and ignores repeated server retries.
export async function appendGroupMessage(groupId, message) {
  return mutateState((state) => {
    const conversation = state.groupConversations[groupId] || [];
    const inserted = !message.messageId || !conversation.some((item) => item.messageId === message.messageId && item.senderId === message.senderId);
    if (!inserted) return { patch: {}, result: { conversation, inserted: false } };
    const nextConversation = [...conversation, message];
    const groupConversations = {
      ...state.groupConversations,
      [groupId]: nextConversation
    };
    return { patch: { groupConversations }, result: { conversation: nextConversation, inserted: true } };
  });
}

// Tracks per-recipient delivery progress for one outbound group message.
export async function updateGroupMessageDelivery(groupId, messageId, peerId, status, recipientCount = 0, updatedAt = new Date().toISOString()) {
  return mutateState((state) => {
    const conversation = state.groupConversations[groupId] || [];
    const nextConversation = conversation.map((message) => {
      if (localMessageKey(message) !== messageId) return message;
      const deliveryByPeer = { ...(message.deliveryByPeer || {}) };
      if (peerId) deliveryByPeer[peerId] = laterDeliveryStatus(deliveryByPeer[peerId], status);
      return {
        ...message,
        deliveryStatus: laterDeliveryStatus(message.deliveryStatus, status),
        deliveryByPeer,
        deliveryRecipientCount: Math.max(Number(message.deliveryRecipientCount || 0), Number(recipientCount || 0)),
        deliveryUpdatedAt: updatedAt
      };
    });
    return {
      patch: { groupConversations: { ...state.groupConversations, [groupId]: nextConversation } },
      result: nextConversation
    };
  });
}

// Records which inbound group-message read receipts have already been handed to the server.
export async function markGroupReadReceiptsSent(groupId, messageIds) {
  const ids = new Set(messageIds);
  return mutateState((state) => {
    const conversation = state.groupConversations[groupId] || [];
    const nextConversation = conversation.map((message) => (
      ids.has(message.messageId) ? { ...message, readReceiptSent: true } : message
    ));
    return { patch: { groupConversations: { ...state.groupConversations, [groupId]: nextConversation } }, result: nextConversation };
  });
}

// Deletes one group message from local storage only.
export async function deleteGroupMessage(groupId, messageId) {
  return mutateState((state) => {
    const conversation = state.groupConversations[groupId] || [];
    const nextConversation = conversation.filter((message) => localMessageKey(message) !== messageId);
    const groupConversations = {
      ...state.groupConversations,
      [groupId]: nextConversation
    };
    return { patch: { groupConversations }, result: nextConversation };
  });
}

// Adds or replaces this device's local emoji reaction on a group message.
export async function reactToGroupMessage(groupId, messageId, emoji, reactorId = "local", active = true) {
  return mutateState((state) => {
    const conversation = state.groupConversations[groupId] || [];
    const nextConversation = conversation.map((message) => (
      localMessageKey(message) === messageId ? withReaction(message, emoji, reactorId, active) : message
    ));
    const groupConversations = {
      ...state.groupConversations,
      [groupId]: nextConversation
    };
    return { patch: { groupConversations }, result: nextConversation };
  });
}

// Updates diagnostic fields and appends recent failure messages.
export async function updateDiagnostics(patch) {
  return mutateState((state) => {
    const failures = patch.failure
      ? [...state.diagnostics.failures.slice(-19), `${new Date().toLocaleTimeString()}: ${patch.failure}`]
      : state.diagnostics.failures;

    const diagnostics = {
      ...state.diagnostics,
      ...patch,
      failures
    };
    delete diagnostics.failure;
    return { patch: { diagnostics }, result: diagnostics };
  });
}

// Clears counters while preserving current connection state.
export async function clearMessageCounts() {
  return mutateState((state) => ({
    diagnostics: {
      ...state.diagnostics,
      sent: 0,
      received: 0,
      failures: []
    }
  }));
}

function localMessageKey(message) {
  return message.messageId || message.localId || `${message.direction}:${message.sentAt}:${message.text || ""}`;
}

function withReaction(message, emoji, reactorId, active) {
  const reactions = { ...(message.reactions || {}) };
  const reactors = new Set(Array.isArray(reactions[emoji]) ? reactions[emoji] : []);
  if (active) reactors.add(reactorId);
  else reactors.delete(reactorId);
  if (reactors.size) reactions[emoji] = [...reactors];
  else delete reactions[emoji];
  const next = { ...message, reactions };
  delete next.reaction;
  return next;
}

function laterDeliveryStatus(current = "queued", incoming = "queued") {
  const rank = { queued: 0, sent: 1, delivered: 2, read: 3, failed: 4 };
  const currentStatus = Object.prototype.hasOwnProperty.call(rank, current) ? current : "queued";
  const incomingStatus = Object.prototype.hasOwnProperty.call(rank, incoming) ? incoming : currentStatus;
  return rank[incomingStatus] >= rank[currentStatus] ? incomingStatus : currentStatus;
}

async function mutateState(mutator) {
  const run = mutationQueue.catch(() => undefined).then(async () => {
    const state = await loadState();
    const outcome = await mutator(state);
    const isEnvelope = outcome && typeof outcome === "object" && Object.prototype.hasOwnProperty.call(outcome, "patch");
    const patch = isEnvelope ? outcome.patch : outcome;
    const result = isEnvelope ? outcome.result : undefined;
    if (patch && Object.keys(patch).length) {
      await chrome.storage.local.set({
        ...normalizeState({ ...state, ...patch }),
        [STATE_SCHEMA_KEY]: STATE_SCHEMA_VERSION
      });
    }
    return result === undefined ? normalizeState({ ...state, ...(patch || {}) }) : result;
  });
  mutationQueue = run.then(() => undefined, () => undefined);
  return run;
}

function normalizeState(stored = {}) {
  const settings = {
    ...DEFAULT_STATE.settings,
    ...(stored.settings || {}),
    palette: {
      ...DEFAULT_STATE.settings.palette,
      ...(stored.settings?.palette || {})
    },
    messageStyle: {
      ...DEFAULT_STATE.settings.messageStyle,
      ...(stored.settings?.messageStyle || {})
    }
  };
  return {
    ...DEFAULT_STATE,
    ...stored,
    contacts: Array.isArray(stored.contacts) ? stored.contacts : [],
    groups: Array.isArray(stored.groups) ? stored.groups : [],
    conversations: stored.conversations && typeof stored.conversations === "object" ? stored.conversations : {},
    groupConversations: stored.groupConversations && typeof stored.groupConversations === "object" ? stored.groupConversations : {},
    settings,
    diagnostics: { ...DEFAULT_STATE.diagnostics, ...(stored.diagnostics || {}) }
  };
}

function migrateState(state, schemaVersion) {
  if (schemaVersion >= STATE_SCHEMA_VERSION) return state;
  const groups = Array.isArray(state.groups)
    ? state.groups.map((group) => {
      const ownerId = group.ownerId || group.createdBy || group.members?.[0] || "";
      return {
        ...group,
        ownerId,
        admins: Array.isArray(group.admins) ? group.admins : ownerId ? [ownerId] : []
      };
    })
    : [];
  return {
    ...state,
    contacts: Array.isArray(state.contacts) ? state.contacts : [],
    groups,
    conversations: state.conversations && typeof state.conversations === "object" ? state.conversations : {},
    groupConversations: state.groupConversations && typeof state.groupConversations === "object" ? state.groupConversations : {}
  };
}

function recoverStateFromUpdateBackup(stored) {
  if (hasValidIdentity(stored.identity)) return { state: stored, recovered: false };
  const backup = stored[UPDATE_BACKUP_KEY]?.data;
  if (!backup || !hasValidIdentity(backup.identity)) return { state: stored, recovered: false };
  return {
    state: {
      ...stored,
      ...backup
    },
    recovered: true
  };
}

function hasMeaningfulState(state = {}) {
  return hasValidIdentity(state.identity)
    || (Array.isArray(state.contacts) && state.contacts.length > 0)
    || (Array.isArray(state.groups) && state.groups.length > 0)
    || Object.keys(state.conversations || {}).length > 0
    || Object.keys(state.groupConversations || {}).length > 0;
}

function hasValidIdentity(identity) {
  return Boolean(
    identity
    && /^\d{6}$/.test(String(identity.id || ""))
    && identity.publicKeyJwk
    && identity.privateKeyJwk
  );
}
