import { createUpdateSafetyBackup } from "../shared/storage.js";

const OFFSCREEN_RECORDER_PATH = "src/offscreen/recorder.html";
const MICROPHONE_PERMISSION_PATH = "src/permissions/microphone.html";
let creatingOffscreenRecorder = null;

// Opens the persistent side panel when the toolbar button is clicked.
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "update") {
    try {
      await createUpdateSafetyBackup(details.previousVersion);
    } catch (error) {
      console.error("Could not create update safety backup:", error);
    }
  }

  if (chrome.sidePanel?.setPanelBehavior) {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  }
});

// Displays local notifications requested by the side panel.
chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "notify") return;

  chrome.notifications.create({
    type: "basic",
    iconUrl: chrome.runtime.getURL("src/assets/icon-128.png"),
    title: message.title || "Bypassium Messenger",
    message: message.body || "New message"
  });
});

// Creates Chrome's hidden USER_MEDIA document before forwarding recorder commands.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target !== "voice-recorder-service") return;

  (async () => {
    if (message.type === "voice-recorder-request-permission") {
      await chrome.windows.create({
        url: chrome.runtime.getURL(MICROPHONE_PERMISSION_PATH),
        type: "popup",
        width: 420,
        height: 520,
        focused: true
      });
      sendResponse({ ok: true });
      return;
    }

    await ensureOffscreenRecorder();
    await chrome.runtime.sendMessage({
      ...message,
      target: "voice-recorder-offscreen"
    });
    sendResponse({ ok: true });
  })().catch((error) => {
    sendResponse({ ok: false, error: error.message || "Voice recorder could not start." });
  });

  return true;
});

async function ensureOffscreenRecorder() {
  const documentUrl = chrome.runtime.getURL(OFFSCREEN_RECORDER_PATH);
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [documentUrl]
  });
  if (contexts.length) return;

  if (!creatingOffscreenRecorder) {
    creatingOffscreenRecorder = chrome.offscreen.createDocument({
      url: OFFSCREEN_RECORDER_PATH,
      reasons: ["USER_MEDIA"],
      justification: "Record a voice note only after the user presses the microphone button."
    }).finally(() => {
      creatingOffscreenRecorder = null;
    });
  }
  await creatingOffscreenRecorder;
}
