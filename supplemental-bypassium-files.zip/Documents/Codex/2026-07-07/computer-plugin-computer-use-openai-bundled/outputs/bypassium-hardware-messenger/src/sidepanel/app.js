import { ensureIdentity, isValidBypassiumId } from "../shared/identity.js";
import {
  appendGroupMessage,
  appendMessage,
  clearMessageCounts,
  deleteContact,
  deleteGroup,
  deleteGroupMessage,
  deleteMessage,
  loadState,
  markDirectReadReceiptsSent,
  markGroupReadReceiptsSent,
  markMessageRead,
  reactToGroupMessage,
  reactToMessage,
  saveSettings,
  updateContact,
  updateGroup,
  updateGroupMessageDelivery,
  updateMessageDelivery,
  upsertGroup,
  upsertContact,
  updateDiagnostics
} from "../shared/storage.js";
import { collectNetworkInfo, PeerMessenger } from "../shared/webrtc.js";

const SIGNALING_SERVER_URL = "wss://bypassium-signaling-server.onrender.com";
const HARDWARE_BRIDGE_URL = "ws://127.0.0.1:8787";
const THEME_PRESETS = {
  classic: { theme: "light", accent: "#2563eb", accent2: "#0f766e", background: "#f6f7fb" },
  midnight: { theme: "dark", accent: "#60a5fa", accent2: "#2dd4bf", background: "#0b1020" },
  cherry: { theme: "light", accent: "#e11d48", accent2: "#7c3aed", background: "#fff1f2" },
  forest: { theme: "light", accent: "#16a34a", accent2: "#0891b2", background: "#f0fdf4" },
  sunset: { theme: "light", accent: "#ea580c", accent2: "#db2777", background: "#fff7ed" },
  obsidian: { theme: "dark", accent: "#a3e635", accent2: "#22d3ee", background: "#09090b" },
  deepsea: { theme: "dark", accent: "#38bdf8", accent2: "#14b8a6", background: "#061826" },
  plum: { theme: "dark", accent: "#c084fc", accent2: "#f472b6", background: "#1a1026" },
  graphite: { theme: "dark", accent: "#f8fafc", accent2: "#94a3b8", background: "#171717" },
  ember: { theme: "dark", accent: "#fb923c", accent2: "#ef4444", background: "#1c0d08" },
  aurora: { theme: "dark", accent: "#34d399", accent2: "#818cf8", background: "#071a17" }
};
const MESSAGE_COLORS = {
  blue: "#2563eb",
  navy: "#1e3a8a",
  sky: "#0284c7",
  cyan: "#0891b2",
  teal: "#0f766e",
  emerald: "#047857",
  lime: "#84cc16",
  violet: "#7c3aed",
  purple: "#9333ea",
  fuchsia: "#c026d3",
  rose: "#e11d48",
  pink: "#ec4899",
  red: "#dc2626",
  orange: "#ea580c",
  amber: "#fbbf24",
  slate: "#334155",
  charcoal: "#111827"
};
const MESSAGE_FONTS = [
  'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  'ui-rounded, "Arial Rounded MT Bold", "Trebuchet MS", sans-serif',
  'Georgia, "Times New Roman", serif',
  'ui-monospace, "Cascadia Mono", Consolas, monospace',
  '"Trebuchet MS", Verdana, sans-serif'
];

const elements = {
  appShell: document.querySelector("#app"),
  messageButton: document.querySelector(".message-button"),
  messageTabs: document.querySelectorAll("[data-message-tab]"),
  ownId: document.querySelector("#ownId"),
  identityShort: document.querySelector("#identityShort"),
  contacts: document.querySelector("#contacts"),
  contactDirectoryTabs: document.querySelectorAll("[data-contact-directory-tab]"),
  savedContactsPanel: document.querySelector("#savedContactsPanel"),
  quickAddPanel: document.querySelector("#quickAddPanel"),
  contactSearch: document.querySelector("#contactSearch"),
  quickAddSearch: document.querySelector("#quickAddSearch"),
  quickAddVisibility: document.querySelector("#quickAddVisibility"),
  refreshQuickAdd: document.querySelector("#refreshQuickAdd"),
  quickAddList: document.querySelector("#quickAddList"),
  loadMoreQuickAdd: document.querySelector("#loadMoreQuickAdd"),
  messageContacts: document.querySelector("#messageContacts"),
  contactPickerScreen: document.querySelector("#contactPickerScreen"),
  conversationScreen: document.querySelector("#conversationScreen"),
  backToContacts: document.querySelector("#backToContacts"),
  reloadMessages: document.querySelector("#reloadMessages"),
  reloadAllMessages: document.querySelector("#reloadAllMessages"),
  toggleMessageSearch: document.querySelector("#toggleMessageSearch"),
  messageSearchBar: document.querySelector("#messageSearchBar"),
  messageSearchInput: document.querySelector("#messageSearchInput"),
  messageSearchCount: document.querySelector("#messageSearchCount"),
  closeMessageSearch: document.querySelector("#closeMessageSearch"),
  addFriendForm: document.querySelector("#addFriendForm"),
  friendId: document.querySelector("#friendId"),
  createGroupForm: document.querySelector("#createGroupForm"),
  groupName: document.querySelector("#groupName"),
  groupPicture: document.querySelector("#groupPicture"),
  groupPicturePreview: document.querySelector("#groupPicturePreview"),
  groupMemberPicker: document.querySelector("#groupMemberPicker"),
  messages: document.querySelector("#messages"),
  newMessagesJump: document.querySelector("#newMessagesJump"),
  messageForm: document.querySelector("#messageForm"),
  messageInput: document.querySelector("#messageInput"),
  attachButton: document.querySelector("#attachButton"),
  voiceNoteButton: document.querySelector("#voiceNoteButton"),
  voiceRecordingBar: document.querySelector("#voiceRecordingBar"),
  voiceRecordingTimer: document.querySelector("#voiceRecordingTimer"),
  cancelVoiceRecording: document.querySelector("#cancelVoiceRecording"),
  finishVoiceRecording: document.querySelector("#finishVoiceRecording"),
  sendMessageButton: document.querySelector("#sendMessageButton"),
  attachmentInput: document.querySelector("#attachmentInput"),
  attachmentPreview: document.querySelector("#attachmentPreview"),
  replyPreview: document.querySelector("#replyPreview"),
  mentionSuggestions: document.querySelector("#mentionSuggestions"),
  activeAvatar: document.querySelector("#activeAvatar"),
  activeName: document.querySelector("#activeName"),
  activeStatus: document.querySelector("#activeStatus"),
  directTabBadge: document.querySelector("#directTabBadge"),
  groupTabBadge: document.querySelector("#groupTabBadge"),
  openMultiSend: document.querySelector("#openMultiSend"),
  multiSendDialog: document.querySelector("#multiSendDialog"),
  multiSendForm: document.querySelector("#multiSendForm"),
  multiSendRecipients: document.querySelector("#multiSendRecipients"),
  multiSendMessage: document.querySelector("#multiSendMessage"),
  multiSendAttachmentInput: document.querySelector("#multiSendAttachmentInput"),
  multiSendAttach: document.querySelector("#multiSendAttach"),
  multiSendVoice: document.querySelector("#multiSendVoice"),
  multiSendAttachmentPreview: document.querySelector("#multiSendAttachmentPreview"),
  multiSendFeedback: document.querySelector("#multiSendFeedback"),
  confirmMultiSend: document.querySelector("#confirmMultiSend"),
  cancelMultiSend: document.querySelector("#cancelMultiSend"),
  presenceToggles: document.querySelectorAll("[data-presence-toggle]"),
  presenceLabels: document.querySelectorAll("[data-presence-label]"),
  blockContact: document.querySelector("#blockContact"),
  networkInfo: document.querySelector("#networkInfo"),
  developerDashboard: document.querySelector("#developerDashboard"),
  diagnosticLog: document.querySelector("#diagnosticLog"),
  themeSelect: document.querySelector("#themeSelect"),
  themePresets: document.querySelector("#themePresets"),
  messageColorPresets: document.querySelector("#messageColorPresets"),
  messageFont: document.querySelector("#messageFont"),
  messageStylePreview: document.querySelector("#messageStylePreview"),
  paletteAccent: document.querySelector("#paletteAccent"),
  paletteAccent2: document.querySelector("#paletteAccent2"),
  paletteBackground: document.querySelector("#paletteBackground"),
  resetPalette: document.querySelector("#resetPalette"),
  localDisplayName: document.querySelector("#localDisplayName"),
  profilePicture: document.querySelector("#profilePicture"),
  profilePreview: document.querySelector("#profilePreview"),
  removeProfilePicture: document.querySelector("#removeProfilePicture"),
  saveProfileSettings: document.querySelector("#saveProfileSettings"),
  supportForm: document.querySelector("#supportForm"),
  supportType: document.querySelector("#supportType"),
  supportMessage: document.querySelector("#supportMessage"),
  supportEvidence: document.querySelector("#supportEvidence"),
  supportFeedback: document.querySelector("#supportFeedback"),
  hardwareBridgeConnect: document.querySelector("#hardwareBridgeConnect"),
  hardwareBridgeSendSnapshot: document.querySelector("#hardwareBridgeSendSnapshot"),
  hardwareBridgeStatus: document.querySelector("#hardwareBridgeStatus"),
  hardwareBridgeLog: document.querySelector("#hardwareBridgeLog"),
  contactDialog: document.querySelector("#contactDialog"),
  contactDialogAvatar: document.querySelector("#contactDialogAvatar"),
  contactDialogName: document.querySelector("#contactDialogName"),
  contactDialogStatus: document.querySelector("#contactDialogStatus"),
  contactDialogCode: document.querySelector("#contactDialogCode"),
  contactMessage: document.querySelector("#contactMessage"),
  contactRename: document.querySelector("#contactRename"),
  contactPin: document.querySelector("#contactPin"),
  contactBlock: document.querySelector("#contactBlock"),
  contactDelete: document.querySelector("#contactDelete"),
  contactNotifications: document.querySelector("#contactNotifications"),
  contactChatBackground: document.querySelector("#contactChatBackground"),
  resetContactChatBackground: document.querySelector("#resetContactChatBackground"),
  quickAddDialog: document.querySelector("#quickAddDialog"),
  quickAddDialogAvatar: document.querySelector("#quickAddDialogAvatar"),
  quickAddDialogName: document.querySelector("#quickAddDialogName"),
  quickAddDialogStatus: document.querySelector("#quickAddDialogStatus"),
  quickAddDialogJoined: document.querySelector("#quickAddDialogJoined"),
  quickAddDialogAdd: document.querySelector("#quickAddDialogAdd"),
  contactChatBackgroundImage: document.querySelector("#contactChatBackgroundImage"),
  syncContactChatBackgroundImage: document.querySelector("#syncContactChatBackgroundImage"),
  removeContactChatBackgroundImage: document.querySelector("#removeContactChatBackgroundImage"),
  profileEditorDialog: document.querySelector("#profileEditorDialog"),
  profileEditorTitle: document.querySelector("#profileEditorTitle"),
  profileEditorDescription: document.querySelector("#profileEditorDescription"),
  profileEditorStage: document.querySelector("#profileEditorStage"),
  profileEditorGuide: document.querySelector("#profileEditorGuide"),
  profileEditorCanvas: document.querySelector("#profileEditorCanvas"),
  profileEditorZoom: document.querySelector("#profileEditorZoom"),
  profileRotateLeft: document.querySelector("#profileRotateLeft"),
  profileRotateRight: document.querySelector("#profileRotateRight"),
  profileEditorReset: document.querySelector("#profileEditorReset"),
  profileEditorApply: document.querySelector("#profileEditorApply"),
  groupDialog: document.querySelector("#groupDialog"),
  groupDialogAvatar: document.querySelector("#groupDialogAvatar"),
  groupDialogName: document.querySelector("#groupDialogName"),
  groupDialogStatus: document.querySelector("#groupDialogStatus"),
  groupDialogRole: document.querySelector("#groupDialogRole"),
  groupMessage: document.querySelector("#groupMessage"),
  groupAddMembers: document.querySelector("#groupAddMembers"),
  groupViewMembers: document.querySelector("#groupViewMembers"),
  groupRename: document.querySelector("#groupRename"),
  groupPin: document.querySelector("#groupPin"),
  groupLeave: document.querySelector("#groupLeave"),
  groupNotifications: document.querySelector("#groupNotifications"),
  groupDialogPicture: document.querySelector("#groupDialogPicture"),
  saveGroupPicture: document.querySelector("#saveGroupPicture"),
  groupChatBackground: document.querySelector("#groupChatBackground"),
  resetGroupChatBackground: document.querySelector("#resetGroupChatBackground"),
  memberPickerDialog: document.querySelector("#memberPickerDialog"),
  addMemberPicker: document.querySelector("#addMemberPicker"),
  confirmAddMembers: document.querySelector("#confirmAddMembers"),
  groupMembersDialog: document.querySelector("#groupMembersDialog"),
  groupMembersList: document.querySelector("#groupMembersList"),
  imageViewerDialog: document.querySelector("#imageViewerDialog"),
  imageViewerImage: document.querySelector("#imageViewerImage"),
  imageDownload: document.querySelector("#imageDownload"),
  toast: document.querySelector("#toast"),
  onboardingDialog: document.querySelector("#onboardingDialog"),
  onboardingSettings: document.querySelector("#onboardingSettings"),
  onboardingDismiss: document.querySelector("#onboardingDismiss")
};

const app = {
  identity: null,
  state: null,
  activeContactId: null,
  activeGroupId: null,
  pendingContactId: null,
  pendingGroupId: null,
  peer: null,
  onboardingTimer: null,
  profileFeedbackTimer: null,
  pendingProfilePicture: null,
  profileEditor: {
    target: "profile",
    contactId: "",
    image: null,
    rotation: 0,
    zoom: 1,
    offsetX: 0,
    offsetY: 0,
    dragging: false,
    pointerX: 0,
    pointerY: 0
  },
  pendingGroupPicture: "",
  pendingCreatedGroup: null,
  connectingContactId: null,
  connectingPromise: null,
  typingByContact: new Map(),
  typingByGroup: new Map(),
  typingTimers: new Map(),
  typingStopTimer: null,
  lastTypingTarget: null,
  selectedAttachment: null,
  multiSendAttachment: null,
  pendingVoiceTarget: "conversation",
  voiceRecording: null,
  voiceRecordingPending: false,
  voicePermissionRequestPending: false,
  replyTo: null,
  messageActionTimer: null,
  messageActionMenu: null,
  emojiPicker: null,
  messagePickerTab: "direct",
  messageSearchQuery: "",
  pendingGroupDialogPicture: "",
  pendingMessageStatuses: new Map(),
  toastTimer: null,
  newMessagesBelow: 0,
  contactDirectoryTab: "contacts",
  contactSearchQuery: "",
  quickAddResults: [],
  quickAddQuery: "",
  quickAddOffset: 0,
  quickAddHasMore: false,
  quickAddLoading: false,
  pendingQuickAddId: null,
  quickAddSearchTimer: null,
  serviceConfig: {},
  hardwareSocket: null,
  hardwareReconnectTimer: null,
  hardwareBridgeLog: []
};

// Bootstraps identity, state, event handlers, and the persistent side-panel UI.
async function init() {
  app.identity = await ensureIdentity();
  app.state = await loadState();
  app.peer = new PeerMessenger({
    identity: app.identity,
    onMessage: receivePeerMessage,
    onGroupMessage: receiveGroupMessage,
    onChatSetting: receiveChatSetting,
    onQuickAddResults: receiveQuickAddResults,
    onAnnouncement: handleServiceAnnouncement,
    onAdminNotice: handleAdminNotice,
    onServiceConfig: (config) => {
      app.serviceConfig = config || {};
    },
    onStatus: handlePeerStatus,
    onPeerDiscovered: rememberDiscoveredPeer,
    onContactStatuses: updateContactStatuses,
    onProfileUpdated: updateContactProfile,
    onGroupsUpdated: updateGroups,
    onTyping: handleTypingNotice,
    onReadReceipt: handleReadReceipt,
    onReaction: handleReaction,
    onMessageStatus: handleMessageStatus
  });

  elements.ownId.value = app.identity.id;
  elements.identityShort.textContent = app.identity.id.slice(0, 22);
  applyTheme(app.state.settings.theme);
  bindEvents();
  renderAll();
  try {
    await app.peer.connectDirectory(SIGNALING_SERVER_URL, watchedPeerIds());
    app.peer.publishProfile(currentProfilePayload());
    void retryQueuedMessages();
  } catch (error) {
    setStatus(`Saved-contact reconnect is unavailable: ${error.message}`);
  }
  await refreshNetworkInfo();
  await requestNotificationPermission();
  showOnboardingIfNeeded();
}

// Connects UI controls to local-first application behavior.
function bindEvents() {
  document.querySelectorAll("[data-view]").forEach((button) => {
    button.addEventListener("click", () => switchView(button.dataset.view));
  });
  document.querySelectorAll("[data-sidebar]").forEach((button) => {
    button.addEventListener("click", () => switchSidebar(button.dataset.sidebar));
  });

  document.querySelector("#copyOwnId").addEventListener("click", () => navigator.clipboard.writeText(app.identity.id));
  document.querySelector("#refreshNetwork").addEventListener("click", refreshNetworkInfo);
  document.querySelector("#clearDiagnostics").addEventListener("click", async () => {
    await clearMessageCounts();
    app.state = await loadState();
    renderDashboard();
  });

  elements.addFriendForm.addEventListener("submit", addFriend);
  elements.contactDirectoryTabs.forEach((button) => {
    button.addEventListener("click", () => switchContactDirectoryTab(button.dataset.contactDirectoryTab));
  });
  elements.contactSearch.addEventListener("input", () => {
    app.contactSearchQuery = elements.contactSearch.value.trim().toLowerCase();
    renderContacts();
  });
  elements.quickAddSearch.addEventListener("input", scheduleQuickAddSearch);
  elements.quickAddVisibility.addEventListener("change", updateQuickAddVisibility);
  elements.refreshQuickAdd.addEventListener("click", () => requestQuickAdd({ reset: true }));
  elements.loadMoreQuickAdd.addEventListener("click", () => requestQuickAdd({ reset: false }));
  elements.quickAddDialogAdd.addEventListener("click", addPendingQuickAddContact);
  elements.createGroupForm.addEventListener("submit", createGroup);
  elements.groupPicture.addEventListener("change", previewGroupPicture);
  elements.messageForm.addEventListener("submit", sendMessage);
  elements.messageInput.addEventListener("input", handleTypingInput);
  elements.messageInput.addEventListener("input", renderMentionSuggestions);
  elements.messageInput.addEventListener("paste", handleComposerPaste);
  elements.messageForm.addEventListener("drop", handleComposerDrop);
  elements.messageForm.addEventListener("dragover", (event) => event.preventDefault());
  elements.attachButton.addEventListener("click", () => elements.attachmentInput.click());
  elements.voiceNoteButton.addEventListener("click", toggleVoiceRecording);
  elements.cancelVoiceRecording.addEventListener("click", cancelVoiceRecording);
  elements.finishVoiceRecording.addEventListener("click", stopVoiceRecording);
  elements.attachmentInput.addEventListener("change", handleAttachmentPicked);
  elements.messages.addEventListener("click", openAttachmentFromClick);
  elements.messages.addEventListener("scroll", handleMessagesScroll);
  elements.newMessagesJump.addEventListener("click", jumpToNewMessages);
  document.addEventListener("click", (event) => {
    if (!app.messageActionMenu?.contains(event.target)) closeMessageActions();
  });
  elements.backToContacts.addEventListener("click", showContactPicker);
  elements.reloadMessages.addEventListener("click", reloadMessages);
  elements.reloadAllMessages.addEventListener("click", reloadMessages);
  elements.toggleMessageSearch.addEventListener("click", openMessageSearch);
  elements.closeMessageSearch.addEventListener("click", closeMessageSearch);
  elements.messageSearchInput.addEventListener("input", updateMessageSearch);
  elements.openMultiSend.addEventListener("click", openMultiSendDialog);
  elements.multiSendForm.addEventListener("submit", sendMessageIndividually);
  elements.multiSendAttach.addEventListener("click", () => elements.multiSendAttachmentInput.click());
  elements.multiSendAttachmentInput.addEventListener("change", handleMultiSendAttachmentPicked);
  elements.multiSendVoice.addEventListener("click", toggleMultiSendVoiceRecording);
  elements.cancelMultiSend.addEventListener("click", closeMultiSendDialog);
  elements.blockContact.addEventListener("click", toggleBlockCurrentContact);
  elements.presenceToggles.forEach((toggle) => toggle.addEventListener("change", togglePresence));
  chrome.runtime.onMessage.addListener(handleVoiceRecorderMessage);
  window.addEventListener("pagehide", discardVoiceRecording);

  elements.themeSelect.addEventListener("change", async () => {
    await saveSettings({ theme: elements.themeSelect.value });
    app.state = await loadState();
    applyTheme(elements.themeSelect.value);
    renderPalette();
  });
  elements.themePresets.addEventListener("click", applyThemePreset);
  elements.messageColorPresets.addEventListener("click", selectMessageColor);
  elements.messageFont.addEventListener("change", selectMessageFont);
  elements.paletteAccent.addEventListener("input", updatePaletteLive);
  elements.paletteAccent2.addEventListener("input", updatePaletteLive);
  elements.paletteBackground.addEventListener("input", updatePaletteLive);
  elements.resetPalette.addEventListener("click", resetPalette);
  elements.profilePicture.addEventListener("change", previewProfilePicture);
  elements.removeProfilePicture.addEventListener("click", removeProfilePicture);
  elements.saveProfileSettings.addEventListener("click", saveProfileSettings);
  elements.profileEditorZoom.addEventListener("input", updateProfileEditorZoom);
  elements.profileRotateLeft.addEventListener("click", () => rotateProfileEditor(-90));
  elements.profileRotateRight.addEventListener("click", () => rotateProfileEditor(90));
  elements.profileEditorReset.addEventListener("click", resetProfileEditor);
  elements.profileEditorApply.addEventListener("click", applyProfileEditor);
  elements.profileEditorCanvas.addEventListener("pointerdown", startProfileEditorDrag);
  elements.profileEditorCanvas.addEventListener("pointermove", moveProfileEditorDrag);
  elements.profileEditorCanvas.addEventListener("pointerup", stopProfileEditorDrag);
  elements.profileEditorCanvas.addEventListener("pointercancel", stopProfileEditorDrag);
  elements.profileEditorCanvas.addEventListener("wheel", zoomProfileEditorWithWheel, { passive: false });
  elements.profileEditorDialog.addEventListener("close", handleProfileEditorClosed);
  elements.supportForm.addEventListener("submit", submitSupportReport);
  elements.hardwareBridgeConnect.addEventListener("click", connectHardwareBridge);
  elements.hardwareBridgeSendSnapshot.addEventListener("click", sendHardwareSnapshot);
  elements.contactMessage.addEventListener("click", messagePendingContact);
  elements.contactRename.addEventListener("click", renamePendingContact);
  elements.contactPin.addEventListener("click", togglePendingContactPin);
  elements.contactBlock.addEventListener("click", blockPendingContact);
  elements.contactDelete.addEventListener("click", deletePendingContact);
  elements.contactNotifications.addEventListener("change", updatePendingContactNotifications);
  elements.contactChatBackground.addEventListener("input", updatePendingContactBackground);
  elements.resetContactChatBackground.addEventListener("click", resetPendingContactBackground);
  elements.contactChatBackgroundImage.addEventListener("change", previewContactBackgroundImage);
  elements.syncContactChatBackgroundImage.addEventListener("click", previewContactBackgroundImage);
  elements.removeContactChatBackgroundImage.addEventListener("click", removePendingContactBackgroundImage);
  elements.groupMessage.addEventListener("click", messagePendingGroup);
  elements.groupAddMembers.addEventListener("click", addPendingGroupMembers);
  elements.confirmAddMembers.addEventListener("click", confirmAddPendingGroupMembers);
  elements.groupViewMembers.addEventListener("click", viewPendingGroupMembers);
  elements.groupMembersList.addEventListener("click", handleGroupMemberAction);
  elements.groupRename.addEventListener("click", renamePendingGroup);
  elements.groupPin.addEventListener("click", togglePendingGroupPin);
  elements.groupLeave.addEventListener("click", leavePendingGroup);
  elements.groupNotifications.addEventListener("change", updatePendingGroupNotifications);
  elements.groupDialogPicture.addEventListener("change", previewGroupDialogPicture);
  elements.saveGroupPicture.addEventListener("click", savePendingGroupPicture);
  elements.groupChatBackground.addEventListener("input", updatePendingGroupBackground);
  elements.resetGroupChatBackground.addEventListener("click", resetPendingGroupBackground);
  elements.onboardingSettings.addEventListener("click", () => completeOnboarding(true));
  elements.onboardingDismiss.addEventListener("click", () => completeOnboarding(false));
  elements.messageTabs.forEach((button) => {
    button.addEventListener("click", () => switchMessageTab(button.dataset.messageTab));
  });

  document.querySelectorAll("[data-settings-panel]").forEach((button) => {
    button.addEventListener("click", () => switchSettingsPanel(button.dataset.settingsPanel));
  });
}

function switchMessageTab(tabName) {
  app.messagePickerTab = tabName === "groups" ? "groups" : "direct";
  elements.messageTabs.forEach((button) => {
    button.classList.toggle("active", button.dataset.messageTab === app.messagePickerTab);
  });
  renderMessageContacts();
}

// Switches between Messages and Settings views.
function switchView(viewName) {
  if (viewName !== "chat") discardVoiceRecording();
  elements.appShell.classList.remove("sidebar-mode");
  elements.appShell.classList.toggle("settings-mode", viewName === "settings");
  elements.appShell.classList.toggle("messages-mode", viewName === "chat");
  document.querySelectorAll(".rail-button").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === viewName);
  });
  document.querySelectorAll(".sidebar-view").forEach((view) => view.classList.remove("active-sidebar-view"));
  document.querySelectorAll(".view").forEach((view) => view.classList.remove("active-view"));
  document.querySelector(`#${viewName}View`).classList.add("active-view");
  if (viewName === "chat") {
    showContactPicker();
  }
  if (viewName === "settings") {
    switchSettingsPanel("general");
    renderDashboard();
    refreshNetworkInfo();
  }
}

// Switches the left sidebar between Menu, Contacts, and Personalisation.
function switchSidebar(sidebarName) {
  discardVoiceRecording();
  elements.appShell.classList.add("sidebar-mode");
  elements.appShell.classList.remove("messages-mode");
  elements.appShell.classList.remove("settings-mode");
  document.querySelectorAll(".rail-button").forEach((button) => {
    button.classList.toggle("active", button.dataset.sidebar === sidebarName);
  });
  showSidebar(sidebarName);
  document.querySelectorAll(".view").forEach((view) => view.classList.remove("active-view"));
}

function showSidebar(sidebarName) {
  document.querySelectorAll(".sidebar-view").forEach((view) => view.classList.remove("active-sidebar-view"));
  document.querySelector(`#${sidebarName}Sidebar`).classList.add("active-sidebar-view");
}

// Switches between General, Network, and Developer sections inside Settings.
function switchSettingsPanel(panelName) {
  document.querySelectorAll("[data-settings-panel]").forEach((button) => {
    button.classList.toggle("active", button.dataset.settingsPanel === panelName);
  });
  document.querySelectorAll(".settings-panel").forEach((panel) => panel.classList.remove("active-settings-panel"));
  document.querySelector(`#${panelName}SettingsPanel`).classList.add("active-settings-panel");
  if (panelName === "dashboard") renderDashboard();
  if (panelName === "network") refreshNetworkInfo();
}

// Shows a one-time prompt that points new users to profile customization.
function showOnboardingIfNeeded() {
  if (app.state.settings.onboardingSeen) return;
  startOnboardingCooldown();
  elements.onboardingDialog.showModal();
}

// Makes both onboarding choices wait briefly so the message is actually noticed.
function startOnboardingCooldown() {
  let remaining = 3;
  const settingsLabel = "Take me there";
  const dismissLabel = "Not now";

  elements.onboardingSettings.disabled = true;
  elements.onboardingDismiss.disabled = true;

  const renderCooldown = () => {
    elements.onboardingSettings.textContent = `${settingsLabel} (${remaining})`;
    elements.onboardingDismiss.textContent = `${dismissLabel} (${remaining})`;
  };

  clearInterval(app.onboardingTimer);
  renderCooldown();
  app.onboardingTimer = setInterval(() => {
    remaining -= 1;
    if (remaining > 0) {
      renderCooldown();
      return;
    }

    clearInterval(app.onboardingTimer);
    elements.onboardingSettings.textContent = settingsLabel;
    elements.onboardingDismiss.textContent = dismissLabel;
    elements.onboardingSettings.disabled = false;
    elements.onboardingDismiss.disabled = false;
  }, 1000);
}

// Saves the onboarding choice and optionally opens Settings > General.
async function completeOnboarding(openSettings) {
  if (elements.onboardingSettings.disabled || elements.onboardingDismiss.disabled) return;
  await saveSettings({ onboardingSeen: true });
  app.state = await loadState();
  if (openSettings) {
    switchView("settings");
    switchSettingsPanel("general");
  }
}

// Applies dark, light, or system theme without external assets.
function applyTheme(theme) {
  elements.themeSelect.value = theme;
  const resolved = theme === "system" ? (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light") : theme;
  document.documentElement.dataset.theme = resolved;
  applyPalette(app.state?.settings.palette);
}

// Applies saved palette variables on top of the selected light/dark theme.
function applyPalette(palette) {
  const root = document.documentElement;
  const variables = [
    "--accent",
    "--accent-2",
    "--bg",
    "--panel",
    "--panel-2",
    "--line",
    "--text",
    "--muted",
    "--bubble-in",
    "--bubble-out",
    "--rail"
  ];

  if (!palette?.custom) {
    variables.forEach((name) => root.style.removeProperty(name));
    return;
  }

  const colors = buildPaletteVariables(palette);
  Object.entries(colors).forEach(([name, value]) => {
    root.style.setProperty(name, value);
  });
}

// Builds a full UI palette from the three user-picked colors.
function buildPaletteVariables(palette) {
  const bg = normalizeHex(palette.background, "#f6f7fb");
  const accent = normalizeHex(palette.accent, "#2563eb");
  const accent2 = normalizeHex(palette.accent2, "#0f766e");
  const darkBackground = isDarkColor(bg);
  const text = darkBackground ? "#f8fafc" : "#111827";
  const muted = darkBackground ? mixHex(bg, "#ffffff", 0.58) : mixHex(bg, "#111827", 0.52);
  const panel = darkBackground ? mixHex(bg, "#ffffff", 0.08) : mixHex(bg, "#ffffff", 0.78);
  const panel2 = darkBackground ? mixHex(bg, "#ffffff", 0.15) : mixHex(bg, accent, 0.09);
  const line = darkBackground ? mixHex(bg, "#ffffff", 0.24) : mixHex(bg, "#111827", 0.18);

  return {
    "--accent": accent,
    "--accent-2": accent2,
    "--bg": bg,
    "--panel": panel,
    "--panel-2": panel2,
    "--line": line,
    "--text": text,
    "--muted": muted,
    "--bubble-in": darkBackground ? mixHex(bg, "#ffffff", 0.13) : mixHex(bg, accent2, 0.12),
    "--bubble-out": darkBackground ? mixHex(bg, accent, 0.34) : mixHex(bg, accent, 0.18),
    "--rail": darkBackground ? mixHex(bg, "#000000", 0.24) : mixHex(accent2, "#000000", 0.42)
  };
}

function normalizeHex(value, fallback) {
  return /^#[0-9a-f]{6}$/i.test(value) ? value : fallback;
}

function isDarkColor(hex) {
  const { r, g, b } = hexToRgb(hex);
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) < 128;
}

function mixHex(first, second, amount) {
  const a = hexToRgb(first);
  const b = hexToRgb(second);
  const mixed = {
    r: Math.round(a.r + (b.r - a.r) * amount),
    g: Math.round(a.g + (b.g - a.g) * amount),
    b: Math.round(a.b + (b.b - a.b) * amount)
  };
  return rgbToHex(mixed);
}

function hexToRgb(hex) {
  const value = hex.replace("#", "");
  return {
    r: parseInt(value.slice(0, 2), 16),
    g: parseInt(value.slice(2, 4), 16),
    b: parseInt(value.slice(4, 6), 16)
  };
}

function rgbToHex({ r, g, b }) {
  return `#${[r, g, b].map((value) => value.toString(16).padStart(2, "0")).join("")}`;
}

// Renders contacts, conversation, settings, and diagnostics from persisted state.
function renderAll() {
  renderContacts();
  renderQuickAdd();
  renderGroupMemberPicker();
  renderMessageContacts();
  renderMessageButtonUnread();
  renderConversation();
  renderSettings();
  renderPalette();
  renderMessageStyleControls();
  renderPresence();
  renderAttachmentPreview();
  renderReplyPreview();
  renderDashboard();
  renderHardwareBridge();
}

function connectHardwareBridge() {
  if (app.hardwareSocket?.readyState === WebSocket.OPEN || app.hardwareSocket?.readyState === WebSocket.CONNECTING) return;
  renderHardwareBridge("Connecting to hardware bridge...");
  const socket = new WebSocket(HARDWARE_BRIDGE_URL);
  app.hardwareSocket = socket;
  socket.addEventListener("open", () => {
    appendHardwareLog("Connected to hardware bridge.");
    sendHardwareSnapshot();
    renderHardwareBridge();
  });
  socket.addEventListener("message", (event) => {
    handleHardwareCommand(event.data).catch((error) => {
      sendHardwareEvent("error", { message: error.message || "Hardware command failed." });
      appendHardwareLog(`Command failed: ${error.message}`);
    });
  });
  socket.addEventListener("close", () => {
    appendHardwareLog("Hardware bridge disconnected.");
    renderHardwareBridge();
  });
  socket.addEventListener("error", () => {
    appendHardwareLog("Hardware bridge connection error.");
    renderHardwareBridge();
  });
}

function renderHardwareBridge(statusText = "") {
  if (!elements.hardwareBridgeStatus) return;
  const socket = app.hardwareSocket;
  const connected = socket?.readyState === WebSocket.OPEN;
  const connecting = socket?.readyState === WebSocket.CONNECTING;
  elements.hardwareBridgeConnect.disabled = connecting;
  elements.hardwareBridgeConnect.textContent = connected ? "Connected" : connecting ? "Connecting" : "Connect";
  elements.hardwareBridgeSendSnapshot.disabled = !connected;
  elements.hardwareBridgeStatus.textContent = statusText || (connected
    ? `Bridge connected at ${HARDWARE_BRIDGE_URL}.`
    : `Bridge disconnected. Start the bridge, then connect to ${HARDWARE_BRIDGE_URL}.`);
  elements.hardwareBridgeLog.textContent = app.hardwareBridgeLog.slice(-16).join("\n");
}

async function handleHardwareCommand(rawData) {
  const command = parseHardwareCommand(rawData);
  if (!command?.type) return;
  appendHardwareLog(`RX ${command.type}`);
  if (command.type === "hello" || command.type === "snapshot" || command.type === "list-contacts") {
    sendHardwareSnapshot();
    return;
  }
  if (command.type === "select-contact") {
    const contactId = String(command.id || "").trim();
    await selectContactFromHardware(contactId);
    return;
  }
  if (command.type === "send-message") {
    const contactId = String(command.to || app.activeContactId || "").trim();
    const text = String(command.text || "").trim();
    await sendDirectTextFromHardware(contactId, text);
    return;
  }
  if (command.type === "presence") {
    const value = command.value === "invisible" ? "invisible" : "online";
    await saveSettings({ presence: value });
    app.state = await loadState();
    renderPresence();
    app.peer.publishProfile(currentProfilePayload());
    sendHardwareEvent("presence", { value });
    return;
  }
  sendHardwareEvent("error", { message: `Unknown command: ${command.type}` });
}

function parseHardwareCommand(rawData) {
  try {
    return JSON.parse(String(rawData));
  } catch {
    const [type, ...parts] = String(rawData).trim().split("|");
    if (type === "SEND") return { type: "send-message", to: parts[0], text: parts.slice(1).join("|") };
    if (type === "SELECT") return { type: "select-contact", id: parts[0] };
    if (type === "CONTACTS") return { type: "list-contacts" };
    if (type === "STATUS") return { type: "presence", value: parts[0] };
    return { type: String(type || "").toLowerCase() };
  }
}

async function selectContactFromHardware(contactId) {
  const contact = app.state.contacts.find((item) => item.id === contactId);
  if (!contact) {
    sendHardwareEvent("error", { message: `Unknown contact ${contactId}.` });
    return;
  }
  await selectContact(contact.id);
  sendHardwareChatSnapshot(contact.id);
}

async function sendDirectTextFromHardware(contactId, text) {
  if (!text) {
    sendHardwareEvent("error", { message: "Type a message before sending." });
    return;
  }
  const contact = app.state.contacts.find((item) => item.id === contactId);
  if (!contact) {
    sendHardwareEvent("error", { message: `Unknown contact ${contactId}.` });
    return;
  }
  if (contact.blocked) {
    sendHardwareEvent("error", { message: "That contact is blocked." });
    return;
  }
  if (contact.accepted === false) {
    sendHardwareEvent("error", { message: "Add this person back before replying." });
    return;
  }
  try {
    if (!contact.publicKeyJwk && !app.peer.canMessagePeer(contact.id)) {
      app.activeContactId = contact.id;
      await connectCurrentContact();
      if (!app.peer.canMessagePeer(contact.id)) {
        sendHardwareEvent("error", { message: "Still connecting. Try again in a moment." });
        return;
      }
    }
    const payload = {
      text,
      attachment: null,
      replyTo: null,
      presentation: currentMessagePresentation()
    };
    const sentAt = new Date().toISOString();
    const messageId = crypto.randomUUID();
    app.peer.sendTyping({ to: contact.id, isTyping: false });
    const sendPromise = app.peer.sendText(payload, { to: contact.id, publicKeyJwk: contact.publicKeyJwk, messageId, sentAt });
    await appendMessage(contact.id, { messageId, ...payload, direction: "outbound", sentAt, deliveryStatus: "queued" });
    app.state = await loadState();
    if (app.activeContactId === contact.id) {
      renderConversation();
      scrollMessagesToBottom();
    }
    sendHardwareEvent("send-ok", { to: contact.id, messageId });
    await sendPromise;
  } catch (error) {
    setStatus(error.message);
    await updateDiagnostics({ failure: error.message });
    app.state = await loadState();
    renderDashboard();
    sendHardwareEvent("error", { message: error.message || "Message failed." });
  }
}

function sendHardwareSnapshot() {
  sendHardwareEvent("snapshot", {
    identity: app.identity?.id || "",
    displayName: app.state?.settings?.displayName || "Local User",
    presence: app.state?.settings?.presence || "online",
    activeContactId: app.activeContactId || "",
    contacts: hardwareContactsPayload()
  });
  if (app.activeContactId) sendHardwareChatSnapshot(app.activeContactId);
}

function sendHardwareChatSnapshot(contactId) {
  const contact = app.state.contacts.find((item) => item.id === contactId);
  if (!contact) return;
  const conversation = app.state.conversations[contact.id] || [];
  sendHardwareEvent("chat", {
    contact: hardwareContactPayload(contact),
    messages: conversation.slice(-8).map(hardwareMessagePayload)
  });
}

function sendHardwareIncomingMessage(peerId, message) {
  const contact = app.state.contacts.find((item) => item.id === peerId);
  sendHardwareEvent("incoming", {
    contact: contact ? hardwareContactPayload(contact) : { id: peerId, name: peerId },
    message: hardwareMessagePayload(message)
  });
}

function hardwareContactsPayload() {
  return sortedConversations(app.state.contacts)
    .filter((contact) => contact.accepted !== false && !contact.blocked)
    .slice(0, 12)
    .map(hardwareContactPayload);
}

function hardwareContactPayload(contact) {
  return {
    id: contact.id,
    name: contact.name || contact.id,
    status: contact.status || "offline",
    unreadCount: Number(contact.unreadCount || 0)
  };
}

function hardwareMessagePayload(message) {
  return {
    direction: message.direction || "inbound",
    text: message.text || notificationPreview(message),
    sentAt: message.sentAt || new Date().toISOString(),
    messageId: message.messageId || ""
  };
}

function sendHardwareEvent(type, payload = {}) {
  if (app.hardwareSocket?.readyState !== WebSocket.OPEN) return;
  app.hardwareSocket.send(JSON.stringify({ type, ...payload }));
  appendHardwareLog(`TX ${type}`);
}

function appendHardwareLog(line) {
  app.hardwareBridgeLog.push(`${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })} ${line}`);
  app.hardwareBridgeLog = app.hardwareBridgeLog.slice(-32);
  renderHardwareBridge();
}

// Draws the local contact list with rename and avatar controls.
function renderContacts() {
  elements.contacts.innerHTML = "";
  const visibleContacts = sortedConversations(app.state.contacts).filter((contact) => {
    if (!app.contactSearchQuery) return true;
    return contact.name.toLowerCase().includes(app.contactSearchQuery) || contact.id.includes(app.contactSearchQuery);
  });
  if (!visibleContacts.length) {
    elements.contacts.innerHTML = `<p class="muted">${app.contactSearchQuery ? "No matching contacts." : "No contacts yet."}</p>`;
    return;
  }

  for (const contact of visibleContacts) {
    const unreadCount = Number(contact.unreadCount || 0);
    const row = document.createElement("button");
    row.className = `contact ${contact.id === app.activeContactId ? "selected" : ""} ${unreadCount ? "has-unread" : ""}`;
    row.innerHTML = `
      <span class="avatar-wrap">
        <span class="avatar">${contact.avatar ? `<img src="${contact.avatar}" alt="">` : contact.name.slice(0, 1).toUpperCase()}</span>
        ${unreadCount ? `<span class="unread-dot" aria-label="${unreadCount} unread message${unreadCount === 1 ? "" : "s"}"></span>` : ""}
      </span>
      <span class="contact-main">
        <strong>${escapeHtml(contact.name)}</strong>
        <small>${contact.pinned ? "Pinned - " : ""}${contactStatusLabel(contact)}</small>
      </span>
      ${unreadCount ? `<span class="unread-count">${formatUnreadCount(unreadCount)}</span>` : ""}
    `;
    row.addEventListener("click", () => openContactDialog(contact.id));
    row.addEventListener("dblclick", () => renameContact(contact));
    elements.contacts.append(row);
  }
  renderGroupMemberPicker();
}

function switchContactDirectoryTab(tabName) {
  app.contactDirectoryTab = tabName === "quick-add" ? "quick-add" : "contacts";
  elements.contactDirectoryTabs.forEach((button) => {
    button.classList.toggle("active", button.dataset.contactDirectoryTab === app.contactDirectoryTab);
  });
  elements.savedContactsPanel.classList.toggle("active-contact-directory-panel", app.contactDirectoryTab === "contacts");
  elements.quickAddPanel.classList.toggle("active-contact-directory-panel", app.contactDirectoryTab === "quick-add");
  if (app.contactDirectoryTab === "quick-add") requestQuickAdd({ reset: true });
}

function scheduleQuickAddSearch() {
  clearTimeout(app.quickAddSearchTimer);
  app.quickAddSearchTimer = setTimeout(() => {
    app.quickAddQuery = elements.quickAddSearch.value.trim();
    requestQuickAdd({ reset: true });
  }, 280);
}

function requestQuickAdd({ reset = true } = {}) {
  if (app.quickAddLoading) return;
  app.quickAddLoading = true;
  if (reset) {
    app.quickAddOffset = 0;
    app.quickAddResults = [];
  }
  renderQuickAdd();
  try {
    app.peer.requestQuickAdd({
      query: app.quickAddQuery,
      exclude: app.state.contacts.map((contact) => contact.id),
      offset: reset ? 0 : app.quickAddOffset,
      limit: 30
    });
  } catch (error) {
    app.quickAddLoading = false;
    renderQuickAdd(error.message);
  }
}

function receiveQuickAddResults(message) {
  const incoming = Array.isArray(message.results) ? message.results.filter((profile) => (
    isValidBypassiumId(profile.id)
    && profile.id !== app.identity.id
    && !app.state.contacts.some((contact) => contact.id === profile.id)
  )) : [];
  app.quickAddResults = Number(message.offset || 0) === 0
    ? incoming
    : [...app.quickAddResults, ...incoming.filter((profile) => !app.quickAddResults.some((item) => item.id === profile.id))];
  app.quickAddOffset = Number(message.nextOffset || app.quickAddResults.length);
  app.quickAddHasMore = Boolean(message.hasMore);
  app.quickAddLoading = false;
  renderQuickAdd();
}

function renderQuickAdd(errorMessage = "") {
  elements.quickAddVisibility.checked = app.state.settings.quickAddVisible !== false;
  elements.quickAddList.innerHTML = "";
  elements.refreshQuickAdd.classList.toggle("spinning", app.quickAddLoading);
  elements.loadMoreQuickAdd.classList.toggle("hidden", !app.quickAddHasMore || app.quickAddLoading);
  if (errorMessage) {
    elements.quickAddList.innerHTML = `<p class="muted">${escapeHtml(errorMessage)}</p>`;
    return;
  }
  if (!app.quickAddResults.length) {
    elements.quickAddList.innerHTML = `<p class="muted">${app.quickAddLoading ? "Loading people..." : "No customized profiles found."}</p>`;
    return;
  }
  for (const profile of app.quickAddResults) {
    const row = document.createElement("article");
    row.className = "quick-add-row";
    row.innerHTML = `
      <span class="avatar">${profile.profilePicture ? `<img src="${escapeHtml(profile.profilePicture)}" alt="">` : escapeHtml(profile.displayName.slice(0, 1).toUpperCase())}</span>
      <span class="contact-main">
        <strong>${escapeHtml(profile.displayName)}</strong>
        <small>${escapeHtml(profile.status || "offline")}</small>
      </span>
      <button type="button" class="quick-add-plus" title="Add ${escapeHtml(profile.displayName)}" aria-label="Add ${escapeHtml(profile.displayName)}">+</button>
      <button type="button" class="quick-add-more" title="View profile" aria-label="View ${escapeHtml(profile.displayName)} profile">&#8942;</button>
    `;
    row.querySelector(".quick-add-plus").addEventListener("click", () => addQuickAddContact(profile.id));
    row.querySelector(".quick-add-more").addEventListener("click", () => openQuickAddDialog(profile.id));
    elements.quickAddList.append(row);
  }
}

async function updateQuickAddVisibility() {
  const visible = elements.quickAddVisibility.checked;
  await saveSettings({ quickAddVisible: visible });
  app.state = await loadState();
  app.peer.publishProfile(currentProfilePayload());
  showToast(visible ? "Your customized profile can appear in Quick Add." : "You are hidden from Quick Add.");
}

function openQuickAddDialog(peerId) {
  const profile = app.quickAddResults.find((item) => item.id === peerId);
  if (!profile) return;
  app.pendingQuickAddId = peerId;
  elements.quickAddDialogAvatar.innerHTML = profile.profilePicture
    ? `<img src="${escapeHtml(profile.profilePicture)}" alt="">`
    : `<span>${escapeHtml(profile.displayName.slice(0, 1).toUpperCase())}</span>`;
  elements.quickAddDialogName.textContent = profile.displayName;
  elements.quickAddDialogStatus.textContent = profile.status || "offline";
  elements.quickAddDialogJoined.textContent = `Joined ${formatJoinedDate(profile.joinedAt)}`;
  elements.quickAddDialog.showModal();
}

async function addPendingQuickAddContact() {
  await addQuickAddContact(app.pendingQuickAddId);
  elements.quickAddDialog.close();
}

async function addQuickAddContact(peerId) {
  const profile = app.quickAddResults.find((item) => item.id === peerId);
  if (!profile || app.state.contacts.some((contact) => contact.id === peerId)) return;
  await upsertContact({
    id: peerId,
    name: profile.displayName,
    nameEdited: false,
    avatar: sanitizeProfilePicture(profile.profilePicture),
    status: profile.status || "offline",
    accepted: true
  });
  app.state = await loadState();
  app.quickAddResults = app.quickAddResults.filter((item) => item.id !== peerId);
  syncWatchedPeers();
  app.peer.publishProfile(currentProfilePayload());
  renderContacts();
  renderQuickAdd();
  renderMessageContacts();
  showToast(`${profile.displayName} added.`);
}

function formatJoinedDate(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "recently";
  return new Intl.DateTimeFormat(undefined, { day: "numeric", month: "short", year: "numeric" }).format(date);
}

function renderGroupMemberPicker() {
  elements.groupMemberPicker.innerHTML = "";
  const selectableContacts = app.state.contacts.filter((contact) => !contact.blocked && contact.accepted !== false);
  if (!selectableContacts.length) {
    elements.groupMemberPicker.innerHTML = `<p class="muted">Add contacts first, then select them here.</p>`;
    return;
  }

  for (const contact of selectableContacts) {
    elements.groupMemberPicker.append(renderMemberOption(contact, "group-member"));
  }
}

function renderAddMemberPicker(group) {
  elements.addMemberPicker.innerHTML = "";
  const existingMembers = new Set(group.members || []);
  const selectableContacts = app.state.contacts.filter((contact) => (
    !contact.blocked
    && contact.accepted !== false
    && !existingMembers.has(contact.id)
  ));
  if (!selectableContacts.length) {
    elements.addMemberPicker.innerHTML = `<p class="muted">No saved contacts available to add.</p>`;
    elements.confirmAddMembers.disabled = true;
    return;
  }
  elements.confirmAddMembers.disabled = false;
  for (const contact of selectableContacts) {
    elements.addMemberPicker.append(renderMemberOption(contact, "add-member"));
  }
}

function renderMemberOption(contact, name) {
  const label = document.createElement("label");
  label.className = "member-option";
  label.innerHTML = `
    <input type="checkbox" name="${name}" value="${escapeHtml(contact.id)}" />
    <span class="avatar">${contact.avatar ? `<img src="${contact.avatar}" alt="">` : contact.name.slice(0, 1).toUpperCase()}</span>
    <span class="contact-main">
      <strong>${escapeHtml(contact.name)}</strong>
      <small>${escapeHtml(contact.id)}</small>
    </span>
  `;
  return label;
}

function renderGroupMembersList(group) {
  elements.groupMembersList.innerHTML = "";
  const viewerIsOwner = group.ownerId === app.identity.id;
  const viewerIsAdmin = viewerIsOwner || group.admins?.includes(app.identity.id);
  for (const memberId of group.members || []) {
    const contact = app.state.contacts.find((item) => item.id === memberId);
    const isSelf = memberId === app.identity.id;
    const memberName = isSelf ? `${app.state.settings.displayName || "You"} (You)` : contact?.name || memberId;
    const memberStatus = isSelf ? "you" : contactStatusLabel(contact || { status: "unknown" });
    const memberAvatar = isSelf ? app.state.settings.profilePicture : contact?.avatar;
    const memberIsOwner = memberId === group.ownerId;
    const memberIsAdmin = memberIsOwner || group.admins?.includes(memberId);
    const role = memberIsOwner ? "Owner" : memberIsAdmin ? "Administrator" : "Member";
    const canRemove = !isSelf && !memberIsOwner && viewerIsAdmin && (viewerIsOwner || !memberIsAdmin);
    const row = document.createElement("article");
    row.className = `group-member-row ${contact?.blocked ? "blocked-member" : ""}`;
    row.innerHTML = `
      <span class="avatar-wrap">
        <span class="avatar">${memberAvatar ? `<img src="${memberAvatar}" alt="">` : memberName.slice(0, 1).toUpperCase()}</span>
      </span>
        <span class="contact-main">
          <strong>${escapeHtml(memberName)}</strong>
          <small>${escapeHtml(memberStatus)} - ${role}</small>
        </span>
        <span class="group-member-actions">
          ${isSelf ? "" : `<button type="button" data-action="${contact ? "message" : "add"}" data-member-id="${escapeHtml(memberId)}">${contact ? "Message" : "Add Contact"}</button>`}
          ${isSelf ? "" : `<button type="button" class="secondary" data-action="block" data-member-id="${escapeHtml(memberId)}">${contact?.blocked ? "Unblock" : "Block"}</button>`}
          ${viewerIsOwner && !isSelf && !memberIsOwner ? `<button type="button" class="secondary" data-action="admin" data-member-id="${escapeHtml(memberId)}">${memberIsAdmin ? "Remove Admin" : "Make Admin"}</button>` : ""}
          ${viewerIsOwner && !isSelf ? `<button type="button" class="secondary" data-action="transfer" data-member-id="${escapeHtml(memberId)}">Transfer Ownership</button>` : ""}
          ${canRemove ? `<button type="button" class="danger-button" data-action="remove" data-member-id="${escapeHtml(memberId)}">Remove</button>` : ""}
        </span>
    `;
    elements.groupMembersList.append(row);
  }
}

function selectedContactIds(container, name) {
  return [...container.querySelectorAll(`input[name="${name}"]:checked`)]
    .map((input) => input.value)
    .filter((id) => isValidBypassiumId(id) && id !== app.identity.id);
}

function openMultiSendDialog() {
  const contacts = sortedConversations(app.state.contacts.filter((contact) => (
    !contact.blocked && contact.accepted !== false
  )));
  elements.multiSendRecipients.innerHTML = "";
  elements.multiSendMessage.value = "";
  elements.multiSendFeedback.textContent = "";
  app.multiSendAttachment = null;
  renderMultiSendAttachmentPreview();
  elements.confirmMultiSend.disabled = contacts.length === 0;
  if (!contacts.length) {
    elements.multiSendRecipients.innerHTML = `<p class="muted">No available contacts. Add or unblock someone first.</p>`;
  } else {
    for (const contact of contacts) {
      elements.multiSendRecipients.append(renderMemberOption(contact, "multi-send"));
    }
  }
  elements.multiSendDialog.showModal();
}

function closeMultiSendDialog() {
  if (app.voiceRecording?.target === "multi-send") discardVoiceRecording();
  app.multiSendAttachment = null;
  app.pendingVoiceTarget = "conversation";
  renderMultiSendAttachmentPreview();
  elements.multiSendDialog.close();
}

async function handleMultiSendAttachmentPicked() {
  const file = elements.multiSendAttachmentInput.files?.[0];
  if (!file) return;
  try {
    app.multiSendAttachment = await prepareAttachment(file);
    renderMultiSendAttachmentPreview();
  } catch (error) {
    elements.multiSendFeedback.textContent = error.message;
  } finally {
    elements.multiSendAttachmentInput.value = "";
  }
}

async function toggleMultiSendVoiceRecording() {
  if (app.voiceRecording?.target === "multi-send" && isVoiceRecording()) {
    stopVoiceRecording();
    return;
  }
  await startVoiceRecording({ target: "multi-send" });
}

function renderMultiSendAttachmentPreview() {
  const attachment = app.multiSendAttachment;
  elements.multiSendAttachmentPreview.classList.toggle("hidden", !attachment);
  const isAudio = attachment?.dataUrl?.startsWith("data:audio/");
  elements.multiSendAttachmentPreview.classList.toggle("voice-attachment-preview", Boolean(isAudio));
  elements.multiSendAttachmentPreview.innerHTML = isAudio
    ? `<div class="voice-preview-content">${renderVoiceNotePlayer(attachment, true)}</div><button type="button" class="secondary" id="clearMultiSendAttachment">Remove</button>`
    : attachment
    ? `<span>${escapeHtml(attachment.external ? "GIF link attached" : attachment.name || "Image")}</span><button type="button" class="secondary" id="clearMultiSendAttachment">Remove</button>`
    : "";
  document.querySelector("#clearMultiSendAttachment")?.addEventListener("click", () => {
    app.multiSendAttachment = null;
    renderMultiSendAttachmentPreview();
  });
  initializeVoiceNotePlayers(elements.multiSendAttachmentPreview);
  elements.multiSendVoice.disabled = Boolean(attachment) || Boolean(app.voiceRecordingPending);
  elements.multiSendAttach.disabled = Boolean(app.voiceRecording) || Boolean(app.voiceRecordingPending);
}

// Sends one independently encrypted direct message to each selected contact.
async function sendMessageIndividually(event) {
  event.preventDefault();
  const recipientIds = selectedContactIds(elements.multiSendRecipients, "multi-send");
  const text = elements.multiSendMessage.value.trim();
  if (!recipientIds.length) {
    elements.multiSendFeedback.textContent = "Select at least one contact.";
    return;
  }
  if (!text && !app.multiSendAttachment) {
    elements.multiSendFeedback.textContent = "Type a message or attach something first.";
    return;
  }

  const contacts = recipientIds
    .map((id) => app.state.contacts.find((contact) => contact.id === id))
    .filter((contact) => contact && !contact.blocked && contact.accepted !== false);
  elements.confirmMultiSend.disabled = true;
  elements.multiSendFeedback.textContent = `Preparing ${contacts.length} private message${contacts.length === 1 ? "" : "s"}...`;

  const outcomes = await Promise.all(contacts.map(async (contact) => {
    try {
      const messageId = crypto.randomUUID();
      const sentAt = new Date().toISOString();
      const payload = {
        text,
        attachment: app.multiSendAttachment,
        replyTo: null,
        presentation: currentMessagePresentation()
      };
      const sendPromise = app.peer.sendText(payload, {
        to: contact.id,
        publicKeyJwk: contact.publicKeyJwk,
        messageId,
        sentAt
      }).then(
        () => ({ sent: true }),
        (error) => ({ sent: false, error: error.message })
      );
      await appendMessage(contact.id, {
        messageId,
        ...payload,
        direction: "outbound",
        sentAt,
        deliveryStatus: "queued"
      });
      await flushPendingMessageStatus(messageId);
      return { contactId: contact.id, ...(await sendPromise) };
    } catch (error) {
      return { contactId: contact.id, sent: false, error: error.message };
    }
  }));

  const sentCount = outcomes.filter((outcome) => outcome.sent).length;
  const queuedCount = outcomes.length - sentCount;
  const summary = queuedCount
    ? `Sent to ${sentCount}; queued for ${queuedCount}.`
    : `Sent separately to ${sentCount} contact${sentCount === 1 ? "" : "s"}.`;
  if (queuedCount) {
    const failures = outcomes.filter((outcome) => !outcome.sent).map((outcome) => outcome.error).filter(Boolean);
    await updateDiagnostics({ failure: `Multi-send queued ${queuedCount}: ${[...new Set(failures)].join("; ")}` });
  }
  app.state = await loadState();
  renderContacts();
  renderMessageContacts();
  renderDashboard();
  elements.multiSendMessage.value = "";
  app.multiSendAttachment = null;
  renderMultiSendAttachmentPreview();
  elements.multiSendDialog.close();
  elements.confirmMultiSend.disabled = false;
  setStatus(summary);
  showToast(summary);
}

function renderMessageButtonUnread() {
  const directUnread = app.state.contacts.reduce((total, contact) => total + Number(contact.unreadCount || 0), 0);
  const groupUnread = app.state.groups.reduce((total, group) => total + Number(group.unreadCount || 0), 0);
  const totalUnread = directUnread + groupUnread;
  elements.messageButton.classList.toggle("has-unread", totalUnread > 0);
  elements.messageButton.dataset.unreadCount = totalUnread ? formatUnreadCount(totalUnread) : "";
  renderTabBadge(elements.directTabBadge, directUnread);
  renderTabBadge(elements.groupTabBadge, groupUnread);
}

function renderTabBadge(element, count) {
  element.textContent = formatUnreadCount(count);
  element.classList.toggle("hidden", !count);
}

// Draws the full-width message picker shown before opening a private chat.
function renderMessageContacts() {
  elements.messageContacts.innerHTML = "";
  elements.openMultiSend.classList.toggle("hidden", app.messagePickerTab !== "direct");
  if (!app.state.contacts.length && !app.state.groups.length) {
    elements.messageContacts.innerHTML = `<p class="muted message-empty">No contacts yet. Add someone from Menu first.</p>`;
    return;
  }

  elements.messageTabs.forEach((button) => {
    button.classList.toggle("active", button.dataset.messageTab === app.messagePickerTab);
  });

  if (app.messagePickerTab === "groups") {
    if (!app.state.groups.length) {
      elements.messageContacts.innerHTML = `<p class="muted message-empty">No group chats yet. Create one from Menu.</p>`;
      return;
    }

    for (const group of sortedMessageGroups()) {
      const unreadCount = Number(group.unreadCount || 0);
      const card = document.createElement("article");
      card.className = `message-contact ${group.id === app.activeGroupId ? "selected" : ""} ${unreadCount ? "has-unread" : ""}`;
      card.innerHTML = `
        <div class="message-contact-summary">
          <span class="avatar-wrap">
            <span class="avatar">${group.avatar ? `<img src="${group.avatar}" alt="">` : "G"}</span>
            ${unreadCount ? `<span class="unread-dot" aria-label="${unreadCount} unread message${unreadCount === 1 ? "" : "s"}"></span>` : ""}
          </span>
          <span class="contact-main">
            <strong>${escapeHtml(group.name)}</strong>
            <small>${group.pinned ? "Pinned - " : ""}${group.members.length} members</small>
          </span>
          ${unreadCount ? `<span class="unread-count">${formatUnreadCount(unreadCount)}</span>` : ""}
          <button class="contact-options-button" type="button" title="Group options" aria-label="Options for ${escapeHtml(group.name)}">&#8942;</button>
        </div>
        <button class="message-contact-action" type="button">Message</button>
      `;
      card.querySelector(".message-contact-action").addEventListener("click", () => selectGroup(group.id));
      card.querySelector(".contact-options-button").addEventListener("click", () => openGroupDialog(group.id));
      elements.messageContacts.append(card);
    }
    return;
  }

  if (!app.state.contacts.length) {
    elements.messageContacts.innerHTML = `<p class="muted message-empty">No direct messages yet. Add someone from Menu.</p>`;
    return;
  }

  for (const contact of sortedMessageContacts()) {
    const unreadCount = Number(contact.unreadCount || 0);
    const card = document.createElement("article");
    card.className = `message-contact ${contact.id === app.activeContactId ? "selected" : ""} ${unreadCount ? "has-unread" : ""}`;
    card.innerHTML = `
      <div class="message-contact-summary">
        <span class="avatar-wrap">
          <span class="avatar">${contact.avatar ? `<img src="${contact.avatar}" alt="">` : contact.name.slice(0, 1).toUpperCase()}</span>
          ${unreadCount ? `<span class="unread-dot" aria-label="${unreadCount} unread message${unreadCount === 1 ? "" : "s"}"></span>` : ""}
        </span>
        <span class="contact-main">
          <strong>${escapeHtml(contact.name)}</strong>
          <small>${contact.pinned ? "Pinned - " : ""}${contactStatusLabel(contact)}</small>
        </span>
        ${unreadCount ? `<span class="unread-count">${formatUnreadCount(unreadCount)}</span>` : ""}
        <button class="contact-options-button" type="button" title="Contact options" aria-label="Options for ${escapeHtml(contact.name)}">&#8942;</button>
      </div>
      <button class="message-contact-action" type="button">Message</button>
    `;
    card.querySelector(".message-contact-action").addEventListener("click", () => selectContact(contact.id));
    card.querySelector(".contact-options-button").addEventListener("click", () => openContactDialog(contact.id));
    elements.messageContacts.append(card);
  }
}

function showContactPicker() {
  sendTypingStopped();
  discardVoiceRecording();
  app.messageSearchQuery = "";
  elements.messageSearchInput.value = "";
  elements.messageSearchBar.classList.add("hidden");
  elements.mentionSuggestions.classList.add("hidden");
  app.activeContactId = null;
  app.activeGroupId = null;
  clearNewMessagesBelow();
  elements.appShell.classList.remove("conversation-open");
  elements.contactPickerScreen.classList.add("active-chat-screen");
  elements.conversationScreen.classList.remove("active-chat-screen");
  renderContacts();
  renderMessageContacts();
}

function showConversation() {
  clearNewMessagesBelow();
  elements.appShell.classList.add("conversation-open");
  elements.contactPickerScreen.classList.remove("active-chat-screen");
  elements.conversationScreen.classList.add("active-chat-screen");
  renderContacts();
  renderMessageContacts();
  renderConversation();
  scrollMessagesToBottom();
  if (app.activeContactId) connectCurrentContact();
}

// Opens contact actions instead of changing chats immediately.
function openContactDialog(contactId) {
  const contact = app.state.contacts.find((item) => item.id === contactId);
  if (!contact) return;
  app.pendingContactId = contactId;
  elements.contactDialogAvatar.innerHTML = contact.avatar
    ? `<img src="${contact.avatar}" alt="">`
    : `<span>${escapeHtml(contact.name.slice(0, 1).toUpperCase())}</span>`;
  elements.contactDialogName.textContent = contact.name;
  elements.contactDialogStatus.textContent = contactDialogStatusText(contact);
  elements.contactDialogCode.textContent = `Code: ${contact.id}`;
  elements.contactMessage.textContent = contact.accepted === false ? "Add Back" : "Message";
  elements.contactPin.textContent = contact.pinned ? "Unpin" : "Pin";
  elements.contactBlock.textContent = contact.blocked ? "Unblock" : "Block";
  elements.contactNotifications.checked = contact.notifications !== false;
  elements.contactChatBackground.value = normalizeHex(contact.chatBackground, app.state.settings.palette.background);
  elements.contactChatBackgroundImage.value = "";
  elements.contactDialog.showModal();
}

function openGroupDialog(groupId) {
  const group = app.state.groups.find((item) => item.id === groupId);
  if (!group) return;
  app.pendingGroupId = groupId;
  app.pendingGroupDialogPicture = "";
  elements.groupDialogPicture.value = "";
  elements.groupDialogAvatar.innerHTML = group.avatar
    ? `<img src="${group.avatar}" alt="">`
    : `<span>${escapeHtml(group.name.slice(0, 1).toUpperCase())}</span>`;
  elements.groupDialogName.textContent = group.name;
  elements.groupDialogStatus.textContent = `${group.members.length} members`;
  const role = group.ownerId === app.identity.id
    ? "You own this group"
    : group.admins?.includes(app.identity.id)
    ? "You are an administrator"
    : `Owned by ${senderLabel(group.ownerId)}`;
  elements.groupDialogRole.textContent = role;
  const canAdminister = canAdministerGroup(group);
  elements.groupAddMembers.disabled = !group.members?.includes(app.identity.id);
  elements.groupRename.disabled = !canAdminister;
  elements.groupDialogPicture.disabled = !canAdminister;
  elements.saveGroupPicture.disabled = !canAdminister;
  elements.groupPin.textContent = group.pinned ? "Unpin" : "Pin";
  elements.groupLeave.disabled = group.ownerId === app.identity.id && group.members.length > 1;
  elements.groupLeave.title = elements.groupLeave.disabled ? "Transfer ownership before leaving" : "";
  elements.groupNotifications.checked = group.notifications !== false;
  elements.groupChatBackground.value = normalizeHex(group.chatBackground, app.state.settings.palette.background);
  elements.groupDialog.showModal();
}

// Selects a contact and displays their local conversation.
async function selectContact(contactId) {
  app.activeContactId = contactId;
  app.activeGroupId = null;
  await clearUnreadCount(contactId);
  await sendVisibleReadReceipts(contactId);
  showConversation();
}

async function selectGroup(groupId) {
  app.activeGroupId = groupId;
  app.activeContactId = null;
  await clearGroupUnreadCount(groupId);
  await sendVisibleGroupReadReceipts(groupId);
  showConversation();
}

async function messagePendingContact() {
  const contact = pendingContact();
  if (!contact) return;
  if (contact.accepted === false) {
    await updateContact(contact.id, {
      accepted: true
    });
    app.state = await loadState();
    syncWatchedPeers();
  }
  elements.appShell.classList.remove("sidebar-mode");
  elements.appShell.classList.remove("settings-mode");
  elements.appShell.classList.add("messages-mode");
  document.querySelectorAll(".rail-button").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === "chat");
  });
  document.querySelectorAll(".view").forEach((view) => view.classList.remove("active-view"));
  document.querySelector("#chatView").classList.add("active-view");
  await selectContact(contact.id);
  elements.contactDialog.close();
}

async function messagePendingGroup() {
  const group = pendingGroup();
  if (!group) return;
  elements.appShell.classList.remove("sidebar-mode");
  elements.appShell.classList.remove("settings-mode");
  elements.appShell.classList.add("messages-mode");
  document.querySelectorAll(".rail-button").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === "chat");
  });
  document.querySelectorAll(".view").forEach((view) => view.classList.remove("active-view"));
  document.querySelector("#chatView").classList.add("active-view");
  await selectGroup(group.id);
  elements.groupDialog.close();
}

async function addPendingGroupMembers() {
  const group = pendingGroup();
  if (!group) return;
  renderAddMemberPicker(group);
  elements.groupDialog.close();
  elements.memberPickerDialog.showModal();
}

async function confirmAddPendingGroupMembers() {
  const group = pendingGroup();
  if (!group) return;
  const members = selectedContactIds(elements.addMemberPicker, "add-member");
  if (!members.length) {
    setStatus("Select at least one contact to add.");
    return;
  }
  for (const memberId of members) {
    if (!app.state.contacts.some((contact) => contact.id === memberId)) {
      await upsertContact({ id: memberId, name: memberId, accepted: false, nameEdited: false });
    }
  }
  app.state = await loadState();
  syncWatchedPeers();
  app.peer.addGroupMembers(group.id, members);
  elements.memberPickerDialog.close();
  setStatus("Group update sent.");
}

function viewPendingGroupMembers() {
  const group = pendingGroup();
  if (!group) return;
  renderGroupMembersList(group);
  elements.groupDialog.close();
  elements.groupMembersDialog.showModal();
}

async function handleGroupMemberAction(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const memberId = button.dataset.memberId;
  if (!isValidBypassiumId(memberId) || memberId === app.identity.id) return;
  const contact = app.state.contacts.find((item) => item.id === memberId);

  if (button.dataset.action === "add") {
    await upsertContact({ id: memberId, name: memberId, nameEdited: false, accepted: true });
    app.state = await loadState();
    syncWatchedPeers();
    app.peer.publishProfile(currentProfilePayload());
    renderContacts();
    renderMessageContacts();
    refreshOpenGroupMembersList(memberId);
    setStatus("Contact added from group.");
  }

  if (button.dataset.action === "message") {
    if (!contact) return;
    elements.groupMembersDialog.close();
    app.pendingContactId = contact.id;
    app.activeGroupId = null;
    app.activeContactId = contact.id;
    switchView("chat");
    showConversation();
    connectCurrentContact();
  }

  if (button.dataset.action === "block") {
    await upsertContact({
      ...(contact || { id: memberId, name: memberId, nameEdited: false, accepted: false }),
      blocked: !contact?.blocked,
      status: !contact?.blocked ? "blocked" : "offline"
    });
    app.state = await loadState();
    renderContacts();
    renderMessageContacts();
    refreshOpenGroupMembersList(memberId);
  }

  const group = pendingGroup() || currentGroup();
  if (!group) return;
  if (button.dataset.action === "admin") {
    const isAdmin = group.admins?.includes(memberId);
    app.peer.setGroupAdmin(group.id, memberId, !isAdmin);
    setStatus(isAdmin ? "Removing administrator permission..." : "Granting administrator permission...");
  }
  if (button.dataset.action === "transfer" && confirm(`Transfer ownership of ${group.name} to ${contact?.name || memberId}?`)) {
    app.peer.transferGroupOwnership(group.id, memberId);
    setStatus("Transferring group ownership...");
  }
  if (button.dataset.action === "remove" && confirm(`Remove ${contact?.name || memberId} from ${group.name}?`)) {
    app.peer.removeGroupMember(group.id, memberId);
    setStatus("Removing group member...");
  }
}

function refreshOpenGroupMembersList(memberId) {
  const group = pendingGroup() || app.state.groups.find((item) => item.members?.includes(memberId));
  if (group && elements.groupMembersDialog.open) renderGroupMembersList(group);
}

async function renamePendingGroup() {
  const group = pendingGroup();
  if (!group) return;
  const name = prompt("Group name", group.name);
  if (!name?.trim()) return;
  app.peer.renameGroup(group.id, name.trim());
  elements.groupDialog.close();
  setStatus("Group name update sent.");
}

async function leavePendingGroup() {
  const group = pendingGroup();
  if (!group || !confirm(`Leave ${group.name}?`)) return;
  app.peer.leaveGroup(group.id);
  await deleteGroup(group.id);
  if (app.activeGroupId === group.id) app.activeGroupId = null;
  app.pendingGroupId = null;
  elements.groupDialog.close();
  app.state = await loadState();
  renderAll();
}

async function renamePendingContact() {
  const contact = pendingContact();
  if (!contact) return;
  await renameContact(contact);
  elements.contactDialog.close();
}

async function blockPendingContact() {
  const contact = pendingContact();
  if (!contact) return;
  await updateContact(contact.id, { blocked: !contact.blocked, status: !contact.blocked ? "blocked" : "offline" });
  app.state = await loadState();
  if (app.activeContactId === contact.id) renderConversation();
  renderContacts();
  const updatedContact = pendingContact();
  if (updatedContact) {
    elements.contactDialogStatus.textContent = contactDialogStatusText(updatedContact);
    elements.contactBlock.textContent = updatedContact.blocked ? "Unblock" : "Block";
  }
}

async function deletePendingContact() {
  const contact = pendingContact();
  if (!contact) return;
  if (!confirm(`Delete ${contact.name} and local chat history?`)) return;
  await deleteContact(contact.id);
  if (app.activeContactId === contact.id) app.activeContactId = null;
  app.pendingContactId = null;
  elements.contactDialog.close();
  app.state = await loadState();
  renderAll();
}

async function updatePendingContactNotifications() {
  const contact = pendingContact();
  if (!contact) return;
  await updateContact(contact.id, { notifications: elements.contactNotifications.checked });
  app.state = await loadState();
  renderContacts();
}

async function togglePendingContactPin() {
  const contact = pendingContact();
  if (!contact) return;
  await updateContact(contact.id, { pinned: !contact.pinned });
  app.state = await loadState();
  elements.contactPin.textContent = !contact.pinned ? "Unpin" : "Pin";
  renderContacts();
  renderMessageContacts();
}

async function updatePendingContactBackground() {
  const contact = pendingContact();
  if (!contact) return;
  await updateContact(contact.id, { chatBackground: elements.contactChatBackground.value });
  app.state = await loadState();
  applyConversationBackground();
}

async function resetPendingContactBackground() {
  const contact = pendingContact();
  if (!contact) return;
  await updateContact(contact.id, { chatBackground: "" });
  app.state = await loadState();
  elements.contactChatBackground.value = normalizeHex("", app.state.settings.palette.background);
  applyConversationBackground();
}

function previewContactBackgroundImage(event) {
  const contact = pendingContact();
  const file = elements.contactChatBackgroundImage.files?.[0];
  if (!contact) return;
  if (!file) {
    if (event?.type === "click") elements.contactChatBackgroundImage.click();
    return;
  }
  if (!file.type.startsWith("image/")) {
    setStatus("Choose an image file for the chat background.");
    elements.contactChatBackgroundImage.value = "";
    return;
  }
  const reader = new FileReader();
  reader.onload = () => openProfileEditor(reader.result, { target: "chat-background", contactId: contact.id });
  reader.onerror = () => {
    setStatus("That background image could not be opened.");
    elements.contactChatBackgroundImage.value = "";
  };
  reader.readAsDataURL(file);
}

async function removePendingContactBackgroundImage() {
  const contact = pendingContact();
  if (!contact) return;
  const color = elements.contactChatBackground.value;
  await updateContact(contact.id, { chatBackground: color, chatBackgroundImage: "" });
  app.state = await loadState();
  applyConversationBackground();
  try {
    await sendSharedChatBackground(contact, { color, image: "" });
    showToast("Shared background image removed.");
  } catch (error) {
    setStatus(`Background removed locally, but sync failed: ${error.message}`);
  }
}

async function sendSharedChatBackground(contact, background) {
  let current = app.state.contacts.find((item) => item.id === contact.id) || contact;
  if (!current.publicKeyJwk) {
    await app.peer.connectToPeer(current, SIGNALING_SERVER_URL);
    app.state = await loadState();
    current = app.state.contacts.find((item) => item.id === contact.id) || current;
  }
  await app.peer.sendChatSetting(background, {
    to: current.id,
    publicKeyJwk: current.publicKeyJwk
  });
}

async function receiveChatSetting(setting) {
  const contact = app.state.contacts.find((item) => item.id === setting.peerId);
  if (!contact || contact.blocked) return;
  const color = /^#[0-9a-f]{6}$/i.test(setting.background?.color || "")
    ? setting.background.color
    : contact.chatBackground || "";
  const image = sanitizeChatBackgroundImage(setting.background?.image);
  await updateContact(contact.id, {
    chatBackground: color,
    chatBackgroundImage: image
  });
  app.state = await loadState();
  if (app.activeContactId === contact.id) applyConversationBackground();
  showToast(`${contact.name} updated the chat background.`);
}

async function updatePendingGroupNotifications() {
  const group = pendingGroup();
  if (!group) return;
  await updateGroup(group.id, { notifications: elements.groupNotifications.checked });
  app.state = await loadState();
  renderMessageContacts();
}

async function togglePendingGroupPin() {
  const group = pendingGroup();
  if (!group) return;
  await updateGroup(group.id, { pinned: !group.pinned });
  app.state = await loadState();
  elements.groupPin.textContent = !group.pinned ? "Unpin" : "Pin";
  renderMessageContacts();
}

async function updatePendingGroupBackground() {
  const group = pendingGroup();
  if (!group) return;
  await updateGroup(group.id, { chatBackground: elements.groupChatBackground.value });
  app.state = await loadState();
  applyConversationBackground();
}

async function resetPendingGroupBackground() {
  const group = pendingGroup();
  if (!group) return;
  await updateGroup(group.id, { chatBackground: "" });
  app.state = await loadState();
  elements.groupChatBackground.value = normalizeHex("", app.state.settings.palette.background);
  applyConversationBackground();
}

function previewGroupDialogPicture() {
  const file = elements.groupDialogPicture.files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async () => {
    app.pendingGroupDialogPicture = await resizeProfilePicture(reader.result);
    if (!app.pendingGroupDialogPicture) return;
    elements.groupDialogAvatar.innerHTML = `<img src="${app.pendingGroupDialogPicture}" alt="">`;
  };
  reader.readAsDataURL(file);
}

function savePendingGroupPicture() {
  const group = pendingGroup();
  if (!group || !canAdministerGroup(group) || !app.pendingGroupDialogPicture) return;
  app.peer.updateGroup(group.id, { avatar: app.pendingGroupDialogPicture });
  app.pendingGroupDialogPicture = "";
  elements.groupDialogPicture.value = "";
  setStatus("Updating group picture...");
}

// Allows a contact to be renamed locally without notifying the peer.
async function renameContact(contact) {
  const name = prompt("Local contact name", contact.name);
  if (!name?.trim()) return;
  await upsertContact({ ...contact, name: name.trim(), nameEdited: true });
  app.state = await loadState();
  renderAll();
}

// Adds a friend ID to local storage.
async function addFriend(event) {
  event.preventDefault();
  const id = elements.friendId.value.trim();
  if (!isValidBypassiumId(id)) {
    setStatus("That does not look like a 6-digit Bypassium code.");
    return;
  }
  await upsertContact({ id, name: id, nameEdited: false, accepted: true });
  elements.addFriendForm.reset();
  app.state = await loadState();
  app.activeContactId = id;
  syncWatchedPeers();
  app.peer.publishProfile(currentProfilePayload());
  renderAll();
  switchSidebar("contacts");
}

async function createGroup(event) {
  event.preventDefault();
  const name = elements.groupName.value.trim();
  const members = selectedContactIds(elements.groupMemberPicker, "group-member");
  if (!name) return;
  if (!members.length) {
    setStatus("Select at least one contact for the group.");
    return;
  }
  try {
    app.state = await loadState();
    syncWatchedPeers();
    app.pendingCreatedGroup = { name, members: [app.identity.id, ...members], avatar: app.pendingGroupPicture || "" };
    app.peer.createGroup(name, members, app.pendingGroupPicture || "");
    elements.createGroupForm.reset();
    clearGroupPicturePreview();
    renderGroupMemberPicker();
    setStatus("Creating group chat...");
  } catch (error) {
    setStatus(error.message);
  }
}

// Renders local conversation history with timestamps.
function renderConversation() {
  const contact = currentContact();
  const group = currentGroup();
  const shouldStickToBottom = isNearMessagesBottom();
  applyConversationBackground();
  elements.activeName.textContent = group?.name || contact?.name || "No contact selected";
  const avatar = group?.avatar || contact?.avatar || "";
  const fallbackName = group?.name || contact?.name || "?";
  elements.activeAvatar.innerHTML = avatar
    ? `<img src="${escapeHtml(avatar)}" alt="">`
    : escapeHtml(fallbackName.slice(0, 1).toUpperCase());
  elements.activeStatus.textContent = group
    ? `${group.members.length} members`
    : contact
    ? "Private conversation"
    : "Add or choose a contact to begin.";
  elements.blockContact.disabled = !contact;
  elements.blockContact.classList.toggle("hidden", !contact);
  elements.blockContact.textContent = contact?.blocked ? "Unblock" : "Block";
  const canType = Boolean(group || (contact && !contact.blocked && contact.accepted !== false));
  const canSendNow = Boolean(contact && !contact.blocked && app.peer.canMessagePeer(contact.id));
  syncComposerControls(canType);
  elements.messageInput.placeholder = group
    ? "Message encrypted separately for each group member"
    : contact && !contact.blocked
    ? canSendNow ? "Message encrypted through the server" : "Type now. Bypassium will send when the server is ready."
    : "Message encrypted through the server";
  elements.messages.innerHTML = "";

  if (!contact && !group) {
    updateSearchResultCount(0, 0);
    elements.messages.classList.add("empty-state");
    elements.messages.innerHTML = "<p>Select a contact to view the local conversation.</p>";
    return;
  }

  if (group) {
    elements.messages.classList.remove("empty-state");
    const conversation = app.state.groupConversations[group.id] || [];
    const visibleMessages = filterMessages(conversation, group);
    updateSearchResultCount(visibleMessages.length, conversation.length);
    if (!visibleMessages.length) {
      elements.messages.innerHTML = `<p class="muted">${app.messageSearchQuery ? "No matching messages." : `No local messages in ${escapeHtml(group.name)}.`}</p>`;
    }
    for (const message of visibleMessages) {
      elements.messages.append(renderGroupMessageRow(message, group));
    }
    renderTypingIndicator(group, null);
    if (shouldStickToBottom) scrollMessagesToBottom();
    return;
  }

  if (contact.blocked) {
    elements.messages.classList.remove("empty-state");
    elements.messages.innerHTML = `<p class="muted">This contact is blocked. Unblock them to send or receive messages.</p>`;
    return;
  }

  if (contact.accepted === false) {
    elements.messages.classList.remove("empty-state");
    elements.messages.innerHTML = `<p class="muted">Message request from ${escapeHtml(contact.id)}. Add them back from the contact popup before replying.</p>`;
    return;
  }

  elements.messages.classList.remove("empty-state");
  const conversation = app.state.conversations[contact.id] || [];
  const visibleMessages = filterMessages(conversation, null);
  updateSearchResultCount(visibleMessages.length, conversation.length);
  if (!visibleMessages.length) {
    elements.messages.innerHTML = `<p class="muted">${app.messageSearchQuery ? "No matching messages." : `No local messages with ${escapeHtml(contact.name)}.`}</p>`;
  }

  for (const message of visibleMessages) {
    elements.messages.append(renderMessageBubble(message, { contact }));
  }
  renderTypingIndicator(null, contact);
  if (shouldStickToBottom) scrollMessagesToBottom();
}

// Sends an outbound message through the encrypted server relay and stores it locally.
async function sendMessage(event) {
  event.preventDefault();
  const contact = currentContact();
  const group = currentGroup();
  const text = elements.messageInput.value.trim();
  const payload = {
    text,
    attachment: app.selectedAttachment,
    replyTo: app.replyTo,
    presentation: currentMessagePresentation()
  };
  if ((!contact && !group) || (!payload.text && !payload.attachment)) return;
  if (group) {
    const sentAt = new Date().toISOString();
    const messageId = crypto.randomUUID();
    try {
      app.peer.sendTyping({ groupId: group.id, isTyping: false });
      const sendPromise = app.peer.sendGroupText(group, app.state.contacts, payload, { messageId, sentAt });
      await appendGroupMessage(group.id, {
        messageId,
        ...payload,
        direction: "outbound",
        senderId: app.identity.id,
        sentAt,
        deliveryStatus: "queued",
        deliveryRecipientCount: Math.max(0, group.members.length - 1)
      });
      clearComposerState();
      app.state = await loadState();
      await flushPendingMessageStatus(messageId);
      app.state = await loadState();
      renderConversation();
      scrollMessagesToBottom();
      clearNewMessagesBelow();
      await sendPromise;
    } catch (error) {
      setStatus(error.message);
      await updateDiagnostics({ failure: error.message });
      app.state = await loadState();
      renderDashboard();
    }
    return;
  }
  if (contact.blocked) {
    setStatus("This contact is blocked. Unblock them before sending messages.");
    return;
  }
  if (contact.accepted === false) {
    setStatus("Add this person back before replying.");
    return;
  }

  try {
    if (!contact.publicKeyJwk && !app.peer.canMessagePeer(contact.id)) {
      await connectCurrentContact();
      if (!app.peer.canMessagePeer(contact.id)) {
        setStatus("Still connecting. Try again in a moment.");
        return;
      }
    }
    const sentAt = new Date().toISOString();
    const messageId = crypto.randomUUID();
    app.peer.sendTyping({ to: contact.id, isTyping: false });
    const sendPromise = app.peer.sendText(payload, { to: contact.id, publicKeyJwk: contact.publicKeyJwk, messageId, sentAt });
    await appendMessage(contact.id, { messageId, ...payload, direction: "outbound", sentAt, deliveryStatus: "queued" });
    clearComposerState();
    app.state = await loadState();
    await flushPendingMessageStatus(messageId);
    app.state = await loadState();
    renderConversation();
    scrollMessagesToBottom();
    clearNewMessagesBelow();
    await sendPromise;
  } catch (error) {
    setStatus(error.message);
    await updateDiagnostics({ failure: error.message });
    app.state = await loadState();
    renderDashboard();
  }
}

// Stores and displays an inbound decrypted peer message.
async function receivePeerMessage(message) {
  const peerId = message.peerId;
  if (!peerId) return;
  const latestState = await loadState();
  const contact = latestState.contacts.find((item) => item.id === peerId);
  const isActiveVisibleChat = app.activeContactId === peerId;
  const wasNearBottom = isActiveVisibleChat ? isNearMessagesBottom() : true;
  if (contact?.blocked) {
    await updateDiagnostics({ failure: `Blocked message ignored from ${contact.name || peerId}.` });
    app.state = await loadState();
    renderDashboard();
    return;
  }
  const saveResult = await appendMessage(peerId, {
    messageId: message.messageId,
    text: message.text,
    attachment: message.attachment,
    replyTo: message.replyTo,
    presentation: message.presentation ? sanitizeMessagePresentation(message.presentation) : null,
    direction: "inbound",
    sentAt: message.sentAt || new Date().toISOString()
  });
  const inserted = Boolean(saveResult.inserted);
  const stateAfterSave = await loadState();
  const savedContact = stateAfterSave.contacts.find((item) => item.id === peerId) || contact;
  await upsertContact({
    id: peerId,
    name: contactDisplayName(savedContact, message.profile, `Message request ${peerId}`),
    nameEdited: savedContact?.nameEdited || false,
    avatar: sanitizeProfilePicture(message.profile?.profilePicture) || savedContact?.avatar || "",
    status: "online",
    publicKeyJwk: message.publicKeyJwk,
    accepted: savedContact?.accepted ?? false,
    unreadCount: nextUnreadCount(savedContact, peerId, !inserted)
  });
  if (inserted && savedContact?.notifications !== false && !isActiveVisibleChat) {
    chrome.runtime.sendMessage({ type: "notify", title: "New Bypassium message", body: notificationPreview(message) });
  }
  if (app.activeContactId === peerId && inserted) {
    app.peer.sendReadReceipt(peerId, message.messageId);
    await markDirectReadReceiptsSent(peerId, [message.messageId]);
  }
  app.state = await loadState();
  renderContacts();
  renderMessageContacts();
  renderMessageButtonUnread();
  if (app.activeContactId === peerId) {
    renderConversation();
    if (!wasNearBottom && inserted) showNewMessagesBelow(app.newMessagesBelow + 1);
  }
  if (inserted) sendHardwareIncomingMessage(peerId, message);
}

async function handleReadReceipt(message) {
  const peerId = String(message.from || "").trim();
  const messageId = String(message.messageId || "").trim();
  if (!isValidBypassiumId(peerId) || !messageId) return;
  const groupId = String(message.groupId || "").trim();
  if (groupId) {
    await updateGroupMessageDelivery(groupId, messageId, peerId, "read", 0, message.readAt || new Date().toISOString());
    app.state = await loadState();
    if (app.activeGroupId === groupId) renderConversation();
    return;
  }
  await markMessageRead(peerId, messageId, message.readAt || new Date().toISOString());
  await updateMessageDelivery(peerId, messageId, "read", message.readAt || new Date().toISOString());
  app.state = await loadState();
  if (app.activeContactId === peerId) renderConversation();
}

async function handleMessageStatus(message) {
  const messageId = String(message.messageId || "").trim();
  const status = String(message.status || "").trim();
  if (!messageId || !["queued", "sent", "delivered", "read"].includes(status)) return;
  const groupId = String(message.groupId || "").trim();
  const exists = groupId
    ? (app.state.groupConversations[groupId] || []).some((item) => item.messageId === messageId)
    : Object.values(app.state.conversations).some((conversation) => conversation.some((item) => item.messageId === messageId));
  if (!exists) {
    app.pendingMessageStatuses.set(messageId, message);
    return;
  }
  if (groupId) {
    await updateGroupMessageDelivery(
      groupId,
      messageId,
      String(message.peerId || "").trim(),
      status,
      Number(message.recipientCount || 0),
      message.updatedAt
    );
  } else {
    const peerId = String(message.peerId || "").trim();
    if (!isValidBypassiumId(peerId)) return;
    await updateMessageDelivery(peerId, messageId, status, message.updatedAt);
  }
  app.state = await loadState();
  if (app.activeGroupId === groupId || (!groupId && app.activeContactId === message.peerId)) renderConversation();
}

async function flushPendingMessageStatus(messageId) {
  const pending = app.pendingMessageStatuses.get(messageId);
  if (!pending) return;
  app.pendingMessageStatuses.delete(messageId);
  await handleMessageStatus(pending);
}

async function handleReaction(message) {
  const peerId = String(message.from || "").trim();
  const messageId = String(message.messageId || "").trim();
  const emoji = String(message.emoji || "").slice(0, 8);
  const active = message.active !== false;
  const groupId = String(message.groupId || "").trim();
  if (!isValidBypassiumId(peerId) || !messageId || !emoji) return;

  if (groupId) {
    const group = app.state.groups.find((item) => item.id === groupId);
    if (!group?.members?.includes(peerId)) return;
    await reactToGroupMessage(groupId, messageId, emoji, peerId, active);
    app.state = await loadState();
    if (app.activeGroupId === groupId) renderConversation();
    renderMessageContacts();
    return;
  }

  await reactToMessage(peerId, messageId, emoji, peerId, active);
  app.state = await loadState();
  if (app.activeContactId === peerId) renderConversation();
  renderMessageContacts();
}

async function handleTypingNotice(message) {
  const peerId = String(message.from || "").trim();
  if (!isValidBypassiumId(peerId) || peerId === app.identity.id) return;
  const isTyping = Boolean(message.isTyping);
  const groupId = String(message.groupId || "").trim();
  const key = groupId ? `group:${groupId}:${peerId}` : `contact:${peerId}`;
  clearTimeout(app.typingTimers.get(key));

  if (groupId) {
    const typing = app.typingByGroup.get(groupId) || new Map();
    if (isTyping) typing.set(peerId, Date.now());
    else typing.delete(peerId);
    app.typingByGroup.set(groupId, typing);
  } else if (isTyping) {
    app.typingByContact.set(peerId, Date.now());
  } else {
    app.typingByContact.delete(peerId);
  }

  if (isTyping) {
    app.typingTimers.set(key, setTimeout(() => {
      if (groupId) {
        const typing = app.typingByGroup.get(groupId);
        typing?.delete(peerId);
      } else {
        app.typingByContact.delete(peerId);
      }
      if (app.activeContactId === peerId || app.activeGroupId === groupId) renderConversation();
    }, 3500));
  }

  if (app.activeContactId === peerId || app.activeGroupId === groupId) renderConversation();
}

async function receiveGroupMessage(message) {
  if (!message.groupId) return;
  const latestState = await loadState();
  const existing = latestState.groups.find((group) => group.id === message.groupId);
  const isActiveVisibleChat = app.activeGroupId === message.groupId;
  const wasNearBottom = isActiveVisibleChat ? isNearMessagesBottom() : true;
  const saveResult = await appendGroupMessage(message.groupId, {
    messageId: message.messageId,
    senderId: message.senderId,
    text: message.text,
    attachment: message.attachment,
    replyTo: message.replyTo,
    presentation: message.presentation ? sanitizeMessagePresentation(message.presentation) : null,
    direction: "inbound",
    sentAt: message.sentAt || new Date().toISOString()
  });
  const inserted = Boolean(saveResult.inserted);
  const stateAfterSave = await loadState();
  const savedGroup = stateAfterSave.groups.find((group) => group.id === message.groupId) || existing;
  await upsertGroup({
    id: message.groupId,
    name: message.groupName || savedGroup?.name || "Group chat",
    members: message.members?.length ? message.members : savedGroup?.members || [app.identity.id, message.senderId],
    avatar: savedGroup?.avatar || "",
    notifications: savedGroup?.notifications ?? true,
    unreadCount: nextGroupUnreadCount(savedGroup, message.groupId, !inserted)
  });
  if (message.profile) await updateContactProfile(message.senderId, message.profile);
  if (isActiveVisibleChat && inserted && message.senderId && message.messageId) {
    app.peer.sendGroupReadReceipt(message.groupId, message.senderId, message.messageId);
    await markGroupReadReceiptsSent(message.groupId, [message.messageId]);
  }
  const mentioned = isCurrentUserMentioned(message.text);
  if (inserted && (savedGroup?.notifications !== false || mentioned) && !isActiveVisibleChat) {
    chrome.runtime.sendMessage({ type: "notify", title: "New Bypassium group message", body: notificationPreview(message) });
  }
  app.state = await loadState();
  renderMessageContacts();
  renderMessageButtonUnread();
  if (app.activeGroupId === message.groupId) {
    renderConversation();
    if (!wasNearBottom && inserted) showNewMessagesBelow(app.newMessagesBelow + 1);
  }
}

// Stores a peer public key discovered through the relay server.
async function rememberDiscoveredPeer(peer) {
  const existing = app.state.contacts.find((contact) => contact.id === peer.id);
  await upsertContact({
    id: peer.id,
    name: contactDisplayName(existing, peer.profile, `Message request ${peer.id}`),
    nameEdited: existing?.nameEdited || false,
    avatar: sanitizeProfilePicture(peer.profile?.profilePicture) || existing?.avatar || "",
    status: "online",
    publicKeyJwk: peer.publicKeyJwk,
    accepted: existing?.accepted ?? false
  });
  app.state = await loadState();
  syncWatchedPeers();
  renderContacts();
  renderMessageContacts();
  renderMessageButtonUnread();
  if (app.activeContactId === peer.id) renderConversation();
}

// Updates online/offline labels from the signaling server's temporary directory.
async function updateContactStatuses(statuses, profiles = {}) {
  const updates = Object.entries(statuses).filter(([id]) => app.state.contacts.some((contact) => contact.id === id));
  for (const [id, status] of updates) {
    const contact = app.state.contacts.find((item) => item.id === id);
    if (!contact?.blocked) {
      const profile = profiles[id] || {};
      await updateContact(id, {
        status,
        name: contactDisplayName(contact, profile, contact.name),
        avatar: sanitizeProfilePicture(profile.profilePicture) || contact.avatar
      });
    }
  }
  app.state = await loadState();
  renderContacts();
  renderMessageContacts();
  renderMessageButtonUnread();
  renderConversation();
}

async function updateContactProfile(peerId, profile) {
  if (!peerId || !profile) return;
  const contact = app.state.contacts.find((item) => item.id === peerId);
  await upsertContact({
    id: peerId,
    name: contactDisplayName(contact, profile, peerId),
    nameEdited: contact?.nameEdited || false,
    avatar: sanitizeProfilePicture(profile.profilePicture) || contact?.avatar || "",
    publicKeyJwk: contact?.publicKeyJwk || null,
    accepted: contact?.accepted ?? false,
    unreadCount: contact?.unreadCount || 0
  });
  app.state = await loadState();
  renderContacts();
  renderMessageContacts();
  renderMessageButtonUnread();
}

async function updateGroups(groups = []) {
  for (const group of groups.filter(Boolean)) {
    if (group.members?.includes(app.identity.id)) await upsertGroup(group);
    else await deleteGroup(group.id);
  }
  app.state = await loadState();
  syncWatchedPeers();
  const createdGroup = findPendingCreatedGroup();
  if (createdGroup) {
    const pendingAvatar = app.pendingCreatedGroup?.avatar || "";
    if (pendingAvatar && !createdGroup.avatar) {
      await updateGroup(createdGroup.id, { avatar: pendingAvatar });
      app.state = await loadState();
    }
    app.pendingCreatedGroup = null;
    app.messagePickerTab = "groups";
    await selectGroup(createdGroup.id);
    showToast("Group created!");
    return;
  }
  renderMessageContacts();
  renderMessageButtonUnread();
  if (app.activeGroupId && !app.state.groups.some((group) => group.id === app.activeGroupId)) showContactPicker();
  else renderConversation();
}

function findPendingCreatedGroup() {
  const pending = app.pendingCreatedGroup;
  if (!pending) return null;
  const expectedMembers = new Set(pending.members);
  return app.state.groups.find((group) => (
    group.name === pending.name
    && pending.members.every((memberId) => group.members?.includes(memberId))
    && group.members?.length === expectedMembers.size
  ));
}

// Selects a saved contact as the current encrypted relay target.
async function connectCurrentContact() {
  const contact = currentContact();
  if (!contact || contact.blocked) return;
  if (app.connectingContactId === contact.id && app.connectingPromise) return app.connectingPromise;
  app.connectingContactId = contact.id;
  app.connectingPromise = (async () => {
    await app.peer.connectToPeer(contact, SIGNALING_SERVER_URL);
  })();
  try {
    await app.connectingPromise;
  } catch (error) {
    await handleConnectionError(error);
  } finally {
    if (app.connectingContactId === contact.id) {
      app.connectingContactId = null;
      app.connectingPromise = null;
    }
    renderConversation();
  }
}

// Reports connection failures with likely causes.
async function handleConnectionError(error) {
  const message = `${error.message}. Server relay messaging needs the Render message server and Chrome extension network access.`;
  setStatus(message);
  await updateDiagnostics({ failure: message, peerConnectionStatus: "failed" });
  app.state = await loadState();
  renderDashboard();
}

// Collects browser-visible network capability diagnostics.
async function refreshNetworkInfo() {
  const info = await collectNetworkInfo();
  info.push(await fetchServerHealthInfo());
  elements.networkInfo.innerHTML = info.map(renderInfoItem).join("");
}

// Shows developer diagnostics for educational use.
function renderDashboard() {
  const diagnostics = app.state?.diagnostics || {};
  const items = [
    ["Current connection type", diagnostics.currentConnectionType || "none"],
    ["Latency", diagnostics.lastLatencyMs === null ? "Not measured" : `${diagnostics.lastLatencyMs} ms`],
    ["Encryption status", diagnostics.encryptionStatus || "not connected"],
    ["Peer connection status", diagnostics.peerConnectionStatus || "idle"],
    ["Messages sent", diagnostics.sent || 0],
    ["Messages received", diagnostics.received || 0],
    ["Local data size", formatBytes(estimateLocalStateSize())],
    ["Message server", serverHealthUrl()]
  ];
  elements.developerDashboard.innerHTML = items.map(([label, value]) => renderInfoItem({ label, value })).join("");
  elements.diagnosticLog.textContent = (diagnostics.failures || []).join("\n") || "No failures recorded.";
}

// Previews a selected profile picture without saving until the user clicks Save.
function previewProfilePicture() {
  const file = elements.profilePicture.files[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    setStatus("Choose an image file for your profile picture.");
    elements.profilePicture.value = "";
    return;
  }
  const reader = new FileReader();
  reader.onload = () => openProfileEditor(reader.result, { target: "profile" });
  reader.onerror = () => {
    setStatus("That image could not be opened.");
    elements.profilePicture.value = "";
  };
  reader.readAsDataURL(file);
}

function openProfileEditor(dataUrl, { target = "profile", contactId = "" } = {}) {
  const image = new Image();
  image.onload = () => {
    app.profileEditor.target = target;
    app.profileEditor.contactId = contactId;
    app.profileEditor.image = image;
    const editingBackground = target === "chat-background";
    elements.profileEditorTitle.textContent = editingBackground ? "Adjust chat background" : "Adjust profile picture";
    elements.profileEditorDescription.textContent = editingBackground
      ? "Drag, zoom, or rotate. The finished image will sync with this contact."
      : "Drag to reposition, zoom, or rotate before applying.";
    elements.profileEditorApply.textContent = editingBackground ? "Apply & Sync" : "Apply Photo";
    elements.profileEditorStage.classList.toggle("background-editor-mode", editingBackground);
    elements.profileEditorCanvas.setAttribute("aria-label", editingBackground ? "Chat background crop preview" : "Profile picture crop preview");
    resetProfileEditor();
    elements.profileEditorDialog.returnValue = "";
    elements.profileEditorDialog.showModal();
  };
  image.onerror = () => {
    setStatus("That image could not be opened.");
    elements.profilePicture.value = "";
  };
  image.src = dataUrl;
}

function resetProfileEditor() {
  app.profileEditor.rotation = 0;
  app.profileEditor.zoom = 1;
  app.profileEditor.offsetX = 0;
  app.profileEditor.offsetY = 0;
  app.profileEditor.dragging = false;
  elements.profileEditorZoom.value = "1";
  drawProfileEditor();
}

function updateProfileEditorZoom() {
  app.profileEditor.zoom = Number(elements.profileEditorZoom.value) || 1;
  drawProfileEditor();
}

function zoomProfileEditorWithWheel(event) {
  event.preventDefault();
  const direction = event.deltaY > 0 ? -0.08 : 0.08;
  const nextZoom = Math.min(3, Math.max(1, app.profileEditor.zoom + direction));
  app.profileEditor.zoom = nextZoom;
  elements.profileEditorZoom.value = String(nextZoom);
  drawProfileEditor();
}

function rotateProfileEditor(degrees) {
  app.profileEditor.rotation = (app.profileEditor.rotation + degrees + 360) % 360;
  app.profileEditor.offsetX = 0;
  app.profileEditor.offsetY = 0;
  drawProfileEditor();
}

function startProfileEditorDrag(event) {
  if (!app.profileEditor.image) return;
  app.profileEditor.dragging = true;
  app.profileEditor.pointerX = event.clientX;
  app.profileEditor.pointerY = event.clientY;
  elements.profileEditorCanvas.setPointerCapture(event.pointerId);
}

function moveProfileEditorDrag(event) {
  if (!app.profileEditor.dragging) return;
  const rect = elements.profileEditorCanvas.getBoundingClientRect();
  const scale = elements.profileEditorCanvas.width / Math.max(1, rect.width);
  app.profileEditor.offsetX += (event.clientX - app.profileEditor.pointerX) * scale;
  app.profileEditor.offsetY += (event.clientY - app.profileEditor.pointerY) * scale;
  app.profileEditor.pointerX = event.clientX;
  app.profileEditor.pointerY = event.clientY;
  drawProfileEditor();
}

function stopProfileEditorDrag(event) {
  app.profileEditor.dragging = false;
  if (elements.profileEditorCanvas.hasPointerCapture(event.pointerId)) {
    elements.profileEditorCanvas.releasePointerCapture(event.pointerId);
  }
}

function drawProfileEditor() {
  const image = app.profileEditor.image;
  if (!image) return;
  const canvas = elements.profileEditorCanvas;
  const context = canvas.getContext("2d");
  const quarterTurn = app.profileEditor.rotation % 180 !== 0;
  const rotatedWidth = quarterTurn ? image.height : image.width;
  const rotatedHeight = quarterTurn ? image.width : image.height;
  const coverScale = Math.max(canvas.width / rotatedWidth, canvas.height / rotatedHeight);
  const scale = coverScale * app.profileEditor.zoom;

  context.clearRect(0, 0, canvas.width, canvas.height);
  context.fillStyle = "#111827";
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.save();
  context.translate(
    canvas.width / 2 + app.profileEditor.offsetX,
    canvas.height / 2 + app.profileEditor.offsetY
  );
  context.rotate((app.profileEditor.rotation * Math.PI) / 180);
  context.scale(scale, scale);
  context.drawImage(image, -image.width / 2, -image.height / 2);
  context.restore();
}

async function applyProfileEditor() {
  const source = elements.profileEditorCanvas;
  const output = document.createElement("canvas");
  const editingBackground = app.profileEditor.target === "chat-background";
  output.width = editingBackground ? 640 : 96;
  output.height = editingBackground ? 640 : 96;
  output.getContext("2d").drawImage(source, 0, 0, output.width, output.height);
  const maxLength = editingBackground ? 260000 : 18000;
  let quality = editingBackground ? 0.68 : 0.78;
  let dataUrl = output.toDataURL("image/jpeg", quality);
  while (dataUrl.length > maxLength && quality > 0.36) {
    quality -= 0.08;
    dataUrl = output.toDataURL("image/jpeg", quality);
  }
  if (dataUrl.length > maxLength) {
    setStatus("That crop is still too large. Try zooming in or choosing another image.");
    return;
  }
  if (editingBackground) {
    const contact = app.state.contacts.find((item) => item.id === app.profileEditor.contactId);
    if (!contact) {
      setStatus("That contact is no longer available.");
      return;
    }
    const color = contact.chatBackground || elements.contactChatBackground.value;
    await updateContact(contact.id, { chatBackground: color, chatBackgroundImage: dataUrl });
    app.state = await loadState();
    applyConversationBackground();
    try {
      await sendSharedChatBackground(contact, { color, image: dataUrl });
      showToast("Chat background synced.");
    } catch (error) {
      setStatus(`Background saved locally, but sync failed: ${error.message}`);
    }
    elements.contactChatBackgroundImage.value = "";
    elements.profileEditorDialog.close("apply");
    return;
  }
  app.pendingProfilePicture = dataUrl;
  elements.profilePreview.src = dataUrl;
  setProfileSaveButton("Save");
  elements.profileEditorDialog.close("apply");
}

function handleProfileEditorClosed() {
  const target = app.profileEditor.target;
  app.profileEditor.dragging = false;
  app.profileEditor.image = null;
  app.profileEditor.target = "profile";
  app.profileEditor.contactId = "";
  elements.profileEditorStage.classList.remove("background-editor-mode");
  if (elements.profileEditorDialog.returnValue !== "apply") {
    if (target === "chat-background") elements.contactChatBackgroundImage.value = "";
    else elements.profilePicture.value = "";
  }
}

// Marks the profile picture for removal; Save commits the change.
function removeProfilePicture() {
  app.pendingProfilePicture = "";
  elements.profilePreview.src = "../assets/icon-128.png";
  elements.profilePicture.value = "";
  setProfileSaveButton("Save");
}

// Saves display name and profile picture together, with clear feedback.
async function saveProfileSettings() {
  const nextDisplayName = elements.localDisplayName.value.trim() || "Local User";
  const currentDisplayName = app.state.settings.displayName;
  const currentProfilePicture = app.state.settings.profilePicture;
  const nextProfilePicture = sanitizeProfilePicture(app.pendingProfilePicture ?? currentProfilePicture);
  const hasDisplayNameChange = nextDisplayName !== currentDisplayName;
  const hasProfilePictureChange = nextProfilePicture !== currentProfilePicture;

  if (!hasDisplayNameChange && !hasProfilePictureChange) {
    showProfileSaveFeedback("No changes made");
    return;
  }

  await saveSettings({
    displayName: nextDisplayName,
    profilePicture: nextProfilePicture
  });
  app.pendingProfilePicture = null;
  elements.profilePicture.value = "";
  app.state = await loadState();
  renderSettings();
  app.peer.publishProfile(currentProfilePayload());
  showProfileSaveFeedback("Saved!");
}

async function submitSupportReport(event) {
  event.preventDefault();
  const reportType = elements.supportType.value;
  const reportMessage = elements.supportMessage.value.trim();
  if (!reportMessage) {
    elements.supportFeedback.textContent = "Type a message before submitting.";
    elements.supportMessage.focus();
    return;
  }

  elements.supportFeedback.textContent = "Submitting securely...";
  try {
    let evidence = "";
    const file = elements.supportEvidence.files?.[0];
    if (file) {
      if (!file.type.startsWith("image/")) throw new Error("Evidence must be an image.");
      evidence = await resizeOutgoingImage(await fileToDataUrl(file));
      if (evidence.length > 250000) throw new Error("That evidence image is too large.");
    }
    app.peer.submitReport(reportType, reportMessage, evidence);
    elements.supportMessage.value = "";
    elements.supportEvidence.value = "";
    elements.supportFeedback.textContent = "Report submitted to Bypassium Support.";
  } catch (error) {
    elements.supportFeedback.textContent = error.message || "The report could not be submitted.";
  }
}

function handleServiceAnnouncement(message) {
  const text = [message.title, message.message].filter(Boolean).join(": ");
  if (!text) return;
  setStatus(text);
  showToast(text);
  chrome.runtime.sendMessage({ type: "notify", title: message.title || "Bypassium announcement", body: message.message || text });
}

function handleAdminNotice(message) {
  const text = [message.title, message.message].filter(Boolean).join(": ");
  if (!text) return;
  setStatus(text);
  showToast(text);
  chrome.runtime.sendMessage({ type: "notify", title: message.title || "Bypassium notice", body: message.message || text });
}

// Renders settings values from local storage.
function renderSettings() {
  elements.themeSelect.value = app.state.settings.theme;
  elements.localDisplayName.value = app.state.settings.displayName;
  elements.profilePreview.src = app.state.settings.profilePicture || "../assets/icon-128.png";
  setProfileSaveButton("Save");
}

// Renders the sidebar palette controls from local settings.
function renderPalette() {
  const palette = app.state.settings.palette;
  elements.paletteAccent.value = palette.accent;
  elements.paletteAccent2.value = palette.accent2;
  elements.paletteBackground.value = palette.background;
  elements.themePresets.querySelectorAll("[data-theme-preset]").forEach((button) => {
    const preset = THEME_PRESETS[button.dataset.themePreset];
    const selected = preset
      && app.state.settings.theme === preset.theme
      && palette.custom
      && palette.accent.toLowerCase() === preset.accent
      && palette.accent2.toLowerCase() === preset.accent2
      && palette.background.toLowerCase() === preset.background;
    button.classList.toggle("selected", Boolean(selected));
    button.setAttribute("aria-pressed", String(Boolean(selected)));
  });
}

async function applyThemePreset(event) {
  const button = event.target.closest("[data-theme-preset]");
  const preset = THEME_PRESETS[button?.dataset.themePreset];
  if (!preset) return;
  const palette = {
    accent: preset.accent,
    accent2: preset.accent2,
    background: preset.background,
    custom: true
  };
  await saveSettings({ theme: preset.theme, palette });
  app.state = await loadState();
  elements.themeSelect.value = preset.theme;
  applyTheme(preset.theme);
  renderPalette();
}

function currentMessagePresentation() {
  return sanitizeMessagePresentation(app.state.settings.messageStyle);
}

function sanitizeMessagePresentation(value = {}) {
  const colorId = Object.prototype.hasOwnProperty.call(MESSAGE_COLORS, value?.colorId)
    ? value.colorId
    : "blue";
  const fontId = Number.isInteger(Number(value?.fontId))
    ? Math.min(MESSAGE_FONTS.length - 1, Math.max(0, Number(value.fontId)))
    : 0;
  return { colorId, fontId };
}

function renderMessageStyleControls() {
  const presentation = currentMessagePresentation();
  elements.messageColorPresets.querySelectorAll("[data-message-color]").forEach((button) => {
    const selected = button.dataset.messageColor === presentation.colorId;
    button.classList.toggle("selected", selected);
    button.setAttribute("aria-pressed", String(selected));
  });
  elements.messageFont.value = String(presentation.fontId);
  applyMessagePresentation(elements.messageStylePreview, presentation);
}

async function selectMessageColor(event) {
  const button = event.target.closest("[data-message-color]");
  if (!button || !MESSAGE_COLORS[button.dataset.messageColor]) return;
  await saveSettings({
    messageStyle: {
      ...currentMessagePresentation(),
      colorId: button.dataset.messageColor
    }
  });
  app.state = await loadState();
  renderMessageStyleControls();
}

async function selectMessageFont() {
  await saveSettings({
    messageStyle: {
      ...currentMessagePresentation(),
      fontId: Number(elements.messageFont.value)
    }
  });
  app.state = await loadState();
  renderMessageStyleControls();
}

function applyMessagePresentation(element, value) {
  const presentation = sanitizeMessagePresentation(value);
  const color = MESSAGE_COLORS[presentation.colorId];
  element.style.setProperty("--message-custom-background", color);
  element.style.setProperty("--message-custom-text", isDarkColor(color) ? "#ffffff" : "#111111");
  element.style.fontFamily = MESSAGE_FONTS[presentation.fontId];
  element.classList.add("custom-message-presentation");
}

// Applies and persists the custom palette while the user changes color inputs.
async function updatePaletteLive() {
  const palette = {
    accent: elements.paletteAccent.value,
    accent2: elements.paletteAccent2.value,
    background: elements.paletteBackground.value,
    custom: true
  };
  app.state = {
    ...app.state,
    settings: {
      ...app.state.settings,
      palette
    }
  };
  applyPalette(palette);
  await saveSettings({
    palette
  });
  renderPalette();
}

// Restores the built-in palette for the active theme.
async function resetPalette() {
  await saveSettings({
    palette: {
      accent: "#2563eb",
      accent2: "#0f766e",
      background: "#f6f7fb",
      custom: false
    }
  });
  app.state = await loadState();
  applyTheme(app.state.settings.theme);
  renderPalette();
}

// Persists and renders the local online/invisible preference.
async function togglePresence(event) {
  const presence = event.currentTarget.checked ? "invisible" : "online";
  await saveSettings({ presence });
  app.state = await loadState();
  renderPresence();
}

function renderPresence() {
  const invisible = app.state.settings.presence === "invisible";
  elements.presenceToggles.forEach((toggle) => {
    toggle.checked = invisible;
  });
  elements.presenceLabels.forEach((label) => {
    label.textContent = invisible ? "Invisible" : "Online";
  });
}

function syncWatchedPeers() {
  app.peer.watchContacts(watchedPeerIds());
}

function watchedPeerIds() {
  const ids = new Set(app.state.contacts.map((contact) => contact.id));
  for (const group of app.state.groups) {
    for (const memberId of group.members || []) ids.add(memberId);
  }
  ids.delete(app.identity.id);
  return [...ids].filter(isValidBypassiumId);
}

// Blocks or unblocks the currently selected contact on this device.
async function toggleBlockCurrentContact() {
  const contact = currentContact();
  if (!contact) return;
  await updateContact(contact.id, { blocked: !contact.blocked, status: !contact.blocked ? "blocked" : "offline" });
  app.state = await loadState();
  renderAll();
}

// Temporarily changes the profile save button label after a save attempt.
function showProfileSaveFeedback(label) {
  setProfileSaveButton(label);
  clearTimeout(app.profileFeedbackTimer);
  app.profileFeedbackTimer = setTimeout(() => setProfileSaveButton("Save"), 2000);
}

function setProfileSaveButton(label) {
  elements.saveProfileSettings.textContent = label;
}

// Requests notification permission only when the platform supports it.
async function requestNotificationPermission() {
  if ("Notification" in window && Notification.permission === "default") await Notification.requestPermission();
}

function currentContact() {
  return app.state.contacts.find((contact) => contact.id === app.activeContactId);
}

function currentGroup() {
  return app.state.groups.find((group) => group.id === app.activeGroupId);
}

function sortedConversations(items = []) {
  return [...items].sort((first, second) => (
    Number(Boolean(second.pinned)) - Number(Boolean(first.pinned))
    || String(second.updatedAt || second.createdAt || "").localeCompare(String(first.updatedAt || first.createdAt || ""))
  ));
}

function sortedMessageContacts() {
  return [...app.state.contacts].sort((first, second) => (
    Number(Boolean(second.pinned)) - Number(Boolean(first.pinned))
    || latestMessageTime(app.state.conversations[second.id]) - latestMessageTime(app.state.conversations[first.id])
    || String(second.createdAt || "").localeCompare(String(first.createdAt || ""))
  ));
}

function sortedMessageGroups() {
  return [...app.state.groups].sort((first, second) => (
    Number(Boolean(second.pinned)) - Number(Boolean(first.pinned))
    || latestMessageTime(app.state.groupConversations[second.id]) - latestMessageTime(app.state.groupConversations[first.id])
    || String(second.updatedAt || "").localeCompare(String(first.updatedAt || ""))
  ));
}

function latestMessageTime(messages = []) {
  const latest = messages[messages.length - 1];
  const value = Date.parse(latest?.sentAt || "");
  return Number.isFinite(value) ? value : 0;
}

function canAdministerGroup(group) {
  return Boolean(group && (group.ownerId === app.identity.id || group.admins?.includes(app.identity.id)));
}

function applyConversationBackground() {
  const conversation = currentGroup() || currentContact();
  const color = /^#[0-9a-f]{6}$/i.test(conversation?.chatBackground || "") ? conversation.chatBackground : "";
  const image = sanitizeChatBackgroundImage(conversation?.chatBackgroundImage);
  elements.messages.style.backgroundColor = color;
  elements.messages.style.backgroundImage = image
    ? `linear-gradient(rgb(0 0 0 / 0.18), rgb(0 0 0 / 0.18)), url("${image}")`
    : "";
  elements.messages.classList.toggle("custom-chat-background", Boolean(color || image));
  elements.messages.classList.toggle("custom-chat-background-image", Boolean(image));
}

function isCurrentUserMentioned(text = "") {
  const displayName = String(app.state.settings.displayName || "Local User").trim();
  if (!displayName) return false;
  return new RegExp(`(^|\\s)@${escapeRegExp(displayName)}(?=\\s|$|[.,!?])`, "i").test(String(text));
}

function pendingContact() {
  return app.state.contacts.find((contact) => contact.id === app.pendingContactId);
}

function pendingGroup() {
  return app.state.groups.find((group) => group.id === app.pendingGroupId);
}

function contactStatusLabel(contact) {
  if (contact.blocked) return "blocked";
  if (contact.accepted === false) return "message request";
  if (contact.notifications === false) return "notifications off";
  return contact.status || "offline";
}

function contactDialogStatusText(contact) {
  if (contact.accepted === false) return "Message request - add back to reply";
  return contact.blocked ? "Blocked" : contact.status || "offline";
}

function isNearMessagesBottom() {
  const remaining = elements.messages.scrollHeight - elements.messages.scrollTop - elements.messages.clientHeight;
  return remaining < 96;
}

function scrollMessagesToBottom() {
  elements.messages.scrollTop = elements.messages.scrollHeight;
}

function handleMessagesScroll() {
  if (isNearMessagesBottom()) clearNewMessagesBelow();
}

function showNewMessagesBelow(count) {
  app.newMessagesBelow = count;
  elements.newMessagesJump.textContent = `Down ${formatUnreadCount(count)} new message${count === 1 ? "" : "s"}`;
  elements.newMessagesJump.classList.remove("hidden");
}

function clearNewMessagesBelow() {
  app.newMessagesBelow = 0;
  elements.newMessagesJump.classList.add("hidden");
}

function jumpToNewMessages() {
  scrollMessagesToBottom();
  clearNewMessagesBelow();
}

function nextUnreadCount(contact, peerId, alreadySaved) {
  const currentCount = Number(contact?.unreadCount || 0);
  if (alreadySaved) return currentCount;
  if (app.activeContactId === peerId) return 0;
  return currentCount + 1;
}

function nextGroupUnreadCount(group, groupId, alreadySaved) {
  const currentCount = Number(group?.unreadCount || 0);
  if (alreadySaved) return currentCount;
  if (app.activeGroupId === groupId) return 0;
  return currentCount + 1;
}

async function clearGroupUnreadCount(groupId) {
  const group = app.state.groups.find((item) => item.id === groupId);
  if (!group?.unreadCount) return;
  await updateGroup(groupId, { unreadCount: 0 });
  app.state = await loadState();
  renderMessageButtonUnread();
}

async function sendVisibleReadReceipts(contactId) {
  const conversation = app.state.conversations[contactId] || [];
  const unread = conversation.filter((message) => message.direction === "inbound" && message.messageId && !message.readReceiptSent);
  for (const message of unread) {
      app.peer.sendReadReceipt(contactId, message.messageId);
  }
  if (unread.length) {
    await markDirectReadReceiptsSent(contactId, unread.map((message) => message.messageId));
    app.state = await loadState();
  }
}

async function sendVisibleGroupReadReceipts(groupId) {
  const conversation = app.state.groupConversations[groupId] || [];
  const unread = conversation.filter((message) => (
    message.direction === "inbound" && message.messageId && message.senderId && !message.readReceiptSent
  ));
  for (const message of unread) {
      app.peer.sendGroupReadReceipt(groupId, message.senderId, message.messageId);
  }
  if (unread.length) {
    await markGroupReadReceiptsSent(groupId, unread.map((message) => message.messageId));
    app.state = await loadState();
  }
}

async function reloadMessages() {
  const reloadButtons = [elements.reloadMessages, elements.reloadAllMessages];
  if (reloadButtons.some((button) => button.disabled)) return;
  reloadButtons.forEach((button) => {
    button.disabled = true;
    button.classList.add("spinning");
  });
  try {
    await app.peer.connectDirectory(SIGNALING_SERVER_URL, watchedPeerIds());
    app.peer.refresh();
    await retryQueuedMessages();
    showToast("Refreshing messages...");
  } catch (error) {
    setStatus(`Refresh failed: ${error.message}`);
  } finally {
    reloadButtons.forEach((button) => {
      button.disabled = false;
      button.classList.remove("spinning");
    });
  }
}

async function retryQueuedMessages() {
  const state = await loadState();
  const retries = [];
  for (const contact of state.contacts) {
    for (const message of state.conversations[contact.id] || []) {
      if (message.direction !== "outbound" || message.deliveryStatus !== "queued") continue;
      retries.push(app.peer.sendText(
        { text: message.text, attachment: message.attachment, replyTo: message.replyTo, presentation: message.presentation },
        { to: contact.id, publicKeyJwk: contact.publicKeyJwk, messageId: message.messageId, sentAt: message.sentAt }
      ));
    }
  }
  for (const group of state.groups) {
    for (const message of state.groupConversations[group.id] || []) {
      if (message.direction !== "outbound" || message.deliveryStatus !== "queued") continue;
      retries.push(app.peer.sendGroupText(
        group,
        state.contacts,
        { text: message.text, attachment: message.attachment, replyTo: message.replyTo, presentation: message.presentation },
        { messageId: message.messageId, sentAt: message.sentAt }
      ));
    }
  }
  const results = await Promise.allSettled(retries);
  const failed = results.filter((result) => result.status === "rejected");
  if (failed.length) setStatus(`${failed.length} queued message${failed.length === 1 ? "" : "s"} still waiting for a connection.`);
}

function openMessageSearch() {
  elements.messageSearchBar.classList.remove("hidden");
  elements.messageSearchInput.focus();
}

function closeMessageSearch() {
  app.messageSearchQuery = "";
  elements.messageSearchInput.value = "";
  elements.messageSearchBar.classList.add("hidden");
  renderConversation();
}

function updateMessageSearch() {
  app.messageSearchQuery = elements.messageSearchInput.value.trim().toLowerCase();
  renderConversation();
}

function filterMessages(messages, group) {
  if (!app.messageSearchQuery) return messages;
  return messages.filter((message) => {
    const sender = group ? groupMessageSender(message.senderId).name : "";
    return [message.text, message.attachment?.name, message.replyTo?.preview, sender]
      .filter(Boolean)
      .some((value) => String(value).toLowerCase().includes(app.messageSearchQuery));
  });
}

function updateSearchResultCount(visible, total) {
  elements.messageSearchCount.textContent = app.messageSearchQuery ? `${visible} of ${total}` : "";
}

function renderMentionSuggestions() {
  const group = currentGroup();
  const value = elements.messageInput.value;
  const mentionStart = value.lastIndexOf("@");
  if (!group || mentionStart < 0 || /\s/.test(value.slice(mentionStart + 1))) {
    elements.mentionSuggestions.classList.add("hidden");
    elements.mentionSuggestions.innerHTML = "";
    return;
  }
  const query = value.slice(mentionStart + 1).toLowerCase();
  const people = group.members
    .filter((id) => id !== app.identity.id)
    .map((id) => ({ id, ...groupMessageSender(id) }))
    .filter((person) => person.name.toLowerCase().includes(query))
    .slice(0, 6);
  if (!people.length) {
    elements.mentionSuggestions.classList.add("hidden");
    return;
  }
  elements.mentionSuggestions.innerHTML = people.map((person) => `
    <button type="button" data-mention-id="${escapeHtml(person.id)}">
      <span class="avatar">${person.avatar ? `<img src="${person.avatar}" alt="">` : escapeHtml(person.name.slice(0, 1).toUpperCase())}</span>
      <span>${escapeHtml(person.name)}</span>
    </button>
  `).join("");
  elements.mentionSuggestions.classList.remove("hidden");
  elements.mentionSuggestions.querySelectorAll("[data-mention-id]").forEach((button) => {
    button.addEventListener("click", () => {
      const person = people.find((item) => item.id === button.dataset.mentionId);
      if (!person) return;
      elements.messageInput.value = `${value.slice(0, mentionStart)}@${person.name} `;
      elements.mentionSuggestions.classList.add("hidden");
      elements.messageInput.focus();
      handleTypingInput();
    });
  });
}

function handleTypingInput() {
  const text = elements.messageInput.value.trim();
  const contact = currentContact();
  const group = currentGroup();
  if (!contact && !group) return;
  const target = group ? { groupId: group.id } : { to: contact.id };
  const targetKey = group ? `group:${group.id}` : `contact:${contact.id}`;

  if (app.lastTypingTarget !== targetKey) {
    sendTypingStopped();
    app.lastTypingTarget = targetKey;
  }

  app.peer.sendTyping({ ...target, isTyping: Boolean(text) });
  clearTimeout(app.typingStopTimer);
  if (text) {
    app.typingStopTimer = setTimeout(() => {
      app.peer.sendTyping({ ...target, isTyping: false });
    }, 1600);
  }
}

function sendTypingStopped() {
  clearTimeout(app.typingStopTimer);
  if (!app.lastTypingTarget) return;
  if (app.lastTypingTarget.startsWith("group:")) {
    app.peer.sendTyping({ groupId: app.lastTypingTarget.slice(6), isTyping: false });
  } else {
    app.peer.sendTyping({ to: app.lastTypingTarget.slice(8), isTyping: false });
  }
  app.lastTypingTarget = null;
}

function renderTypingIndicator(group, contact) {
  const people = typingPeople(group, contact);
  if (!people.length) return;
  const indicator = document.createElement("article");
  indicator.className = "typing-indicator";
  indicator.innerHTML = `
    <span class="typing-avatars">${people.slice(0, 3).map(renderTypingAvatar).join("")}</span>
    <span class="typing-dots" aria-hidden="true"><i></i><i></i><i></i></span>
    <span>${escapeHtml(formatTypingNames(people.map((person) => person.name)))} typing</span>
  `;
  elements.messages.append(indicator);
}

function renderGroupMessageRow(message, group) {
  const row = document.createElement("div");
  row.className = `group-message-row ${message.direction}`;
  const sender = groupMessageSender(message.senderId);
  const avatar = document.createElement("span");
  avatar.className = "group-message-avatar";
  avatar.title = sender.name;
  avatar.innerHTML = sender.avatar
    ? `<img src="${sender.avatar}" alt="">`
    : `<span>${escapeHtml(sender.name.slice(0, 1).toUpperCase())}</span>`;
  const bubble = renderMessageBubble(message, { group, senderLabelText: sender.name });
  row.append(avatar, bubble);
  return row;
}

function groupMessageSender(senderId) {
  if (senderId === app.identity.id) {
    return {
      name: app.state.settings.displayName || "You",
      avatar: app.state.settings.profilePicture || ""
    };
  }
  const contact = app.state.contacts.find((item) => item.id === senderId);
  return {
    name: contact?.name || senderId || "Unknown",
    avatar: contact?.avatar || ""
  };
}

function renderMessageBubble(message, { group = null, contact = null, senderLabelText = "" } = {}) {
  const bubble = document.createElement("article");
  bubble.className = `message ${message.direction}`;
  if (message.presentation) applyMessagePresentation(bubble, message.presentation);
  bubble.innerHTML = `
    ${group ? `<strong class="group-message-sender">${escapeHtml(senderLabelText)}</strong>` : ""}
    ${message.replyTo ? renderReplyChip(message.replyTo) : ""}
    ${message.attachment ? renderAttachment(message.attachment) : ""}
    ${message.text ? `<p>${renderMessageText(message.text, group)}</p>` : ""}
    ${renderReactions(message)}
    <span class="message-meta">
      <time>${formatMessageTime(message.sentAt)}</time>
      ${message.direction === "outbound" ? `<span class="delivery-status">${escapeHtml(deliveryStatusLabel(message, group))}</span>` : ""}
    </span>
  `;
  bubble.querySelector(".attachment-frame")?.addEventListener("click", (event) => {
    event.stopPropagation();
    openImageViewer(message.attachment);
  });
  initializeVoiceNotePlayers(bubble);
  bubble.querySelectorAll(".message-reaction").forEach((reaction) => {
    reaction.addEventListener("click", async (event) => {
      event.stopPropagation();
      await reactToLocalMessage(message, { group, contact }, reaction.dataset.emoji);
    });
  });
  const openActions = (event) => {
    event.preventDefault();
    openMessageActions(message, { group, contact }, bubble);
  };
  bubble.addEventListener("dblclick", openActions);
  bubble.addEventListener("contextmenu", openActions);
  bubble.addEventListener("mouseenter", () => {
    clearTimeout(app.messageActionTimer);
    app.messageActionTimer = setTimeout(() => openMessageActions(message, { group, contact }, bubble), 900);
  });
  bubble.addEventListener("mouseleave", () => clearTimeout(app.messageActionTimer));
  return bubble;
}

function renderMessageText(text, group) {
  const names = group
    ? group.members.map((memberId) => groupMessageSender(memberId).name).filter(Boolean)
    : [];
  names.push(app.state.settings.displayName || "Local User");
  const uniqueNames = [...new Set(names.map((name) => name.trim()).filter(Boolean))]
    .sort((first, second) => second.length - first.length);
  if (!uniqueNames.length) return escapeHtml(text);
  const pattern = new RegExp(`(@(?:${uniqueNames.map(escapeRegExp).join("|")}))`, "gi");
  return String(text).split(pattern).map((part) => (
    part.startsWith("@") && uniqueNames.some((name) => part.slice(1).toLowerCase() === name.toLowerCase())
      ? `<mark class="mention">${escapeHtml(part)}</mark>`
      : escapeHtml(part)
  )).join("");
}

function renderReactions(message) {
  const reactions = { ...(message.reactions || {}) };
  if (message.reaction && !reactions[message.reaction]) reactions[message.reaction] = ["legacy"];
  const entries = Object.entries(reactions).filter(([, reactors]) => Array.isArray(reactors) && reactors.length);
  if (!entries.length) return "";
  return `<span class="message-reactions">${entries.map(([emoji, reactors]) => `
    <button type="button" class="message-reaction ${reactors.includes(app.identity.id) ? "mine" : ""}" data-emoji="${escapeHtml(emoji)}" title="${reactors.length} reaction${reactors.length === 1 ? "" : "s"}">
      <span>${escapeHtml(emoji)}</span><strong>${reactors.length}</strong>
    </button>
  `).join("")}</span>`;
}

function deliveryStatusLabel(message, group) {
  const status = message.deliveryStatus || (message.readAt ? "read" : "queued");
  if (!group) return status.slice(0, 1).toUpperCase() + status.slice(1);
  const total = Math.max(0, Number(message.deliveryRecipientCount || group.members.length - 1));
  if (!total) return status.slice(0, 1).toUpperCase() + status.slice(1);
  const states = Object.values(message.deliveryByPeer || {});
  const read = states.filter((value) => value === "read").length;
  const delivered = states.filter((value) => value === "delivered" || value === "read").length;
  if (read) return `Read ${read}/${total}`;
  if (delivered) return `Delivered ${delivered}/${total}`;
  return status.slice(0, 1).toUpperCase() + status.slice(1);
}

function renderReplyChip(replyTo) {
  return `
    <div class="reply-chip">
      ${replyTo.image ? `<img class="reply-thumb" src="${escapeHtml(replyTo.image)}" alt="">` : ""}
      <span>${escapeHtml(replyTo.sender || "Reply")}: ${escapeHtml(replyTo.preview || "")}</span>
    </div>
  `;
}

function renderAttachment(attachment) {
  const audioSource = attachment?.dataUrl?.startsWith("data:audio/") ? attachment.dataUrl : "";
  if (audioSource) return renderVoiceNotePlayer(attachment);
  const source = attachment?.dataUrl?.startsWith("data:image/") ? attachment.dataUrl : attachment?.url;
  if (!source) return "";
  return `
    <button class="attachment-frame" type="button" title="${escapeHtml(attachment.name || "Image attachment")}">
      <img src="${escapeHtml(source)}" alt="${escapeHtml(attachment.name || "Image attachment")}" />
    </button>
  `;
}

const VOICE_WAVEFORM_HEIGHTS = [7, 13, 9, 18, 12, 21, 10, 16, 23, 14, 19, 8, 17, 11, 22, 13, 18, 9, 15, 7];

function renderVoiceNotePlayer(attachment, preview = false) {
  const source = attachment?.dataUrl?.startsWith("data:audio/") ? attachment.dataUrl : "";
  if (!source) return "";
  const bars = VOICE_WAVEFORM_HEIGHTS.map((height) => `<i style="height:${height}px"></i>`).join("");
  return `
    <div class="voice-note-player ${preview ? "voice-note-preview-player" : ""}" data-duration-ms="${Math.max(0, Number(attachment.durationMs) || 0)}">
      <button type="button" class="voice-play-button" aria-label="Play voice note">${voicePlaybackIcon(false)}</button>
      <button type="button" class="voice-waveform" aria-label="Seek voice note">
        ${bars}
      </button>
      <button type="button" class="voice-speed-button" aria-label="Change playback speed">1x</button>
      <time class="voice-playback-time">${escapeHtml(formatVoiceDuration(attachment.durationMs))}</time>
      <audio class="voice-note-audio" preload="metadata" src="${escapeHtml(source)}"></audio>
    </div>
  `;
}

function voicePlaybackIcon(playing) {
  return playing
    ? `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14M16 5v14"></path></svg>`
    : `<svg viewBox="0 0 24 24" aria-hidden="true"><path class="voice-play-fill" d="m8 5 11 7-11 7Z"></path></svg>`;
}

// Turns each rendered audio attachment into a compact play/pause waveform player.
function initializeVoiceNotePlayers(root) {
  root.querySelectorAll(".voice-note-player").forEach((player) => {
    if (player.dataset.ready === "true") return;
    player.dataset.ready = "true";
    const audio = player.querySelector(".voice-note-audio");
    const playButton = player.querySelector(".voice-play-button");
    const waveform = player.querySelector(".voice-waveform");
    const speedButton = player.querySelector(".voice-speed-button");
    const time = player.querySelector(".voice-playback-time");
    const bars = [...waveform.querySelectorAll("i")];
    const storedDuration = Math.max(0, Number(player.dataset.durationMs || 0) / 1000);
    let speedIndex = 0;
    const speeds = [1, 1.5, 2];

    const duration = () => (
      Number.isFinite(audio.duration) && audio.duration > 0 ? audio.duration : storedDuration
    );
    const updatePlayer = () => {
      const total = duration();
      const progress = total > 0 ? Math.min(1, audio.currentTime / total) : 0;
      bars.forEach((bar, index) => {
        bar.classList.toggle("played", index / Math.max(1, bars.length - 1) <= progress);
      });
      time.textContent = audio.currentTime > 0
        ? `${formatVoiceDuration(audio.currentTime * 1000)}/${formatVoiceDuration(total * 1000)}`
        : formatVoiceDuration(total * 1000);
      playButton.innerHTML = voicePlaybackIcon(!audio.paused && !audio.ended);
      playButton.setAttribute("aria-label", audio.paused ? "Play voice note" : "Pause voice note");
      player.classList.toggle("playing", !audio.paused && !audio.ended);
    };

    playButton.addEventListener("click", async (event) => {
      event.stopPropagation();
      if (!audio.paused) {
        audio.pause();
        return;
      }
      document.querySelectorAll(".voice-note-audio").forEach((other) => {
        if (other !== audio && !other.paused) other.pause();
      });
      try {
        await audio.play();
      } catch (error) {
        const detail = error?.message || "Chrome could not decode this voice note.";
        setStatus("This voice note could not be played.");
        void updateDiagnostics({ failure: `Voice playback failed: ${detail}` });
      }
    });
    waveform.addEventListener("click", (event) => {
      event.stopPropagation();
      const total = duration();
      if (!total) return;
      const bounds = waveform.getBoundingClientRect();
      audio.currentTime = Math.max(0, Math.min(total, ((event.clientX - bounds.left) / bounds.width) * total));
      updatePlayer();
    });
    speedButton.addEventListener("click", (event) => {
      event.stopPropagation();
      speedIndex = (speedIndex + 1) % speeds.length;
      audio.playbackRate = speeds[speedIndex];
      speedButton.textContent = `${speeds[speedIndex]}x`;
    });
    ["play", "pause", "ended", "timeupdate", "loadedmetadata", "durationchange"].forEach((name) => {
      audio.addEventListener(name, updatePlayer);
    });
    audio.addEventListener("error", () => {
      setStatus("This voice note is damaged or uses an unsupported audio format.");
      void updateDiagnostics({ failure: `Voice playback error code ${audio.error?.code || "unknown"}.` });
    });
    ["mouseenter", "click", "dblclick", "contextmenu"].forEach((name) => {
      player.addEventListener(name, (event) => {
        clearTimeout(app.messageActionTimer);
        if (name !== "mouseenter") event.stopPropagation();
      });
    });
    updatePlayer();
  });
}

function openAttachmentFromClick(event) {
  const frame = event.target.closest(".attachment-frame");
  if (frame) event.stopPropagation();
}

function openImageViewer(attachment) {
  const source = attachment?.dataUrl?.startsWith("data:image/") ? attachment.dataUrl : attachment?.url;
  if (!source) return;
  elements.imageViewerImage.src = source;
  elements.imageViewerImage.alt = attachment.name || "Attachment preview";
  elements.imageDownload.href = source;
  elements.imageDownload.download = attachment.name || "bypassium-image";
  elements.imageViewerDialog.showModal();
}

function isVoiceRecording() {
  return ["recording", "stopping"].includes(app.voiceRecording?.status);
}

function syncComposerControls(canType = Boolean(currentGroup() || (currentContact() && !currentContact().blocked && currentContact().accepted !== false))) {
  const recording = isVoiceRecording();
  const recordingBusy = Boolean(app.voiceRecording) || app.voiceRecordingPending || app.voicePermissionRequestPending;
  elements.messageInput.disabled = !canType || recordingBusy;
  elements.attachButton.disabled = !canType || recordingBusy;
  elements.voiceNoteButton.disabled = !canType || app.voiceRecordingPending || (!recording && Boolean(app.selectedAttachment));
  elements.sendMessageButton.disabled = !canType || recordingBusy;
}

async function toggleVoiceRecording() {
  if (isVoiceRecording()) {
    stopVoiceRecording();
    return;
  }
  await startVoiceRecording();
}

// Starts a locally captured voice note. Audio is attached only after recording stops.
async function startVoiceRecording({ permissionGranted = false, target = app.pendingVoiceTarget || "conversation" } = {}) {
  if (app.voiceRecordingPending || app.voicePermissionRequestPending) return;
  if (target === "conversation" && !currentContact() && !currentGroup()) return;
  app.pendingVoiceTarget = target;
  const selectedAttachment = target === "multi-send" ? app.multiSendAttachment : app.selectedAttachment;
  if (selectedAttachment) {
    setStatus("Remove the current attachment before recording a voice note.");
    return;
  }

  if (!permissionGranted) {
    app.voicePermissionRequestPending = true;
    syncComposerControls();
    try {
      const permissionState = await microphonePermissionState();
      if (permissionState !== "granted") {
        const response = await chrome.runtime.sendMessage({
          target: "voice-recorder-service",
          type: "voice-recorder-request-permission"
        });
        if (!response?.ok) throw new Error(response?.error || "Chrome could not open microphone setup.");
        setStatus("Select Allow microphone in the Bypassium setup window.");
        return;
      }
    } catch (error) {
      setStatus(error.message || "Chrome could not open microphone setup.");
      return;
    } finally {
      app.voicePermissionRequestPending = false;
      syncComposerControls();
    }
  }

  const requestId = crypto.randomUUID();
  app.voiceRecording = {
    requestId,
    target,
    status: "starting",
    startedAt: 0,
    interval: null
  };
  app.voiceRecordingPending = true;
  updateVoiceRecordingUi();
  syncComposerControls();
  try {
    const response = await chrome.runtime.sendMessage({
      target: "voice-recorder-service",
      type: "voice-recorder-start",
      requestId
    });
    if (!response?.ok) throw new Error(response?.error || "Chrome could not open the voice recorder.");
    setStatus("Waiting for microphone access...");
  } catch (error) {
    clearVoiceRecordingState();
    app.voiceRecordingPending = false;
    setStatus(error.message || "Chrome could not open the voice recorder.");
  }
}

function stopVoiceRecording() {
  const recording = app.voiceRecording;
  if (!recording) return;
  recording.status = "stopping";
  updateVoiceRecordingUi();
  void sendVoiceRecorderCommand("voice-recorder-stop", recording.requestId);
}

function cancelVoiceRecording() {
  const recording = app.voiceRecording;
  if (!recording) return;
  recording.status = "cancelling";
  updateVoiceRecordingUi();
  void sendVoiceRecorderCommand("voice-recorder-cancel", recording.requestId);
}

function discardVoiceRecording() {
  const recording = app.voiceRecording;
  if (!recording) return;
  void sendVoiceRecorderCommand("voice-recorder-cancel", recording.requestId);
  clearVoiceRecordingState();
}

async function sendVoiceRecorderCommand(type, requestId) {
  try {
    const response = await chrome.runtime.sendMessage({
      target: "voice-recorder-service",
      type,
      requestId
    });
    if (!response?.ok) throw new Error(response?.error || "Voice recorder command failed.");
  } catch (error) {
    clearVoiceRecordingState();
    setStatus(error.message || "Chrome lost the voice recorder.");
  }
}

// Receives status and the completed audio attachment from the offscreen recorder.
function handleVoiceRecorderMessage(message) {
  if (message?.target !== "voice-recorder-ui") return;
  if (message.type === "voice-recorder-permission-granted") {
    setStatus("Microphone enabled. Starting voice note...");
    void startVoiceRecording({ permissionGranted: true, target: app.pendingVoiceTarget });
    return;
  }
  if (message.requestId !== app.voiceRecording?.requestId) return;

  if (message.type === "voice-recorder-started") {
    app.voiceRecordingPending = false;
    app.voiceRecording.status = "recording";
    app.voiceRecording.startedAt = Date.now();
    app.voiceRecording.interval = setInterval(updateVoiceRecordingUi, 250);
    updateVoiceRecordingUi();
    setStatus("Recording voice note. Select Done when finished.");
    return;
  }

  if (message.type === "voice-recorder-result") {
    const attachment = message.attachment;
    const recordingTarget = app.voiceRecording?.target || "conversation";
    clearVoiceRecordingState();
    if (!attachment?.dataUrl?.startsWith("data:audio/") || attachment.size > 750 * 1024) {
      setStatus("Chrome returned an invalid voice recording.");
      return;
    }
    if (recordingTarget === "multi-send") {
      app.multiSendAttachment = attachment;
      renderMultiSendAttachmentPreview();
    } else {
      app.selectedAttachment = attachment;
      renderAttachmentPreview();
    }
    app.pendingVoiceTarget = "conversation";
    setStatus("Voice note ready to send.");
    return;
  }

  if (message.type === "voice-recorder-cancelled") {
    clearVoiceRecordingState();
    setStatus("Voice note cancelled.");
    return;
  }

  if (message.type === "voice-recorder-error") {
    const detail = voiceRecorderErrorMessage(message.errorName, message.errorMessage);
    clearVoiceRecordingState();
    setStatus(detail);
    void updateDiagnostics({ failure: `Voice recorder: ${message.errorName || "Error"} - ${message.errorMessage || detail}` });
  }
}

async function microphonePermissionState() {
  try {
    if (!navigator.permissions?.query) return "prompt";
    const permission = await navigator.permissions.query({ name: "microphone" });
    return permission.state || "prompt";
  } catch {
    return "prompt";
  }
}

function voiceRecorderErrorMessage(errorName, fallback = "") {
  if (["NotAllowedError", "PermissionDeniedError"].includes(errorName)) {
    return "Microphone access is blocked. Allow microphone access for Bypassium in Chrome and Windows settings.";
  }
  if (errorName === "NotFoundError") return "Chrome could not find a microphone.";
  if (errorName === "NotReadableError") return "The microphone is busy in another app or blocked by Windows.";
  if (errorName === "SecurityError") return "A browser or administrator policy blocked microphone recording.";
  if (errorName === "RecordingTooShort") return "That voice note was too short.";
  return fallback || "Chrome could not record that voice note.";
}

function clearVoiceRecordingState() {
  clearInterval(app.voiceRecording?.interval);
  app.voiceRecording = null;
  app.voiceRecordingPending = false;
  updateVoiceRecordingUi();
}

function updateVoiceRecordingUi() {
  const recording = app.voiceRecording;
  const active = isVoiceRecording();
  const durationMs = active && recording.startedAt ? Date.now() - recording.startedAt : 0;
  elements.voiceRecordingBar.classList.toggle("hidden", !active);
  elements.voiceRecordingTimer.textContent = formatVoiceDuration(durationMs);
  elements.voiceNoteButton.classList.toggle("recording", active);
  elements.voiceNoteButton.setAttribute("aria-pressed", String(active));
  elements.voiceNoteButton.title = active ? "Finish voice note" : "Record a voice note";
  elements.messageForm.classList.toggle("recording-voice", active);
  elements.multiSendVoice.classList.toggle("recording", active && recording?.target === "multi-send");
  elements.multiSendVoice.textContent = active && recording?.target === "multi-send" ? "Stop recording" : "Record voice note";
  if (recording?.target === "multi-send") {
    elements.multiSendFeedback.textContent = active
      ? `Recording voice note ${formatVoiceDuration(durationMs)} - select Stop recording when finished.`
      : elements.multiSendFeedback.textContent;
  }
  renderMultiSendAttachmentPreview();
  syncComposerControls();
}

function formatVoiceDuration(durationMs = 0) {
  const totalSeconds = Math.max(0, Math.floor(Number(durationMs) / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = String(totalSeconds % 60).padStart(2, "0");
  return `${minutes}:${seconds}`;
}

async function handleAttachmentPicked() {
  const file = elements.attachmentInput.files?.[0];
  if (!file) return;
  try {
    app.selectedAttachment = await prepareAttachment(file);
    renderAttachmentPreview();
  } catch (error) {
    setStatus(error.message);
  } finally {
    elements.attachmentInput.value = "";
  }
}

function previewGroupPicture() {
  const file = elements.groupPicture.files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async () => {
    app.pendingGroupPicture = await resizeProfilePicture(reader.result);
    elements.groupPicturePreview.src = app.pendingGroupPicture;
    elements.groupPicturePreview.classList.remove("hidden");
  };
  reader.readAsDataURL(file);
}

function clearGroupPicturePreview() {
  app.pendingGroupPicture = "";
  elements.groupPicture.value = "";
  elements.groupPicturePreview.src = "";
  elements.groupPicturePreview.classList.add("hidden");
}

async function handleComposerPaste(event) {
  const file = [...(event.clipboardData?.files || [])].find((item) => item.type.startsWith("image/"));
  if (file) {
    event.preventDefault();
    await setAttachmentFromFile(file);
    return;
  }

  const text = event.clipboardData?.getData("text/plain")?.trim();
  const gifUrl = findGifUrl(text);
  if (gifUrl) {
    event.preventDefault();
    app.selectedAttachment = {
      type: "image/gif",
      name: "GIF",
      url: gifUrl,
      size: 0,
      external: true
    };
    renderAttachmentPreview();
  }
}

async function handleComposerDrop(event) {
  const file = [...(event.dataTransfer?.files || [])].find((item) => item.type.startsWith("image/"));
  if (!file) return;
  event.preventDefault();
  await setAttachmentFromFile(file);
}

async function setAttachmentFromFile(file) {
  try {
    app.selectedAttachment = await prepareAttachment(file);
    renderAttachmentPreview();
  } catch (error) {
    setStatus(error.message);
  }
}

async function prepareAttachment(file) {
  const isGif = file.type === "image/gif" || file.name.toLowerCase().endsWith(".gif");
  if (!file.type.startsWith("image/") && !isGif) throw new Error("Only images and GIFs are supported.");
  if (isGif) {
    if (file.size > 450 * 1024) throw new Error("GIF is too large. Keep GIFs under 450 KB so server storage stays low.");
    return { type: "image/gif", name: file.name.slice(0, 80), dataUrl: await fileToDataUrl(file), size: file.size };
  }
  const dataUrl = await resizeOutgoingImage(await fileToDataUrl(file));
  if (!dataUrl) throw new Error("Could not prepare that image.");
  if (dataUrl.length > 360000) throw new Error("Image is too large after compression. Try a smaller image.");
  return { type: "image/jpeg", name: file.name.slice(0, 80), dataUrl, size: dataUrl.length };
}

function findGifUrl(text = "") {
  const match = String(text).match(/https?:\/\/\S+/i);
  if (!match) return "";
  const url = match[0].replace(/[)\].,!?]+$/, "");
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    const path = parsed.pathname.toLowerCase();
    if (path.endsWith(".gif") || host.includes("tenor.com") || host.includes("giphy.com") || host.includes("media.giphy.com")) return url;
  } catch {
    return "";
  }
  return "";
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Could not read that file."));
    reader.readAsDataURL(file);
  });
}

function resizeOutgoingImage(dataUrl) {
  return new Promise((resolve) => {
    const image = new Image();
    image.onload = () => {
      const maxSide = 960;
      const scale = Math.min(1, maxSide / Math.max(image.width, image.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(image.width * scale));
      canvas.height = Math.max(1, Math.round(image.height * scale));
      canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
      resolve(canvas.toDataURL("image/jpeg", 0.72));
    };
    image.onerror = () => resolve("");
    image.src = dataUrl;
  });
}

function sanitizeChatBackgroundImage(value = "") {
  const image = String(value || "");
  return image.startsWith("data:image/jpeg;base64,") && image.length <= 260000 ? image : "";
}

function renderAttachmentPreview() {
  elements.attachmentPreview.classList.toggle("hidden", !app.selectedAttachment);
  const audioSource = app.selectedAttachment?.dataUrl?.startsWith("data:audio/") ? app.selectedAttachment.dataUrl : "";
  elements.attachmentPreview.classList.toggle("voice-attachment-preview", Boolean(audioSource));
  elements.attachmentPreview.innerHTML = audioSource
    ? `<div class="voice-preview-content">${renderVoiceNotePlayer(app.selectedAttachment, true)}</div><button type="button" class="secondary" id="clearAttachment">Remove</button>`
    : app.selectedAttachment
    ? `<span>${escapeHtml(app.selectedAttachment.external ? "GIF link attached" : app.selectedAttachment.name || "Image")}</span><button type="button" class="secondary" id="clearAttachment">Remove</button>`
    : "";
  document.querySelector("#clearAttachment")?.addEventListener("click", () => {
    app.selectedAttachment = null;
    renderAttachmentPreview();
  });
  initializeVoiceNotePlayers(elements.attachmentPreview);
  syncComposerControls();
}

function renderReplyPreview() {
  elements.replyPreview.classList.toggle("hidden", !app.replyTo);
  elements.replyPreview.innerHTML = app.replyTo
    ? `<span class="reply-preview-content">${app.replyTo.image ? `<img class="reply-thumb" src="${escapeHtml(app.replyTo.image)}" alt="">` : ""}<span>Replying to ${escapeHtml(app.replyTo.sender)}: ${escapeHtml(app.replyTo.preview)}</span></span><button type="button" class="secondary" id="clearReply">Cancel</button>`
    : "";
  document.querySelector("#clearReply")?.addEventListener("click", () => {
    app.replyTo = null;
    renderReplyPreview();
  });
}

function clearComposerState() {
  elements.messageInput.value = "";
  app.selectedAttachment = null;
  app.replyTo = null;
  renderAttachmentPreview();
  renderReplyPreview();
}

function openMessageActions(message, context, bubble) {
  closeMessageActions();
  const menu = document.createElement("div");
  menu.className = "message-actions-menu";
  menu.innerHTML = `
    <button type="button" data-action="reply">Reply</button>
    <button type="button" data-action="react">React</button>
    <button type="button" data-action="copy">Copy</button>
    <button type="button" data-action="delete">Delete</button>
  `;
  elements.messages.append(menu);
  app.messageActionMenu = menu;
  positionFloatingMenu(menu, bubble, -42);
  menu.addEventListener("click", async (event) => {
    event.stopPropagation();
    const action = event.target?.dataset?.action;
    if (action === "reply") startReply(message, context);
    if (action === "react") {
      openEmojiPicker(message, context, bubble);
      return;
    }
    if (action === "copy") await navigator.clipboard.writeText(message.text || message.attachment?.name || "Image attachment");
    if (action === "delete") await deleteLocalMessage(message, context);
    closeMessageActions();
  });
}

function closeMessageActions() {
  app.messageActionMenu?.remove();
  app.messageActionMenu = null;
  app.emojiPicker?.remove();
  app.emojiPicker = null;
}

function openEmojiPicker(message, context, bubble) {
  app.emojiPicker?.remove();
  const picker = document.createElement("div");
  picker.className = "emoji-picker";
  const emojis = ["👍", "❤️", "😂", "😮", "😢", "🔥", "👏", "💀"];
  picker.innerHTML = emojis.map((emoji) => `<button type="button" data-emoji="${emoji}">${emoji}</button>`).join("");
  elements.messages.append(picker);
  app.emojiPicker = picker;
  positionFloatingMenu(picker, bubble, -88);
  picker.addEventListener("click", async (event) => {
    event.stopPropagation();
    const emoji = event.target?.dataset?.emoji;
    if (!emoji) return;
    await reactToLocalMessage(message, context, emoji);
    closeMessageActions();
  });
}

function positionFloatingMenu(menu, bubble, offsetY) {
  const containerRect = elements.messages.getBoundingClientRect();
  const bubbleRect = bubble.getBoundingClientRect();
  const menuRect = menu.getBoundingClientRect();
  const padding = 8;
  const preferredLeft = bubbleRect.left - containerRect.left + (bubbleRect.width / 2) - (menuRect.width / 2);
  const maxLeft = Math.max(padding, containerRect.width - menuRect.width - padding);
  const left = Math.min(Math.max(padding, preferredLeft), maxLeft);
  const top = Math.max(padding, bubbleRect.top - containerRect.top + elements.messages.scrollTop + offsetY);
  menu.style.left = `${left}px`;
  menu.style.right = "auto";
  menu.style.top = `${top}px`;
}

async function reactToLocalMessage(message, context, emoji) {
  const key = message.messageId || message.localId || `${message.direction}:${message.sentAt}:${message.text || ""}`;
  const active = !(message.reactions?.[emoji] || []).includes(app.identity.id);
  if (context.group) {
    await reactToGroupMessage(context.group.id, key, emoji, app.identity.id, active);
  } else if (context.contact) {
    await reactToMessage(context.contact.id, key, emoji, app.identity.id, active);
  }
  app.state = await loadState();
  renderConversation();
  if (context.group) {
    app.peer.sendGroupReaction(context.group, app.state.contacts, key, emoji, active).catch((error) => setStatus(error.message));
  } else if (context.contact) {
    app.peer.sendReaction({ to: context.contact.id, messageId: key, emoji, active, publicKeyJwk: context.contact.publicKeyJwk }).catch((error) => setStatus(error.message));
  }
}

function startReply(message, context) {
  const attachmentSource = message.attachment?.dataUrl?.startsWith("data:image/")
    ? message.attachment.dataUrl
    : message.attachment?.url || "";
  const isVoiceNote = message.attachment?.dataUrl?.startsWith("data:audio/");
  app.replyTo = {
    messageId: message.messageId || message.localId || "",
    sender: context.group ? senderLabel(message.senderId) : message.direction === "outbound" ? "You" : currentContact()?.name || "Contact",
    preview: message.text || (isVoiceNote ? `Voice note (${formatVoiceDuration(message.attachment.durationMs)})` : message.attachment?.name || "Image attachment"),
    image: attachmentSource
  };
  renderReplyPreview();
  elements.messageInput.focus();
}

async function deleteLocalMessage(message, context) {
  const key = message.messageId || message.localId || `${message.direction}:${message.sentAt}:${message.text || ""}`;
  if (context.group) await deleteGroupMessage(context.group.id, key);
  else if (context.contact) await deleteMessage(context.contact.id, key);
  app.state = await loadState();
  renderConversation();
}

function typingPeople(group, contact) {
  if (group) {
    return [...(app.typingByGroup.get(group.id)?.keys() || [])]
      .filter((id) => id !== app.identity.id)
      .map(typingPerson);
  }
  return contact && app.typingByContact.has(contact.id) ? [typingPerson(contact.id)] : [];
}

function typingPerson(id) {
  const contact = app.state.contacts.find((item) => item.id === id);
  return {
    id,
    name: contact?.name || id,
    avatar: contact?.avatar || ""
  };
}

function renderTypingAvatar(person) {
  return `<span class="typing-avatar">${person.avatar ? `<img src="${person.avatar}" alt="">` : escapeHtml(person.name.slice(0, 1).toUpperCase())}</span>`;
}

function formatTypingNames(names) {
  if (names.length === 1) return `${names[0]} is`;
  if (names.length === 2) return `${names[0]} and ${names[1]} are`;
  return `${names[0]} and ${names.length - 1} others are`;
}

function senderLabel(senderId) {
  if (senderId === app.identity.id) return "You";
  return app.state.contacts.find((contact) => contact.id === senderId)?.name || senderId || "Unknown";
}

function contactDisplayName(contact, profile = {}, fallback = "") {
  if (contact?.nameEdited && contact.name) return contact.name;
  const profileName = String(profile?.displayName || "").trim();
  if (profileName) return profileName;
  if (contact?.name && !isGeneratedContactName(contact.name, contact.id)) return contact.name;
  return fallback || contact?.id || "";
}

function isGeneratedContactName(name, id) {
  return !name
    || name === id
    || name === id?.slice(0, 12)
    || name === `Message request ${id}`;
}

function currentProfilePayload() {
  return {
    displayName: app.state.settings.displayName,
    profilePicture: sanitizeProfilePicture(app.state.settings.profilePicture),
    quickAddVisible: app.state.settings.quickAddVisible !== false
  };
}

function resizeProfilePicture(dataUrl) {
  return new Promise((resolve) => {
    const image = new Image();
    image.onload = () => {
      const canvas = document.createElement("canvas");
      const size = 72;
      canvas.width = size;
      canvas.height = size;
      const context = canvas.getContext("2d");
      const sourceSize = Math.min(image.width, image.height);
      const sourceX = Math.floor((image.width - sourceSize) / 2);
      const sourceY = Math.floor((image.height - sourceSize) / 2);
      context.drawImage(image, sourceX, sourceY, sourceSize, sourceSize, 0, 0, size, size);
      resolve(sanitizeProfilePicture(canvas.toDataURL("image/jpeg", 0.62)));
    };
    image.onerror = () => resolve("");
    image.src = dataUrl;
  });
}

function sanitizeProfilePicture(value) {
  const picture = String(value || "");
  if (!picture || !picture.startsWith("data:image/")) return "";
  return picture.length > 18000 ? picture.slice(0, 18000) : picture;
}

function setStatus(message) {
  elements.activeStatus.textContent = message;
}

function showToast(message) {
  clearTimeout(app.toastTimer);
  elements.toast.textContent = message;
  elements.toast.classList.remove("hidden");
  app.toastTimer = setTimeout(() => {
    elements.toast.classList.add("hidden");
  }, 1000);
}

function handlePeerStatus(message) {
  setStatus(message);
  if (message.includes("ready") || message.includes("disconnected") || message.includes("failed")) {
    renderConversation();
  }
}

async function clearUnreadCount(contactId) {
  const contact = app.state.contacts.find((item) => item.id === contactId);
  if (!contact?.unreadCount) return;
  await updateContact(contactId, { unreadCount: 0 });
  app.state = await loadState();
  renderMessageButtonUnread();
}

function formatUnreadCount(count) {
  return count > 99 ? "99+" : String(count);
}

function notificationPreview(message) {
  if (message.text) return message.text.slice(0, 80);
  if (message.attachment?.dataUrl?.startsWith("data:audio/")) return "Voice note";
  if (message.attachment?.name) return `Image: ${message.attachment.name}`;
  if (message.attachment) return "Image message";
  return "New encrypted message";
}

function renderInfoItem({ label, value }) {
  return `<article class="info-item"><strong>${escapeHtml(label)}</strong><span>${escapeHtml(String(value))}</span></article>`;
}

async function fetchServerHealthInfo() {
  try {
    const response = await fetch(serverHealthUrl(), { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const health = await response.json();
    return {
      label: "Server health",
      value: `${health.ok ? "Online" : "Problem"} - ${health.storage || "unknown storage"}, ${health.onlineClients || 0} online`
    };
  } catch (error) {
    return {
      label: "Server health",
      value: `Unavailable - ${error.message}`
    };
  }
}

function serverHealthUrl() {
  return SIGNALING_SERVER_URL.replace("wss://", "https://").replace("ws://", "http://") + "/health";
}

function estimateLocalStateSize() {
  try {
    return new Blob([JSON.stringify(app.state || {})]).size;
  } catch {
    return 0;
  }
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// Formats message timestamps with the least detail needed for a chat bubble.
function formatMessageTime(sentAt) {
  const date = new Date(sentAt);
  if (Number.isNaN(date.getTime())) return "";
  const now = new Date();
  const sameDay = date.toDateString() === now.toDateString();
  const time = date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  if (sameDay) return time;
  const day = date.toLocaleDateString([], { month: "short", day: "numeric" });
  return `${day}, ${time}`;
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[char]);
}

init();
