# Bypassium Messenger

Bypassium Messenger is a Manifest V3 Chrome extension for local-first encrypted messaging. It opens in Chrome's side panel so conversations can remain visible while browsing.

This hardware-enabled build also includes `HARDWARE-README.md`, a Node serial/WebSocket bridge, and an Arduino Uno terminal sketch for a physical Bypassium messenger console.

The implementation is privacy-focused:

- No email address or phone number is collected by Bypassium, and there is no analytics, advertising, or tracking.
- Each Chrome Sync profile receives a permanent random six-digit code. Only that code may be stored in `chrome.storage.sync`; private encryption keys remain local.
- Contacts, local contact names, profile pictures, conversations, settings, and diagnostics are stored locally.
- Encrypted direct and group messages travel through the Bypassium relay server. Offline envelopes are deleted after the receiving extension saves them locally.
- In-transit message bodies are encrypted with AES-GCM using an ECDH-derived shared key.
- Voice notes are recorded only after a user gesture, capped at 60 seconds, and sent through the same encrypted attachment pipeline.
- Message delivery can progress through Queued, Sent, Delivered, and Read states.

Important boundary: the extension uses browser-approved WebRTC, notification, and storage APIs. It reports network and policy failures, but it does not bypass browser, operating system, workplace, school, firewall, or administrative controls.

## Project Structure

```text
bypassium-messenger/
  manifest.json
  build.ps1
  README.md
  src/
    assets/
      icon-16.png
      icon-32.png
      icon-48.png
      icon-128.png
    background/
      service-worker.js
    offscreen/
      recorder.html
      recorder.js
    permissions/
      microphone.html
      microphone.css
      microphone.js
    shared/
      crypto.js
      identity.js
      storage.js
      webrtc.js
    sidepanel/
      app.js
      index.html
      styles.css
```

## Feature Map

- `src/shared/identity.js` restores the six-digit Bypassium code from Chrome Sync when available and stores ECDH keys locally.
- `src/shared/storage.js` wraps `chrome.storage.local` for contacts, conversations, delivery states, reactions, settings, and diagnostics.
- `src/shared/crypto.js` imports ECDH keys, derives an AES-GCM key, and encrypts/decrypts messages in transit.
- `src/shared/webrtc.js` manages the encrypted WebSocket relay, connection status, diagnostics, and encrypted sends.
- `src/sidepanel/app.js` controls the UI, local contact management, conversation rendering, notifications, settings, and dashboard.
- `src/sidepanel/styles.css` provides responsive dark/light side-panel styling inspired by modern chat tools.
- `src/background/service-worker.js` enables side-panel behavior, Chrome notifications, and the offscreen voice-recorder bridge.
- `src/offscreen/recorder.js` records microphone audio in Chrome's MV3 `USER_MEDIA` offscreen document and returns the finished encrypted attachment to the side panel.
- `src/permissions/microphone.js` performs the one-time microphone permission request from a visible extension window before offscreen recording begins.

## Installation

1. Open Chrome.
2. Go to `chrome://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the `bypassium-messenger` folder.
6. Click the Bypassium Messenger toolbar icon to open the persistent side panel.

## Build

No dependency installation is required.

To package the extension as a zip on Windows:

```powershell
cd .\bypassium-messenger
.\build.ps1
```

The zip is written to:

```text
dist/bypassium-messenger.zip
```

You can also load the project folder directly as an unpacked extension during development.

## How To Use

1. Install the extension on two Chrome profiles or devices.
2. Copy each six-digit Bypassium code and add it as a contact on the other side.
3. Open the contact from Messages.
4. Send encrypted direct messages or create a group from Menu.
5. The first voice-note attempt opens a focused Bypassium window; select **Allow microphone** once, then recording begins automatically.

Chats support search, mentions, counted emoji reactions, pinned conversations, voice notes with waveform playback and speed controls, per-chat background colours, and manual refresh. Direct Messages also provides **Send to multiple**, which creates a separately encrypted message in each selected contact's individual conversation without creating a group. Any group member can invite people. Owners and administrators retain the existing group-management permissions.

## Network Information Page

The Network Information page checks:

- Encrypted relay availability.
- Offline inbox support.
- Notification permission state.
- `chrome.storage.local` availability.
- Chrome Sync ID recovery availability.

## Developer Dashboard

The dashboard displays:

- Current connection type.
- Last measured local encryption/send latency.
- Encryption status.
- Peer connection status.
- Sent message count.
- Received message count.
- Recent diagnostic failures.

## Security Notes

This is a prototype and should be reviewed before sensitive use.

- Messages are encrypted before they reach the relay server, but local message history is stored as plaintext in `chrome.storage.local`.
- Chrome Sync may store the six-digit ID when enabled. Bypassium does not receive the Google account email address.
- Private ECDH keys remain local and are regenerated after an uninstall, even when the six-digit ID is restored.
- Offline encrypted envelopes are temporarily stored in Upstash and removed after acknowledgement.
- Six-digit codes are easy to exchange but can collide. There is no identity verification beyond exchanging codes and connection signals.

## Future Feature Suggestions

- Encrypt local conversation history at rest with a passphrase-derived key.
- Add verified safety numbers or key fingerprints.
- Add contact avatar import per friend.
- Add optional local backup and restore.
- Add optional self-hosted signaling for easier connection setup.
- Add optional self-hosted TURN support for networks that block direct peer-to-peer paths.
- Add multi-device identity export/import.
- Add encrypted local backup and restore.
- Add message editing, polls, and optional voice-note playback speed controls.
- Add service-worker offscreen document support if Chrome permits longer-lived background connection handling.
