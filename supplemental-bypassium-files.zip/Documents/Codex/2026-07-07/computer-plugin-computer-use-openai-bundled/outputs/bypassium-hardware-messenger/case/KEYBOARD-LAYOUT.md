# Bypassium Multi-Tap Keyboard Layout

3D-print model:

```text
case/multitap_keyboard_plate.scad
case/multitap_key_plungers.scad
case/multitap_keyboard_case.scad
```

Open each file in OpenSCAD, press `F6`, then export as STL.

The case is an open-top hollow box:

```text
52 mm wide
78 mm long
35 mm high
2 mm walls
2 mm bottom
matching screw posts for the keyboard plate
small cable notch on one short side
```

## Layout

```text
+---------+---------+
|  ABCD   |  EFGH   |
|   D2    |   D3    |
+---------+---------+
|  IJKL   |  MNOP   |
|   D4    |   D5    |
+---------+---------+
|  QRST   | UVWXYZ  |
|   D6    |   D7    |
+---------+---------+
| SPACE   |  BACK   |
|   D8    |   D9    |
+---------+---------+
|  NEXT   |  SEND   |
|   A0    |   A1    |
+---------+---------+
```

## Wiring

Each button uses the Arduino internal pullup:

```text
Arduino pin -> button leg
Other button leg -> GND
```

No resistor is needed for the button lines.

## Print Fit

The current button cutout is sized for your 6 mm x 6 mm through-hole tactile buttons:

```text
6.8 mm x 6.8 mm
```

The plate is now `5 mm` thick, so the full switch height can sit down inside each square pocket.

The separate key plunger file makes 10 small square press pieces:

```text
stem: 5.9 mm square
top cap: 8.4 mm square
underside press nub: 3.2 mm round
```

The plunger stem slides into the plate hole, the top cap sticks out above the plate, and the small round nub underneath presses the tactile switch.

If the plungers are too tight, edit:

```scad
stem_w = 5.8;
```

If the plungers are too loose, edit:

```scad
stem_w = 6.0;
```

If your button is smaller or larger, edit this line in `multitap_keyboard_plate.scad`:

```scad
button_cutout = 6.8;
```

Good rule:

```text
button_cutout = measured button body width + 0.3 mm
```

## Controls

- Press one letter key repeatedly to cycle letters.
- Wait about 1 second to lock the letter in.
- `SPACE` adds a space.
- `BACK` deletes one character.
- `NEXT` changes the selected contact.
- `SEND` sends the typed message.
