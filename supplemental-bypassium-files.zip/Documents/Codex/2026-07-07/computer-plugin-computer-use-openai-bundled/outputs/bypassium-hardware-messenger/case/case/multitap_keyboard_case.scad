/*
  Bypassium multi-tap keyboard hollow lower case.

  This is a 35 mm tall open-top box. The already-printed keyboard plate screws
  on as the lid. Screw holes match multitap_keyboard_plate.scad.

  Open in OpenSCAD, press F6, export STL.
*/

$fn = 36;

// Must match the keyboard plate.
case_w = 52;
case_h = 78;
case_height = 35;
corner_r = 3;
mount_hole_d = 3.2;
mount_inset = 5;

wall_t = 2;
bottom_t = 2;

// Screw posts inside the box.
post_d = 7.5;
post_h = 32;
post_hole_d = 2.4; // Pilot hole for small self-tapping screws.

// Cable notch on one short side for wires/USB.
cable_notch_w = 14;
cable_notch_h = 8;

module rounded_box(w, h, z, r) {
  hull() {
    translate([-(w / 2 - r), -(h / 2 - r), 0]) cylinder(h = z, r = r);
    translate([(w / 2 - r), -(h / 2 - r), 0]) cylinder(h = z, r = r);
    translate([-(w / 2 - r), (h / 2 - r), 0]) cylinder(h = z, r = r);
    translate([(w / 2 - r), (h / 2 - r), 0]) cylinder(h = z, r = r);
  }
}

module shell() {
  difference() {
    rounded_box(case_w, case_h, case_height, corner_r);

    translate([0, 0, bottom_t])
      rounded_box(case_w - wall_t * 2, case_h - wall_t * 2, case_height + 0.2, max(0.5, corner_r - wall_t));

    translate([0, case_h / 2 - wall_t / 2, bottom_t + cable_notch_h / 2])
      cube([cable_notch_w, wall_t + 0.4, cable_notch_h], center = true);
  }
}

module screw_post(x, y) {
  difference() {
    translate([x, y, bottom_t])
      cylinder(h = post_h, d = post_d);
    translate([x, y, bottom_t - 0.1])
      cylinder(h = post_h + 0.2, d = post_hole_d);
  }
}

module screw_posts() {
  for (x = [-case_w / 2 + mount_inset, case_w / 2 - mount_inset]) {
    for (y = [-case_h / 2 + mount_inset, case_h / 2 - mount_inset]) {
      screw_post(x, y);
    }
  }
}

union() {
  shell();
  screw_posts();
}
