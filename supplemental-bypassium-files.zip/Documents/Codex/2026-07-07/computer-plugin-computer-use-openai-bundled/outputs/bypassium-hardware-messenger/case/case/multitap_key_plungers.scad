/*
  Bypassium multi-tap key plungers.

  Print these separately from the keyboard plate.
  Each plunger slides into a square button hole and presses the small round nub
  on a 6 mm tactile switch underneath.

  If they are too tight, lower stem_w by 0.1 mm.
  If they are too loose, raise stem_w by 0.1 mm.
*/

$fn = 24;

key_count = 10;

// Keyboard plate hole is currently 6.35 mm.
stem_w = 5.9;
stem_h = 5.4;

// Top cap sits above the plate so your finger has something bigger to press.
cap_w = 8.4;
cap_h = 2.2;
cap_corner_r = 1.0;

// Small underside nub focuses pressure onto the tactile switch button.
press_nub_d = 3.2;
press_nub_h = 0.9;

spacing = 12;

module rounded_square(w, h, r) {
  hull() {
    translate([-(w / 2 - r), -(w / 2 - r), 0]) cylinder(h = h, r = r);
    translate([(w / 2 - r), -(w / 2 - r), 0]) cylinder(h = h, r = r);
    translate([-(w / 2 - r), (w / 2 - r), 0]) cylinder(h = h, r = r);
    translate([(w / 2 - r), (w / 2 - r), 0]) cylinder(h = h, r = r);
  }
}

module plunger() {
  union() {
    translate([0, 0, press_nub_h])
      cube([stem_w, stem_w, stem_h], center = true);

    translate([0, 0, press_nub_h + stem_h / 2])
      rounded_square(cap_w, cap_h, cap_corner_r);

    translate([0, 0, -press_nub_h / 2])
      cylinder(h = press_nub_h, d = press_nub_d, center = true);
  }
}

for (i = [0:key_count - 1]) {
  translate([(i % 5) * spacing, floor(i / 5) * spacing, 0])
    plunger();
}
