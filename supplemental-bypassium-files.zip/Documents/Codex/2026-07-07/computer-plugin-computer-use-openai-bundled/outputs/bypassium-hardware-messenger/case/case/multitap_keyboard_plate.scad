/*
  Bypassium 10-button multi-tap keyboard plate.

  Open this in OpenSCAD, press F6, then export STL.

  Assumption:
  - Buttons are 6 mm x 6 mm tactile switches.
  - The switch sits inside a full-depth square pocket.
  - The default cutout is 6.4 mm square.
  - If your button body/cap is different, change button_cutout.

  Wiring map from the Arduino sketch:
  D2  ABCD
  D3  EFGH
  D4  IJKL
  D5  MNOP
  D6  QRST
  D7  UVWXYZ
  D8  SPACE
  D9  BACK
  A0  NEXT
  A1  SEND
*/

$fn = 36;

plate_w = 52;
plate_h = 78;
plate_t = 5;
corner_r = 3;

button_cutout = 6.35;
button_pitch_x = 22;
button_pitch_y = 13;
label_offset_y = 5.5;

mount_hole_d = 3.2;
mount_inset = 5;

// Set true to print raised labels. Set false if you want to write labels with marker.
labels_enabled = true;
label_size = 2.6;
// Thin raised text keeps the button opening easier to press.
label_height = 0.22;

labels = [
  ["ABCD", "EFGH"],
  ["IJKL", "MNOP"],
  ["QRST", "UVWXYZ"],
  ["SPACE", "BACK"],
  ["NEXT", "SEND"]
];

module rounded_box(w, h, t, r) {
  hull() {
    translate([-(w / 2 - r), -(h / 2 - r), 0]) cylinder(h = t, r = r);
    translate([(w / 2 - r), -(h / 2 - r), 0]) cylinder(h = t, r = r);
    translate([-(w / 2 - r), (h / 2 - r), 0]) cylinder(h = t, r = r);
    translate([(w / 2 - r), (h / 2 - r), 0]) cylinder(h = t, r = r);
  }
}

module screw_holes() {
  for (x = [-plate_w / 2 + mount_inset, plate_w / 2 - mount_inset]) {
    for (y = [-plate_h / 2 + mount_inset, plate_h / 2 - mount_inset]) {
      translate([x, y, -0.1]) cylinder(h = plate_t + 0.2, d = mount_hole_d);
    }
  }
}

module button_positions() {
  for (row = [0:4]) {
    for (col = [0:1]) {
      x = (col - 0.5) * button_pitch_x;
      y = (2 - row) * button_pitch_y;
      translate([x, y, 0]) children();
    }
  }
}

module button_cutouts() {
  button_positions() {
    translate([0, 0, plate_t / 2])
      cube([button_cutout, button_cutout, plate_t + 0.2], center = true);
  }
}

module label_text() {
  if (labels_enabled) {
    for (row = [0:4]) {
      for (col = [0:1]) {
        x = (col - 0.5) * button_pitch_x;
        y = (2 - row) * button_pitch_y + label_offset_y;
        translate([x, y, plate_t])
          linear_extrude(height = label_height)
            text(labels[row][col], size = label_size, halign = "center", valign = "center", font = "Arial:style=Bold");
      }
    }
  }
}

difference() {
  rounded_box(plate_w, plate_h, plate_t, corner_r);
  button_cutouts();
  screw_holes();
}

label_text();
