# Bypassium Hardware Messenger Prototype

This build adds a local hardware bridge to the Bypassium Messenger extension.

## What runs where

- Chrome extension: contact list, identity, encrypted messages, local storage, relay connection.
- Node bridge: localhost WebSocket for the extension and USB serial for Arduino.
- Arduino Uno: hardware terminal controller for display, buzzer, buttons, and later the printer TFT.

## First test without Arduino

From `hardware-bridge`, using the bundled Node runtime:

```powershell
& "C:\Users\purce\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" .\mock-bridge.js
```

Then load this extension folder unpacked in Chrome and open:

```text
Settings > Developer > Hardware Terminal > Connect
```

In the bridge terminal, type:

```text
CONTACTS
SELECT|123456
SEND|123456|hello from the hardware bridge
STATUS|invisible
STATUS|online
```

Replace `123456` with one of your saved contact codes.

## Arduino mode

Upload:

```text
arduino/bypassium_terminal/bypassium_terminal.ino
```

Then run the bridge with your Arduino COM port:

```powershell
npm install
$env:BYPASSIUM_SERIAL_PORT="COM5"
npm start
```

Change `COM5` to the port shown in Arduino IDE.

## Current hardware wiring

For the 10-button multi-tap Arduino sketch:

```text
Arduino USB  -> computer running the Node bridge
Arduino A2   -> buzzer positive, through a suitable resistor if needed
Arduino GND  -> buzzer negative
Arduino A3   -> 220/330 ohm resistor -> online LED +, LED - -> GND
Arduino A4   -> 220/330 ohm resistor -> message LED +, LED - -> GND
Arduino D10  -> TFT RX, tentative
Arduino D11  -> TFT TX, tentative
Arduino 5V   -> TFT VCC only if the TFT header is confirmed 5V
Arduino GND  -> TFT GND
```

Each button connects from the listed Arduino pin to `GND`; the sketch uses `INPUT_PULLUP`, so no button resistors are needed.

```text
D2 -> button -> GND   letters a b c d
D3 -> button -> GND   letters e f g h
D4 -> button -> GND   letters i j k l
D5 -> button -> GND   letters m n o p
D6 -> button -> GND   letters q r s t
D7 -> button -> GND   letters u v w x y z
D8 -> button -> GND   space
D9 -> button -> GND   backspace
A0 -> button -> GND   next contact
A1 -> button -> GND   send typed message
```

The TFT pinout still needs confirming from a close-up photo or multimeter check. Do not connect the TFT until the `VCC`, `GND`, `RX`, and `TX` labels are confirmed.

## Protocol

Arduino to bridge:

```text
SNAPSHOT
CONTACTS
SELECT|contactId
SEND|contactId|message text
STATUS|online
STATUS|invisible
```

Bridge to Arduino:

```text
READY|ownId|displayName|presence
CONTACT|index|contactId|name|status|unreadCount
END_CONTACTS
CHAT|contactId|name
MSG|direction|text|sentAt
END_CHAT
INCOMING|contactId|name|text
SENT|contactId|messageId
ERROR|message
```

## Important limits

- The Uno is not doing encryption or WebRTC. The extension still does that.
- The Creality box is not used yet. It can replace the laptop bridge later if it can run Node or another WebSocket/serial bridge.
- The TFT output is tentative because the screen protocol is not identified yet.
