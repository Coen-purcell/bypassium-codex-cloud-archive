param(
  [string]$Output = "dist\bypassium-messenger.zip"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifest = Join-Path $root "manifest.json"
$dist = Join-Path $root "dist"
$zip = Join-Path $root $Output

if (!(Test-Path $manifest)) {
  throw "manifest.json was not found."
}

if (Test-Path $dist) {
  Remove-Item -LiteralPath $dist -Recurse -Force
}

New-Item -ItemType Directory -Force -Path $dist | Out-Null
Compress-Archive -Path (Join-Path $root "manifest.json"), (Join-Path $root "src") -DestinationPath $zip -Force
Write-Host "Created $zip"
